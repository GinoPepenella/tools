##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Oracle Java Runtime Environment (JRE) Version 8 for Windows
# Version:  V2R1
# Class:    UNCLASSIFIED
# Updated:  5/13/2024
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Format-JavaPath {
    # https://en.wikipedia.org/wiki/File_URI_scheme
    # https://docs.oracle.com/javase/8/docs/technotes/guides/deploy/properties.html
    Param (
        [Parameter(Mandatory = $true)]
        [String]$Path,

        [Parameter(Mandatory = $true)]
        [ValidateSet("deployment.properties", "exception.sites")]
        [String]$JavaFile
    )

    $Result = New-Object System.Collections.Generic.List[System.Object]
    $Pass = $true

    $WorkingPath = $Path -replace "\\{5,}", "///" -replace "\\{4}", "//" -replace "\\{3}", "/" -replace "\\{2}", "/" -replace "\\{1}", ""

    Switch ($JavaFile) {
        "deployment.properties" {
            # Java variables don't appear to work for deployment.properties path
            If ($WorkingPath -like '*$SYSTEM_HOME*' -or $WorkingPath -like '*$USER_HOME*' -or $WorkingPath -like '*$JAVA_HOME*') {
                $Pass = $false
                $Formatted = "Path to deployment.properites cannot include a variable.`r`nRefer to https://docs.oracle.com/javase/8/docs/technotes/guides/deploy/properties.html"
            }
            ElseIf ($WorkingPath -notlike 'file:*') {
                $Pass = $false
                $Formatted = "Path to deployment.properites must start with proper 'file:' format.`r`nRefer to https://docs.oracle.com/javase/8/docs/technotes/guides/deploy/properties.html"
            }
            Else {
                Switch -Regex ($WorkingPath) {
                    # Local path patterns
                    "^file:[A-Za-z]:{1}" {
                        # 'file:C:'
                        $Formatted = $WorkingPath -replace "file:", ""
                    }
                    "^file:/{1}[A-Za-z]:{1}" {
                        # 'file:/C:'
                        $Formatted = $WorkingPath -replace "file:/{1}", ""
                    }
                    "^file:/{3}[A-Za-z]:{1}" {
                        # 'file:///C:'
                        $Formatted = $WorkingPath -replace "file:/{3}", ""
                    }
                    # UNC path pattern
                    "^file:/{2}[A-Za-z0-9]" {
                        # 'file://<server>'
                        $Formatted = $WorkingPath -replace "file:", ""
                        If ($Formatted -match ":") {
                            $Pass = $false
                        }
                    }
                    # Dynamic pattern
                    "^file:/{4,}[A-Za-z0-9]" {
                        # 'file:////<server or drive letter>' (4 or more slashes)
                        If ($WorkingPath -match "file:/{4,}[A-Za-z]:") {
                            # Drive letter detected
                            $Formatted = $WorkingPath -replace "file:/{4,}", ""
                        }
                        Else {
                            # No drive letter detected so UNC
                            $Formatted = $WorkingPath -replace "file:/{4,}", "//"
                        }
                    }
                    Default {
                        $Pass = $false
                        $Formatted = "Path to deployment.properites is invalid format.`r`nRefer to https://docs.oracle.com/javase/8/docs/technotes/guides/deploy/properties.html"
                    }
                }
            }
        }
        "exception.sites" {
            If ($WorkingPath -like '*$SYSTEM_HOME*') {
                $WorkingPath = $WorkingPath.Replace('$SYSTEM_HOME', $("$($env:SystemRoot.Replace("\","/"))/Sun/Java/Deployment"))
            }
            Switch -Regex ($WorkingPath) {
                # Local path patterns
                "^[A-Za-z]:{1}" {
                    # 'C:'
                    $Formatted = $WorkingPath
                }
                "^/{1}[A-Za-z]:{1}" {
                    # '/C:'
                    $Formatted = $WorkingPath -replace "/{1}", ""
                }
                # Dynamic pattern
                "^/{2,}[A-Za-z0-9]" {
                    # '//<server or drive letter>' (2 or more slashes)
                    If ($WorkingPath -match "/{2,}[A-Za-z]:") {
                        # Drive letter detected
                        $Formatted = $WorkingPath -replace "/{2,}", ""
                    }
                    Else {
                        # No drive letter detected so UNC
                        $Formatted = $WorkingPath -replace "/{2,}", "//"
                    }
                }
                Default {
                    $Pass = $false
                    $Formatted = "Path to exception.sites is an invalid format."
                }
            }
        }
    }

    $NewObj = [PSCustomObject]@{
        Pass       = $Pass
        Configured = $Path
        Working    = $WorkingPath
        Formatted  = $Formatted
    }
    $Result.Add($NewObj)

    Return $Result
}

Function Get-JreInstallPath {
    $JrePath = @()
    If (Test-Path 'HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment\1.8') {
        $JrePath += Get-ChildItem "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment\" -Recurse | Where-Object { ($_.Name -match "1\.8") -and ($_.Property -match "INSTALLDIR") } | ForEach-Object { Get-ItemPropertyValue -Path $_.PsPath -Name "INSTALLDIR" }
    }
    If (Test-Path 'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment\1.8') {
        $JrePath += Get-ChildItem "HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment\" -Recurse | Where-Object { ($_.Name -match "1\.8") -and ($_.Property -match "INSTALLDIR") } | ForEach-Object { Get-ItemPropertyValue -Path $_.PsPath -Name "INSTALLDIR" }
    }

    Get-InstalledSoftware | Where-Object DisplayName -like "Java 8*" | ForEach-Object {
        If ($_.InstallLocation) {
            $JrePath += $_.InstallLocation
        }
    }

    Return ($JrePath | Select-Object -Unique)
}

Function Test-ConfigFile {
    $Result = New-Object System.Collections.Generic.List[System.Object]
    $ResultText = @()
    $Compliant = $true
    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $JREPaths = Get-JreInstallPath
    $PathsToEval += $JREPaths | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in ($PathsToEval | Sort-Object -Descending)) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $ResultText += "Java JRE 8 Install Paths:"
    ForEach ($JREPath in $JREPaths) {
        $ResultText += " - $($JREPath)"
    }
    $ResultText += ""

    If (-Not($ConfigFiles)) {
        $Compliant = $false
        $ResultText += "No deployment.config file found - FINDING"
    }
    Else {
        $ResultText += "Config file status:"
        # Check for Windows deployment.config
        If ("$env:windir\Sun\Java\Deployment\deployment.config" -in $ConfigFiles.FullName) {
            $WindowsJREConfig = $true
            $ResultText += " - $env:windir\Sun\Java\Deployment\deployment.config - Found"
        }
        Else {
            $WindowsJREConfig = $false
            $ResultText += " - $env:windir\Sun\Java\Deployment\deployment.config - Not Found"
        }

        # Check for JRE install deployment.config
        ForEach ($JREPath in $JREPaths) {
            If ($ConfigFiles.FullName -like "$($JREPath)*") {
                $ResultText += " - $JREPath\lib\deployment.config - Found"
            }
            Else {
                If ($WindowsJREConfig -ne $true) {
                    $Compliant = $false
                    $ResultText += " - $JREPath\lib\deployment.config - Not Found - FINDING"
                }
                Else {
                    $ResultText += " - $JREPath\lib\deployment.config - Not Found - Using $env:WINDIR config file"
                }
            }
        }
    }
    $NewObj = [PSCustomObject]@{
        Compliant   = $Compliant
        ConfigFiles = $ConfigFiles
        ResultText  = $ResultText
    }
    $Result.Add($NewObj)

    Return $Result
}

Function Get-V234683 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234683
        STIG ID    : JRE8-WN-000010
        Rule ID    : SV-234683r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must have a deployment.config file present.
        DiscussMD5 : 9818E1EA7EECA4B3BD524ED5B2EEEC58
        CheckMD5   : FF4729117E5666B70713BE75F7FEC6F6
        FixMD5     : 616E11652FD1B9DA6AA094820F1EE7B1
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234684 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234684
        STIG ID    : JRE8-WN-000020
        Rule ID    : SV-234684r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 deployment.config file must contain proper keys and values.
        DiscussMD5 : 8FB93155C9BB13C1B3634DD0F84DDDE2
        CheckMD5   : D0E2F44955928C45651341C1B0A4307F
        FixMD5     : 24AAF789E785C2C58A3DC0E11C7EFAE3
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    $KeysToEval = "deployment.system.config=", `
        "deployment.system.config.mandatory=true"

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $Option1Set = $false
            $Option2Set = $false
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $FindingDetails += "" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "$($KeysToEval[0])*") {
                        $Option1Set = $true
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                        }
                        If ($PropsPath) {
                            $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                            If ($PropsFile.Pass -ne $true) {
                                $Compliant = $false
                                $FindingDetails += "$Line" | Out-String
                                $FindingDetails += "" | Out-String
                                $FindingDetails += "$($PropsFile.Configured) - FINDING" | Out-String
                            }
                            ElseIf ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "$Line" | Out-String
                                $FindingDetails += "" | Out-String
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                $FindingDetails += "$Line is present" | Out-String
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                    }
                    ElseIf (($Line -Replace "\s", "") -eq $KeysToEval[1]) {
                        $Option2Set = $true
                        $FindingDetails += "$Line is present" | Out-String
                    }
                }

                If ($Option1Set -eq $false) {
                    $Compliant = $false
                    $FindingDetails += "Path to 'deployment.properties' is NOT present - FINDING" | Out-String
                }
                ElseIf ($Option2Set -eq $false) {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config.mandatory=true is NOT present - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234685 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234685
        STIG ID    : JRE8-WN-000030
        Rule ID    : SV-234685r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must have a deployment.properties file present.
        DiscussMD5 : 588666C94B5F3D39746B984449C6E6D5
        CheckMD5   : 9E5CA877CB4BF5114A763616C17A6EC3
        FixMD5     : 5285A3A0AD25A1377B2C103E30555390
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Configured) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $FindingDetails += "Properties file exists in the path defined." | Out-String
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234686 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234686
        STIG ID    : JRE8-WN-000060
        Rule ID    : SV-234686r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must default to the most secure built-in setting.
        DiscussMD5 : 61476BE2840E85A7AA739C3F90814373
        CheckMD5   : 4E1BE6FB8538E4CD45764ACED10D661E
        FixMD5     : 4FAE488F6C2251EC3DB60D01D0D3E46E
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.security.level=VERY_HIGH", `
        "deployment.security.level.locked"

    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                }
                                Else {
                                    $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                    ForEach ($Key in $KeysToEval) {
                                        If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                            $FindingDetails += "$Key is present" | Out-String
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                        }
                                    }
                                }
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234687 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234687
        STIG ID    : JRE8-WN-000070
        Rule ID    : SV-234687r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must be set to allow Java Web Start (JWS) applications.
        DiscussMD5 : 5DEE22E2DE37260B37F6F641CDFAE90C
        CheckMD5   : E7961FD2EE56FB5CA335A6698971F3E6
        FixMD5     : E1BDBFD6E8B5B20A33BAA0C7A49ED5EF
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.webjava.enabled=true", `
        "deployment.webjava.enabled.locked"

    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                }
                                Else {
                                    $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                    ForEach ($Key in $KeysToEval) {
                                        If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                            $FindingDetails += "$Key is present" | Out-String
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                        }
                                    }
                                }
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234688 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234688
        STIG ID    : JRE8-WN-000080
        Rule ID    : SV-234688r617446_rule
        CCI ID     : CCI-001695
        Rule Name  : SRG-APP-000112
        Rule Title : Oracle JRE 8 must disable the dialog enabling users to grant permissions to execute signed content from an untrusted authority.
        DiscussMD5 : 884B69274C3B7E49843DC681FC28341A
        CheckMD5   : 168E005119660EA412563B0774F80DCF
        FixMD5     : 79422036C6641DB371AABE21829E3348
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.askgrantdialog.notinca=false", `
            "deployment.security.askgrantdialog.notinca.locked"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            $FindingDetails += "" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                                $FindingDetails += "$Key is present" | Out-String
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234689 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234689
        STIG ID    : JRE8-WN-000090
        Rule ID    : SV-234689r617446_rule
        CCI ID     : CCI-001695
        Rule Name  : SRG-APP-000112
        Rule Title : Oracle JRE 8 must lock the dialog enabling users to grant permissions to execute signed content from an untrusted authority.
        DiscussMD5 : CF669DA14A24210AF51C2FEB68300BBC
        CheckMD5   : 0CB927326259CC3E224BDE774FBA1ED8
        FixMD5     : 177A88046D5AD5B5870DACC0E0A44623
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.askgrantdialog.show=false", `
            "deployment.security.askgrantdialog.show.locked"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            $FindingDetails += "" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                                $FindingDetails += "$Key is present" | Out-String
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234690 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234690
        STIG ID    : JRE8-WN-000100
        Rule ID    : SV-234690r617446_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : Oracle JRE 8 must set the option to enable online certificate validation.
        DiscussMD5 : A49775A6E44134FD46FF4732407BF5FB
        CheckMD5   : CC8ADDB08E2971213CD95E02DA5D331E
        FixMD5     : E48D9A9FD9F1FA1AB4B430C56DD5B426
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.validation.ocsp=true", `
            "deployment.security.validation.ocsp.locked"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            $FindingDetails += "" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                                $FindingDetails += "$Key is present" | Out-String
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234691 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234691
        STIG ID    : JRE8-WN-000110
        Rule ID    : SV-234691r617446_rule
        CCI ID     : CCI-001169
        Rule Name  : SRG-APP-000209
        Rule Title : Oracle JRE 8 must prevent the download of prohibited mobile code.
        DiscussMD5 : CEC79E03E4228BD7547CB3EBAB995CA3
        CheckMD5   : B5A925EEBB4F85963F29B7BEE5DEF7D1
        FixMD5     : C65541F32BE040260340C60BD50313A1
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.security.blacklist.check=true", `
        "deployment.security.blacklist.check.locked"

    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                }
                                Else {
                                    $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                    ForEach ($Key in $KeysToEval) {
                                        If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                            $FindingDetails += "$Key is present" | Out-String
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                        }
                                    }
                                }
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234692 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234692
        STIG ID    : JRE8-WN-000120
        Rule ID    : SV-234692r617446_rule
        CCI ID     : CCI-001774
        Rule Name  : SRG-APP-000386
        Rule Title : Oracle JRE 8 must enable the option to use an accepted sites list.
        DiscussMD5 : F07373721D4DC99C769562427B1C6F3B
        CheckMD5   : 5393E295AA4782DB5B1EA14A54130D52
        FixMD5     : A05A7DFCBDAF91D48996E1CE3387991B
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.user.security.exception.sites"

    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                }
                                Else {
                                    $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                    ForEach ($Key in $KeysToEval) {
                                        If ($DeployFileContent -match $Key) {
                                            ForEach ($Line in $DeployFileContent) {
                                                If ($Line -like "$($KeysToEval)*") {
                                                    $ExceptionPath = ($Line.Split("=")[1]).Trim()
                                                    Break
                                                }
                                            }
                                            If ($ExceptionPath) {
                                                $ExceptionFile = Format-JavaPath -Path $ExceptionPath -JavaFile exception.sites
                                                If ($ExceptionFile.Pass -ne $true) {
                                                    $Compliant = $false
                                                    $FindingDetails += "$Line" | Out-String
                                                    $FindingDetails += "" | Out-String
                                                    $FindingDetails += "$($ExceptionFile.Formatted) - FINDING" | Out-String
                                                }
                                                ElseIf ($ExceptionFile.Formatted.Split("/")[0, -1][1] -ne "exception.sites") {
                                                    $Compliant = $false
                                                    $FindingDetails += "$Line" | Out-String
                                                    $FindingDetails += "" | Out-String
                                                    $FindingDetails += "$Key does NOT point to an 'exception.sites' file - FINDING" | Out-String
                                                }
                                                Else {
                                                    $FindingDetails += "$Line is present" | Out-String
                                                }
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Line" | Out-String
                                                $FindingDetails += "" | Out-String
                                                $FindingDetails += "Path to 'exception.sites' file is NOT defined in properties file - FINDING" | Out-String
                                            }
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                        }
                                    }
                                }
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234693 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234693
        STIG ID    : JRE8-WN-000130
        Rule ID    : SV-234693r617446_rule
        CCI ID     : CCI-001774
        Rule Name  : SRG-APP-000386
        Rule Title : Oracle JRE 8 must have an exception.sites file present.
        DiscussMD5 : F07373721D4DC99C769562427B1C6F3B
        CheckMD5   : FF7236A21E04C91934EAE2F409EAD6C7
        FixMD5     : B1E34DCC935F0488D74FFD96F8460B8D
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.user.security.exception.sites"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "" | Out-String
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($DeployFileContent -match $Key) {
                                                ForEach ($Line in $DeployFileContent) {
                                                    If ($Line -like "$($KeysToEval)*") {
                                                        $ExceptionPath = ($Line.Split("=")[1]).Trim()
                                                        Break
                                                    }
                                                }
                                                If ($ExceptionPath) {
                                                    $ExceptionFile = Format-JavaPath -Path $ExceptionPath -JavaFile exception.sites
                                                    If ($ExceptionFile.Pass -ne $true) {
                                                        $Compliant = $false
                                                        $FindingDetails += "" | Out-String
                                                        $FindingDetails += "$Line" | Out-String
                                                        $FindingDetails += "" | Out-String
                                                        $FindingDetails += "$($ExceptionFile.Formatted) - FINDING" | Out-String
                                                    }
                                                    Else {
                                                        $FindingDetails += "Exception File:`t`t$($ExceptionFile.Configured)" | Out-String
                                                        $FindingDetails += "" | Out-String
                                                        If ($ExceptionFile.Formatted.Split("/")[0, -1][1] -ne "exception.sites") {
                                                            $Compliant = $false
                                                            $FindingDetails += "$Key does NOT point to an 'exception.sites' file - FINDING" | Out-String
                                                        }
                                                        Else {
                                                            If (Test-Path $ExceptionFile.Formatted) {
                                                                $FindingDetails += "Exception file exists in the path defined." | Out-String
                                                            }
                                                            Else {
                                                                $Compliant = $false
                                                                $FindingDetails += "Exception file NOT found in the path defined - FINDING" | Out-String
                                                            }
                                                        }
                                                    }
                                                }
                                                Else {
                                                    $Compliant = $false
                                                    $FindingDetails += "" | Out-String
                                                    $FindingDetails += "Path to 'exception.sites' file is NOT defined in properties file - FINDING" | Out-String
                                                }
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "" | Out-String
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "" | Out-String
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234694 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234694
        STIG ID    : JRE8-WN-000150
        Rule ID    : SV-234694r617446_rule
        CCI ID     : CCI-001991
        Rule Name  : SRG-APP-000401
        Rule Title : Oracle JRE 8 must enable the dialog to enable users to check publisher certificates for revocation.
        DiscussMD5 : C3D8C5511483BF09893323791B8DFE96
        CheckMD5   : B3C20A52D5863216EE499BB854FE40B7
        FixMD5     : 9D0734F8F6C3FCA24CD845A37B0F0F7B
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.validation.crl=true", `
            "deployment.security.validation.crl.locked"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            $FindingDetails += "" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                                $FindingDetails += "$Key is present" | Out-String
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234695 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234695
        STIG ID    : JRE8-WN-000160
        Rule ID    : SV-234695r617446_rule
        CCI ID     : CCI-001991
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must lock the option to enable users to check publisher certificates for revocation.
        DiscussMD5 : 641C7784614699CE2C93D8CA2E495B55
        CheckMD5   : 69FD6048228D19D71C796DAC9E09DBEA
        FixMD5     : 95295612F60E641D17F03A3554121290
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.revocation.check=ALL_CERTIFICATES", `
            "deployment.security.revocation.check.locked"

        $ConfigResult = Test-ConfigFile
        $Compliant = $ConfigResult.Compliant
        ForEach ($Line in $ConfigResult.ResultText) {
            $FindingDetails += $Line | Out-String
        }
        $FindingDetails += "" | Out-String
        $FindingDetails += "------------------------------------------" | Out-String

        If (-Not($ConfigResult.ConfigFiles)) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found - FINDING" | Out-String
        }
        Else {
            ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
                $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
                $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                }
                Else {
                    # Get path to deployment.properties from .config file
                    $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                    ForEach ($Line in $ConfigFileContent) {
                        If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                            $PropsPath = ($Line.Split("=")[1]).Trim()
                            Break
                        }
                    }
                    If ($PropsPath) {
                        $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                        If ($PropsFile.Pass -ne $true) {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                        }
                        Else {
                            $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                            $FindingDetails += "" | Out-String
                            If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                                $Compliant = $false
                                $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                            }
                            Else {
                                If (Test-Path $PropsFile.Formatted) {
                                    $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                    If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                        $Compliant = $false
                                        $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                        $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                    }
                                    Else {
                                        $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                        ForEach ($Key in $KeysToEval) {
                                            If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                                $FindingDetails += "$Key is present" | Out-String
                                            }
                                            Else {
                                                $Compliant = $false
                                                $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                            }
                                        }
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                    }
                }
                $FindingDetails += "------------------------------------------" | Out-String
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234696 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234696
        STIG ID    : JRE8-WN-000170
        Rule ID    : SV-234696r617446_rule
        CCI ID     : CCI-002460
        Rule Name  : SRG-APP-000488
        Rule Title : Oracle JRE 8 must prompt the user for action prior to executing mobile code.
        DiscussMD5 : EB406C03E21F7D1CBE591AA7FDC219DE
        CheckMD5   : 99698508AC947007FC327449F5723040
        FixMD5     : D0F38D5725FC822140C02C022ECD214C
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.insecure.jres=PROMPT", `
        "deployment.insecure.jres.locked"

    $ConfigResult = Test-ConfigFile
    $Compliant = $ConfigResult.Compliant
    ForEach ($Line in $ConfigResult.ResultText) {
        $FindingDetails += $Line | Out-String
    }
    $FindingDetails += "" | Out-String
    $FindingDetails += "------------------------------------------" | Out-String

    If (-Not($ConfigResult.ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found - FINDING" | Out-String
    }
    Else {
        ForEach ($ConfigFile in $ConfigResult.ConfigFiles) {
            $FindingDetails += "Config File:`t`t$($ConfigFile.FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFile.FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFile.FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Format-JavaPath -Path $PropsPath -JavaFile deployment.properties
                    If ($PropsFile.Pass -ne $true) {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "$($PropsFile.Formatted) - FINDING" | Out-String
                    }
                    Else {
                        $FindingDetails += "Properties File:`t`t$($PropsFile.Configured)" | Out-String
                        $FindingDetails += "" | Out-String
                        If ($PropsFile.Formatted.Split("/")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "deployment.system.config does NOT point to a 'deployment.properties' file - FINDING" | Out-String
                        }
                        Else {
                            If (Test-Path $PropsFile.Formatted) {
                                $Encoding = Get-FileEncoding -Path $PropsFile.Formatted
                                If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                    $Compliant = $false
                                    $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows - FINDING." | Out-String
                                    $FindingDetails += "Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                                }
                                Else {
                                    $DeployFileContent = Get-Content -Path $PropsFile.Formatted
                                    ForEach ($Key in $KeysToEval) {
                                        If ($Key -in ($DeployFileContent -Replace "\s", "" -replace ".locked\s*=.*$",".locked")) {
                                            $FindingDetails += "$Key is present" | Out-String
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "$Key is NOT present - FINDING" | Out-String
                                        }
                                    }
                                }
                            }
                            Else {
                                $Compliant = $false
                                $FindingDetails += "Properties file NOT found in the path defined - FINDING" | Out-String
                            }
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is NOT defined in deployment.config - FINDING" | Out-String
                }
            }
            $FindingDetails += "------------------------------------------" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234697 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234697
        STIG ID    : JRE8-WN-000180
        Rule ID    : SV-234697r617446_rule
        CCI ID     : CCI-002605
        Rule Name  : SRG-APP-000456
        Rule Title : The version of Oracle JRE 8 running on the system must be the most current available.
        DiscussMD5 : 1A65A3F13B756E1A1094EFEA1913C357
        CheckMD5   : 73D1DCFC26D761464C4511F16DEC18A8
        FixMD5     : 342FFDCC86D141555A2D54F97E83C461
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $FindingDetails += "Java version information:`r`n" | Out-String
    $JrePaths = Get-JreInstallPath
    ForEach ($Path in $JrePaths) {
        If (Test-Path $(Join-Path $Path -ChildPath bin | Join-Path -ChildPath java.exe)) {
            $File = Get-ChildItem $(Join-Path $Path -ChildPath bin | Join-Path -ChildPath java.exe)
            $FindingDetails += "Path:`t`t$($File.FullName)" | Out-String
            $FindingDetails += "Version:`t$($File.VersionInfo.ProductVersion)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V234698 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234698
        STIG ID    : JRE8-WN-000190
        Rule ID    : SV-234698r617446_rule
        CCI ID     : CCI-002617
        Rule Name  : SRG-APP-000454
        Rule Title : Oracle JRE 8 must remove previous versions when the latest version is installed.
        DiscussMD5 : 1664F2CB47698D309E1F3C0682B43A4C
        CheckMD5   : D9DACA84A573EDCFE6560D4873ED4CA5
        FixMD5     : E9C4DC2493D4E29DD6CFA6A4A22D77F1
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $InstalledSoftwareVersions = Get-InstalledSoftware | Where-Object DisplayName -Match "Java 8" | Select-Object DisplayName, DisplayVersion

    If (($InstalledSoftwareVersions.DisplayVersion | Select-Object -Unique).Count -gt 1) {
        $Status = "Open"
        $FindingDetails += "Multiple versions of Java JRE are installed:" | Out-String
        ForEach ($Version in $InstalledSoftwareVersions) {
            $FindingDetails += $Version.Displayname + " ($($Version.DisplayVersion))" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "Java JRE version information:`r`n" | Out-String
        ForEach ($Version in $InstalledSoftwareVersions) {
            $FindingDetails += $Version.Displayname + " ($($Version.DisplayVersion))" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCAf3qdh3hmaeAr
# /8n5ckt4PnbCNUkMQ+TJBYtAn0XyZqCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIAFJjAHG
# W8Wn0HO/l17VTJKxRaY/vELwxwSvXe1lWb17MA0GCSqGSIb3DQEBAQUABIIBACGw
# pvMzElBpRFzkzeWxLf1XYG2BzmQZeXOGiMRoheekZEG3rRZGYPzLXm6Uca09s+Jr
# y4ZFRan1HFiXU0G0ogMZ+2aST75lfihPcLyYuVPSIjM1xdsB7fOKbYfoN+1rzlLc
# /uSm4ncBFYpNrvFx0Wen8C3sNk11qef8z8QaxIR7H/veCceyskhxqejs7wztamPi
# 8a+B/YT46wUDd/fRYT5Xizlz+Sun7naOZRA47N4VUQlGGY/osrrJr7FXwkkrUc5y
# Ctc2wQCpOzHWo7+uQc4IH48DW2s/1BQCqufm1bHMdfNNon/OhUdVpp6SlEQtfzaT
# 7u45MhaQ7DAAmeXbnhmhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNDA3MTI1NTU2WjAv
# BgkqhkiG9w0BCQQxIgQg+YFTe0r/OVO8OJWm/olTzJXZjDy53YhK6Aw6hTM9XdQw
# DQYJKoZIhvcNAQEBBQAEggIAlNAyfqPzplyR22uafbvuoqY1IpG1yF4M0UDmyxwk
# 2esaKMBUR5fot0FEv8n6Mpkkt/1bTZemr13J8psGo90CTKiCPuq9wNua8JPB7iyq
# h/fWLf7uXIffSOdePs4aRIOwvyhP+NzajUsC54zgicwr333ydwsOEMbX6WtUUlP8
# rsGgZeme5Gu2+y01vdIpUVket0BWcLr0Oalm9DYzZm+z5g4Ujg2FMuWGp2fctiXJ
# OaVlZITjPBsscZDLeQkOD315QfcOeXgGtSdsEVzVnF+flsMm6G23UBqs+I5Kudj4
# C+ABibu5rmNIiOD/o1g8tN9F+Jw0rA7d0RZLdl32TF52c6Actpef/ixXlJSzU4YP
# R3oYjbo7OJsnrDsNFPLhK2FTHmXMVV8LR2vqH3w4csoLPzIcNgUKF8rU4ngDhJ2x
# G8dUxKApqCgkE7J2uc3up5t+aps+S+hHCZKeGD1g8ipDfydYz/yUVo9c95YKCSyP
# zTpRZ2trvXPmZlY2gMce4pWCZe+ELUZ8lD5rmIHqNDDeA3iQmcyisVFUeOcCKS7Z
# gal4gZ7SdSxgyQOs0FkMRdb+fuyP4cihUXD37X0B183jjnNPM3AfnvQYJDoKsihs
# naDEjThc+6UfsrODNoGiQtrG+yKUDmOomLc1xCdCPrGwEnBxEiB+RQV/q3ymNEqB
# W5w=
# SIG # End signature block
