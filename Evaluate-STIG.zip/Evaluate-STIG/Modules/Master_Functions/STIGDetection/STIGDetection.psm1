##############################################
# STIG detection functions for Evaluate-STIG #
##############################################

Function Test-IsActiveDirectoryInstalled {
    # Active Directory detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Domain", "Forest")]
        [string]$Level
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Level) {
                "Domain" {
                    If ((Get-DomainRoleStatus -ExpectedRole "Primary Domain Controller").BoolMatchExpected) {
                        $STIGRequired = $true
                    }
                }
                "Forest" {
                    If ((Get-DomainRoleStatus -ExpectedRole "Primary Domain Controller").BoolMatchExpected -and ((Get-ADDomain).DNSRoot -eq (Get-ADDomain).Forest)) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsAdobeProReaderInstalled {
    # Adobe Acrobat Pro and Reader detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Pro", "Reader")]
        [string]$Edition,

        [Parameter(Mandatory)]
        [ValidateSet("XI", "Classic", "Continuous")]
        [string]$Track
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Edition) {
                "Pro" {
                    Switch ($Track) {
                        "XI" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Version -eq "XI"}) {
                                $STIGRequired = $true
                            }
                        }
                        "Classic" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Track -eq "Classic" -and $_.Version -in @("2015", "2017", "2020")}) {
                                $STIGRequired = $true
                            }
                        }
                        "Continuous" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Track -eq "Continuous" -and $_.Version -eq "DC"}) {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
                "Reader" {
                    Switch ($Track) {
                        "Classic" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Reader*" -and $_.Track -eq "Classic" -and $_.Version -in @("2015", "2017", "2020")}) {
                                $STIGRequired = $true
                            }
                        }
                        "Continuous" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Reader*" -and $_.Track -eq "Continuous" -and $_.Version -eq "DC"}) {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsApacheInstalled {
    # Apache 2.4 detection
    Param (
        [Parameter(Mandatory)]
        [string] $OnOS
    )

    $STIGRequired = $false
    Try {
        If ($OnOS -eq "Unix") {
            If (-not ($IsLinux)) {
                Return $STIGRequired
            }

            $ExecutablePids = Get-ApacheUnixExecutablePids
            If (($ExecutablePids | Measure-Object).Count -gt 0) {
                $STIGRequired = $True
            }

            Return $STIGRequired
        }
        ElseIf ($OnOS -eq "Windows") {
            If ($IsLinux) {
                Return $STIGRequired
            }

            $Services = Get-CimInstance -ClassName win32_service
            If ($null -eq $Services) {
                Return $STIGRequired
            }

            $stoppedServices = @()

            Foreach ($service in $Services) {
                $PathName = $service.PathName
                $Path = ($PathName -split '"')[1]
                If ($null -eq $Path -or $Path -eq "") {
                    # If a path can't be parsed (because we know what it looks like) ignore.
                    Continue
                }

                If (-not (Test-Path -Path $Path -PathType Leaf)) {
                    # If a path is parsed and it doesn't lead to a file, ignore.
                    Continue
                }

                $Extension = (Get-ItemProperty -Path $Path -Name Extension).Extension
                If ($Extension -ne '.exe') {
                    # If the file is not an .exe, ignore.
                    Continue
                }

                $VersionInfo = (Get-Item -Path $Path).VersionInfo;
                $FileDescription = $VersionInfo.FileDescription;
                If ($FileDescription -notlike "*Apache*HTTP*Server") {
                    # If the file descriptor is not anything related to apache server, ignore.
                    Continue
                }

                $Param = '-v'
                $VersionOutput = (& "$($Path)" $Param)
                If ($VersionOutput | Select-String -Pattern '2.4' -Quiet) {
                    # If we get no version as output or if the version is incorrect, ignore.

                    if ($service.State -notmatch 'Running') {
                        # If service is not running, ignore.
                        $stoppedServices += $service.DisplayName
                    }
                    else {
                        $STIGRequired = $true
                    }
                }
            }
            if ($stoppedServices.Length -gt 0) {
                Write-Host "ERROR: Apache detected, but service(s) ($($stoppedServices -join ", ")) are not running. Please start service and scan again." -ForegroundColor Red -BackgroundColor Black
            }
        }
        Return $STIGRequired
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsTomcatInstalled {
    # Apache Tomcat Application Server detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsTomcatRunning = 0

            If ((Get-Process).ProcessName -match "tomcat") {
                $IsTomcatRunning += 1
            }

            Get-Process | ForEach-Object {
                If (($_.Name -match "^java\d{0,}\b") -and ($_.CommandLine -match "catalina.base|catalina.home")) {
                    $IsTomcatRunning += 1
                }
            }

            If ($IsTomcatRunning -gt 0) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsArcGISInstalled {
    # ArcGIS Server 10.3 detection
    $STIGRequired = $false
    Try {
        If (($PsVersionTable.PSVersion).ToString() -match "5.*") {
            $IsArcGISInstalled = (Get-WmiObject Win32_Process -Filter "Name= 'ArcGISServer.exe'" | ForEach-Object {Write-Output "$($_.Name)"})
        }
        Else {
            $IsArcGISInstalled = ((Get-Process).ProcessName -Match "ArcGIS\s?Server" )
        }

        If ($IsArcGISInstalled) {
            $STIGRequired = $true
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsCisco {
    # Cisco detection
    Param (
        [Parameter(Mandatory)]
        [psobject]$DeviceInfo,

        [Parameter(Mandatory)]
        [ValidateSet("Router", "Switch")]
        [string]$DeviceType,

        [Parameter(Mandatory)]
        [ValidateSet("XE")]
        [string]$CiscoOS
    )

    $STIGRequired = $false
    Try {
        If ($DeviceInfo | Where-Object {($_.DeviceType -eq $DeviceType -and $_.CiscoOS -match $CiscoOS)}) {
            $STIGRequired = $true
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsChromeInstalled {
    # Google Chrome detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-InstalledSoftware | Where-Object DisplayName -EQ "Google Chrome") -or (Get-ChildItem -Path $env:ProgramFiles\Google\Chrome -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "chrome.exe") -or (Get-ChildItem -Path ${env:ProgramFiles(x86)}\Google\Chrome -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "chrome.exe")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsCitrixWorkspaceInstalled {
    # Citrix Workspace detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-InstalledSoftware | Where-Object DisplayName -Match "Citrix Workspace") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsIISInstalled {
    # Microsoft IIS detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("10.0", "8.5")]
        [string]$Version
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-WindowsFeatureState | Where-Object {$_.Name -in @("Web-WebServer", "IIS-WebServer") -and $_.Enabled -eq $true}) {
                Switch ($Version) {
                    "10.0" {
                        If (Test-Path "HKLM:\SOFTWARE\Microsoft\InetStp") {
                            $InetStp = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp"
                            [Version]$IISVersion = "$(($InetStp).MajorVersion).$(($InetStp).MinorVersion)"
                            If ($IISVersion -ge [Version]"10.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "8.5" {
                        If (Test-Path "HKLM:\SOFTWARE\Microsoft\InetStp") {
                            $InetStp = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp"
                            [Version]$IISVersion = "$(($InetStp).MajorVersion).$(($InetStp).MinorVersion)"
                            If ($IISVersion -ge [Version]"8.5" -and $IISVersion -lt [Version]"10.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsIE11Installed {
    # Internet Explorer 11 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $Paths = @("$env:ProgramFiles", "${env:ProgramFiles(x86)}")
            ForEach ($Path in $Paths) {
                If ([Version](Get-ChildItem "$Path\Internet Explorer\iexplore.exe" -ErrorAction SilentlyContinue).VersionInfo.ProductVersion -ge "11.0") {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsJBossInstalled {
    # JBoss EAP 6.3 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsJBossInstalled = (ps -ef | grep -i jboss.home.dir | grep -v grep)
            If ($IsJBossInstalled) {
                $STIGRequired = $true
            }
        }
        Else {
            If (($PsVersionTable.PSVersion).ToString() -match "5.*") {
                $IsJBossInstalled = (Get-WmiObject Win32_Process -Filter "Name= 'java.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
                        If ($_.CommandLine | Select-String -Pattern "jboss.home.dir") {
                            Write-Output "$($_.CommandLine)}"
                        }})
            }
            Else {
                $IsJBossInstalled = (Get-Process -Name "java" -ErrorAction SilentlyContinue | ForEach-Object {
                        If ($_.CommandLine | Select-String -Pattern "jboss.home.dir") {
                            Write-Output "$($_.Id) $($_.CommandLine)}"
                        }})
            }

            If ($IsJBossInstalled) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMcAfeeVS88Installed {
    # McAfee VirusScan 8.8 Local Client detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ((Get-CimInstance Win32_OperatingSystem).OSArchitecture) {
                "64-bit" {
                    If ((Get-InstalledSoftware | Where-Object {($_.DisplayName -eq "McAfee VirusScan Enterprise") -and ([Version]$_.DisplayVersion -ge "8.8")}) -and ((Get-RegistryResult -Path "HKLM:\SOFTWARE\WOW6432Node\Network Associates\ePolicy Orchestrator\Agent" -ValueName "ePOServerList").Value -in @("(blank)", "(NotFound)"))) {
                        $STIGRequired = $true
                    }
                }
                "32-bit" {
                    If ((Get-InstalledSoftware | Where-Object {($_.DisplayName -eq "McAfee VirusScan Enterprise") -and ([Version]$_.DisplayVersion -ge "8.8")}) -and ((Get-RegistryResult -Path "HKLM:\SOFTWARE\Network Associates\ePolicy Orchestrator\Agent" -ValueName "ePOServerList").Value -in @("(blank)", "(NotFound)"))) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsDotNET4Installed {
    # Microsoft .NET Framework 4 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -ErrorAction SilentlyContinue).Install -eq 1) -or ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue).Install -eq 1)) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSOfficeInstalled {
    # Microsoft Office detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2013", "2016", "O365")]
        [string]$Version,

        [ValidateSet("Common", "Access", "Excel", "Groove", "InfoPath", "Lync", "OneNote", "Outlook", "PowerPoint", "Project", "Publisher", "Skype", "Visio", "Word")]
        [array]$Component
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Version) {
                "2013" {
                    $MinVer = [Version]"15.0.4420.1017"
                    $NextVer = [Version]"16.0.4229.1003"
                    $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\15.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0")
                }
                "2016" {
                    $MinVer = [Version]"16.0.4229.1003"
                    $NextVer = [Version]"16.0.10336.20039"
                    $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                }
                "O365" {
                    $MinVer = [Version]"16.0.10336.20039"
                    If ($Component) {
                        $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                    }
                    Else {
                        $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\ClickToRun\Configuration")
                        ForEach ($Path in $RegPaths) {
                            [Version]$VersionToReport = (Get-ItemProperty -Path "$Path" -Name "VersionToReport" -ErrorAction SilentlyContinue).VersionToReport
                            If ($VersionToReport -ge $MinVer) {
                                $STIGRequired = $true
                            }
                        }
                        If ($STIGRequired -eq $true) {
                            Return $STIGRequired
                        }
                        Else {
                            $Component = @("Access", "Excel", "Lync", "Outlook", "PowerPoint", "Publisher", "Word", "Visio", "Project")
                            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                        }
                    }
                }
            }
            ForEach ($Item in $Component) {
                Switch ($Item) {
                    "Common" {
                        $Executable = "CLVIEW.EXE"
                    }
                    "Access" {
                        $Executable = "MSACCESS.EXE"
                    }
                    "Excel" {
                        $Executable = "EXCEL.EXE"
                    }
                    "Groove" {
                        $Executable = "GROOVE.EXE"
                    }
                    "InfoPath" {
                        $Executable = "INFOPATH.EXE"
                    }
                    {$_ -in @("Lync", "Skype")} {
                        $Executable = "LYNC.EXE"
                        If ($Version -ne "O365") {
                            ForEach ($Path in $RegPaths) {
                                If (Get-ChildItem -Path $Path -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "Lync" -and $_.Property -eq "InstallationDirectory")}) {
                                    $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath "Lync")).InstallationDirectory -ChildPath $Executable)
                                    [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                                    If ($NextVer) {
                                        If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                                            $STIGRequired = $true
                                        }
                                    }
                                }
                            }
                            Return $STIGRequired
                        }
                    }
                    "OneNote" {
                        $Executable = "ONENOTE.EXE"
                    }
                    "Outlook" {
                        $Executable = "OUTLOOK.EXE"
                    }
                    "PowerPoint" {
                        $Executable = "POWERPNT.EXE"
                    }
                    "Project" {
                        $Executable = "WINPROJ.EXE"
                    }
                    "Publisher" {
                        $Executable = "MSPUB.EXE"
                    }
                    "Visio" {
                        $Executable = "VISIO.EXE"
                    }
                    "Word" {
                        $Executable = "WINWORD.EXE"
                    }
                }

                ForEach ($Path in $RegPaths) {
                    If (Get-ChildItem -Path "$Path\$Item" -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "InstallRoot" -and $_.Property -eq "Path")}) {
                        $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath $Item | Join-Path -ChildPath "InstallRoot")).Path -ChildPath $Executable)
                        If (Test-Path -Path $ExecutablePath) {
                            [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                            If ($NextVer) {
                                If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                                    $STIGRequired = $true
                                }
                            }
                            Else {
                                If ($ProductVersion -ge $MinVer) {
                                    $STIGRequired = $true
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }
    Return $STIGRequired
}

Function Test-IsMSOneDriveInstalled {
    # Microsoft OneDrive detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $ProductKey = "Groove"
            $Executable = "GROOVE.EXE"
            $MinVer = [Version]"16.0.4229.1003"
            $NextVer = [Version]"16.0.10336.20039"
            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
            ForEach ($Path in $RegPaths) {
                If (Get-ChildItem -Path "$Path\$ProductKey" -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "InstallRoot" -and $_.Property -eq "Path")}) {
                    $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath $ProductKey | Join-Path -ChildPath "InstallRoot")).Path -ChildPath $Executable)
                    If (Test-Path -Path $ExecutablePath) {
                        [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                        If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                            $STIGRequired = $true
                        }
                    }
                }
            }

            If ($STIGRequired -eq $false) {
                If ((Test-Path "$env:ProgramFiles\Microsoft OneDrive\OneDrive.exe") -or (Test-Path "$(${env:ProgramFiles(x86)})\Microsoft OneDrive\OneDrive.exe") -or (Test-Path "$((Get-UsersToEval -ProvideSingleUser).LocalPath)\AppData\Local\Microsoft\OneDrive\OneDrive.exe")) {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsSharePointDesignerInstalled {
    # Microsoft SharePoint Designer 2013 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-InstalledSoftware | Where-Object DisplayName -Like "Microsoft SharePoint Designer 2013*") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsSharePoint2013Installed {
    # Microsoft SharePoint Server 2013+ detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-InstalledSoftware | Where-Object {$_.DisplayName -Match "SharePoint Server" -and $_.DisplayVersion -ge [Version]"15.0"}) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSDefenderInstalled {
    # Microsoft Defender Antivirus detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-Service WinDefend -ErrorAction Stop) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSEdgeInstalled {
    # Microsoft Edge detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-InstalledSoftware | Where-Object DisplayName -EQ "Microsoft Edge") -or (Get-ChildItem -Path $env:ProgramFiles\Microsoft\Edge -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "msedge.exe") -or (Get-ChildItem -Path ${env:ProgramFiles(x86)}\Microsoft\Edge -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "msedge.exe")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSExchangeRoleInstalled {
    # Microsoft Exchange detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2016", "2019")]
        [string]$Version,

        [Parameter(Mandatory)]
        [ValidateSet("Edge", "Mailbox")]
        [string]$Role
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Version) {
                "2016" {
                    $MinVer = [Version]"15.1"
                    $NextVer = [Version]"15.2"
                }
                "2019" {
                    $MinVer = [Version]"15.2"
                }
            }

            Switch ($Role) {
                "Edge" {
                    $RegPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\V15\EdgeTransportRole"
                }
                "Mailbox" {
                    $RegPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\V15\MailboxRole"
                }
            }

            [Version]$Version = (Get-ItemProperty $RegPath -ErrorAction SilentlyContinue).ConfiguredVersion
            If ($NextVer) {
                If ($Version -ge $MinVer -and $Version -lt $NextVer) {
                    $STIGRequired = $true
                }
            }
            Else {
                If ($Version -ge $MinVer) {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSSQLInstalled {
    # Microsoft SQL Server detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2014", "2016")]
        [string]$Version
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server", "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Microsoft SQL Server")
            ForEach ($Path in $RegPaths) {
                $Instances = (Get-ItemProperty $Path -ErrorAction SilentlyContinue).InstalledInstances
                ForEach ($Instance in $Instances) {
                    $InstanceName = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -ErrorAction SilentlyContinue).$Instance
                    $InstanceInfo = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstanceName\Setup" -ErrorAction SilentlyContinue
                    Switch ($Version) {
                        "2014" {
                            If (($InstanceInfo).Edition -notlike "*Express*" -and [Version]($InstanceInfo).Version -like "12.*") {
                                $STIGRequired = $true
                            }
                        }
                        "2016" {
                            If ([Version]($InstanceInfo).Version -ge "13.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMongoDB3Installed {
    # MongoDB 3.x detection
    $STIGRequired = $false
    Try {
        $MongoProcess = Get-Process -Name 'mongo?'
        If ($null -ne $MongoProcess.Path) {
            $MongoDBVersionInfo = (& $MongoProcess.Path --version)
            $IsDB3 = $MongoDBVersionInfo | Select-String -Pattern "db\s*version\s*v3.*"
            $IsEnterprise = $MongoDBVersionInfo | Select-String -Pattern "modules:\s*enterprise"
            If ($null -ne $IsDB3 -and $null -ne $IsEnterprise) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsFirefoxInstalled {
    # Mozilla Firefox detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $FirefoxCheck = Get-Firefox
            if ($FirefoxCheck | Where-Object {$_.Exists -eq $true}) {
                $STIGRequired = $true
            }
        }
        Else {
            If (Get-InstalledSoftware | Where-Object DisplayName -Like "Mozilla Firefox*") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsJavaJRE8Installed {
    # Oracle Java JRE 8 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $Command = "java -version 2$([Char]62)$([Char]38)1 | Out-String"
            $JavaVer = Invoke-Expression $Command -ErrorAction SilentlyContinue
            If ($JavaVer -like "java*SE Runtime Environment*1.8.0*") {
                $STIGRequired = $true
            }
        }
        Else {
            If ((Get-DomainRoleStatus -ExpectedRole "Standalone Workstation", "Member Workstation").BoolMatchExpected -and (Get-InstalledSoftware | Where-Object DisplayName -Like "Java 8*")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsPostgresInstalled {
    # PostgreSQL detection
    $STIGRequired = $false

    Try {
        if ($IsLinux) {
            $PostgresProcesses = (ps f -opid','ppid','cmd -C 'postgres,postmaster' --no-headers)
            if ($null -ne $PostgresProcesses) {
                if (grep Ubuntu /etc/os-release) {
                    $PGInstalls = (apt list 2>/dev/null | grep postgres | grep -v Crunchy | grep -v edb)
                }
                else {
                    $PGInstalls = (rpm -qa 2> /dev/null | grep postgres | grep -v Crunchy | grep -v edb)
                }
                if ($null -ne $PGInstalls) {
                    $STIGRequired = $true
                }
            }
        }
        else {
            If (Get-InstalledSoftware | Where-Object {$_.DisplayName -match "^PostgreSQL" -and $_.Publisher -match "PostgreSQL Global Development Group" -and [int]($_.DisplayVersion -Replace "[^\d\.]", "" -split "\.")[0] -ge 9}) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsRKE2Installed {
    # Rancher Government Solutions RKE2 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            If ((Get-Process).ProcessName -match "rke2 agent|rke2 server") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsTrellixInstalled {
    # Trellix ENS 10x Local detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsTrellixInstalled = ((Get-TrellixOptDirs | Measure-Object).Count -ge 1)
            $IsENSInstalled = (((find /opt -type d -name ens) | Measure-Object).Count -ge 1)
            If ($IsTrellixInstalled -eq $true -and $IsENSInstalled -eq $true) {
                $Parameters = "-i"
                $Exec = (find /opt -type f -name cmdagent)
                $AgentModeString = (Invoke-Expression "$($Exec) $($Parameters)") | Select-String -Pattern AgentMode -Raw
                If ($null -ne $AgentModeString -and $AgentModeString -ne "") {
                    $AgentMode = ($AgentModeString.Split(":")[1]).Trim()
                    If ($AgentMode -eq "0") {
                        $STIGRequired = $true
                    }
                }
            }
        }
        Else {
            $RegistryPath = "HKLM:\SOFTWARE\McAfee\Endpoint\Common"
            $RegistryValueName = "ProductVersion"
            $IsVersionTenPlus = ((Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName).Value -Like "10.*")
            If ($IsVersionTenPlus -eq $true) {
                $RegistryPath = "HKLM:\SOFTWARE\WOW6432Node\McAfee\Agent"
                $RegistryValueName = "AgentMode"
                $AgentMode = (Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName).Value
                If ($null -eq $AgentMode -or $AgentMode -eq "(NotFound)") {
                    $STIGRequired = $true
                }
                Else {
                    $IsAgentModeZero = ($AgentMode -eq "0")
                    If ($IsAgentModeZero -eq $true) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsVMwareHorizonInstalled {
    # VMware Horizon 7.13 detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Agent", "Client", "ConnectionServer")]
        [string]$Component
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Component) {
                "Agent" {
                    $DisplayName = "VMware Horizon Agent"
                    $DisplayVersion = "7"
                }
                "Client" {
                    $DisplayName = "VMware Horizon Client"
                    $DisplayVersion = "5"
                }
                "ConnectionServer" {
                    $DisplayName = "VMware Horizon 7 Connection Server"
                    $DisplayVersion = "7"
                }
            }
            If (Get-InstalledSoftware | Where-Object {$_.DisplayName -eq $DisplayName -and $_.DisplayVersion -like "$($DisplayVersion).*"}) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsWinDNSServer {
    # Windows DNS Server detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-Service DNS -ErrorAction SilentlyContinue) -and ((Test-IsRunningOS -Version WinServer2016) -or (Test-IsRunningOS -Version WinServer2019) -or (Test-IsRunningOS -Version WinServer2022) -or (Test-IsRunningOS -Version WinServer2025))) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsWinFirewallInstalled {
    # Windows Firewall detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ([Version](Get-CimInstance Win32_OperatingSystem).Version -ge [Version]"6.1") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

function Test-IsContainerProcess {
    param (
        [Parameter(Mandatory = $True)]
        [int]$ProcessId
    )

    $IsContainer = $false

    if ($ProcessId -gt 1) {
        $ProcessCommandLine = Get-ProcessCommandLine -ProcessId $ProcessId
        $ContainerProcess = $ProcessCommandLine -match '\bcontainerd-shim\b|\bconmon\b'

        if ($null -ne $ContainerProcess -and $ContainerProcess -ne "") {
            $IsContainer = $true
        }
    }

    return $IsContainer
}

Function Test-IsRunningOS {
    # Operating system detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Oracle7", "Oracle8", "Oracle9", "RHEL7", "RHEL8", "RHEL9", "Ubuntu16", "Ubuntu18", "Ubuntu20", "Ubuntu22", "Ubuntu24", "Win7", "Win10", "Win11", "WinServer2008R2", "WinServer2012", "WinServer2016", "WinServer2019", "WinServer2022", "WinServer2025")]
        [string]$Version
    )

    # Expose addtional dynamic parameters
    DynamicParam {
        $ParamDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

        If ($Version.Trim() -match "^WinServer") {
            # Expose -IsDC
            $Attributes = New-Object System.Management.Automation.ParameterAttribute
            $Attributes.Mandatory = $false
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            $AttributeCollection.Add($Attributes)
            $IsDCParam = New-Object System.Management.Automation.RuntimeDefinedParameter("IsDC", [Switch], $AttributeCollection)
            $ParamDictionary.Add("IsDC", $IsDCParam)
        }

        Return $ParamDictionary
    }

    Process {
        $STIGRequired = $false
        Try {
            If ($IsLinux) {
                $OSRelease = Get-Content /etc/os-release -ErrorAction SilentlyContinue
                Switch ($Version) {
                    "Oracle7" {
                        If ($OSRelease -like '*NAME="Oracle Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Oracle8" {
                        If ($OSRelease -like '*NAME="Oracle Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Oracle9" {
                        If ($OSRelease -like '*NAME="Oracle Linux*' -and $OSRelease -like '*VERSION_ID="9.*') {
                            $STIGRequired = $true
                        }
                    }
                    "RHEL7" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="CentOS Linux*' -and $OSRelease -like '*VERSION_ID="7*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "RHEL8" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "RHEL9" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="9.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="9.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "Ubuntu16" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="16.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu18" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="18.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu20" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="20.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu22" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="22.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu24" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="24.*') {
                            $STIGRequired = $true
                        }
                    }
                }
            }
            Else {
                If ($PsBoundParameters.IsDC) {
                    $IsDC = "{0}" -f $PsBoundParameters.IsDC
                }
                $Caption = (Get-CimInstance Win32_OperatingSystem).Caption
                Switch ($Version) {
                    "Win7" {
                        If ($Caption -Like "*Windows 7*") {
                            $STIGRequired = $true
                        }
                    }
                    "Win10" {
                        If ($Caption -Like "*Windows 10*") {
                            $STIGRequired = $true
                        }
                    }
                    "Win11" {
                        If ($Caption -Like "*Windows 11*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2008R2" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2008 R2*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2008 R2*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2012" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2012*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2012*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2016" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2016*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2016*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2019" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2019*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2019*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2022" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2022*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2022*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2025" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2025*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2025*") {
                            $STIGRequired = $true
                        }
                    }
                }
            }
        }
        Catch {
            Return $STIGRequired
        }

        Return $STIGRequired
    }
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD5W1tzUysQvTTI
# AYhFKVn6Kg+Ywbzw7/VVZ6gwIgjqS6CCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEYVCdL0
# gR0Q3/jipDLEG744Gii/CWWYcktUxx4l9yPHMA0GCSqGSIb3DQEBAQUABIIBAAiG
# e1B0hm9+CYJslHozqobgI5ebdvL/Xy2I1OQbnA9WCTn52hdG3J6OilkEcSeH13AW
# gvLdpr3Pp7qLGEppFJqImxIxLzQAR/Acno/rjHSbi4Jg6TTtMOv+9b9Kvm7WrG+a
# xGPsipOTRxkHlzu5cwuQ2HTLWM2iMntTefazirl/VxJV35d7Q1fF8rUBCzyk22F+
# ReY8Nty4fnw9ySQRaPZC8ev+BRh6EHM+pDTi70zq7InR1A0FKp+HLPcVmO4DnnpX
# k+HyZitDa+5JVwfhTpDfkhHE49XULPcR+2eW1TsEO6lwA/zgZBwtN9veXoQWEZq/
# 7XqyKo9IHUD5GeXOPvihggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNTA3MTQwMDQ2WjAv
# BgkqhkiG9w0BCQQxIgQgdgx1EBKa2sds/YB5eVKjC3G/ZBha9h//X2VNmRLs7UEw
# DQYJKoZIhvcNAQEBBQAEggIADqrTo6MP5xWC6stch/DBiNH20XcVch/VDax/0PpE
# 3vz/OZYIBnCdmFutKiTIcEUv/TzF3bq9ruKXzR+lnTn8bdtwOemb5OklhlxtrIYG
# ThoOuq670W6Fzj+Slmk6/u8Kj4eeuUCEkbsCw7JITfEWmKQWCeavCqiSr4+0+49m
# A+Q9FxXqXuZj8EZv5USoXsU0Sd0TyU8nckCsv/FEkjbD5WuOHN+UJbQCicA36UD4
# x7+YTAEyCgMqzNwadS2tRA94bj8ooYxrphjm23iT4TcsmDs5MVQPoKzLKoAsnJ4z
# asiEyfUzHtCwX6vG513iszEHgyiTopzEJ0Q1AZIjYlXU+Fl5u00V5be0ax5YygcY
# 5z1n0L1BDnetA7xS0B3/DRAwQcVFXgYX5HhJkrCAXpJLqs4HYa33kPXrBRkXDw9/
# wax+CghWPzPDGA3AKyBns+2LRiHtPrqIs2frKCgK6WlkhcKlHLDqwnw1hQbsLTCr
# X7gioMNUafHqdSyEIyN7sdNqYz5qYPVMfbnOGVJhLVYQghTd5BLxlJn57mboSiXw
# c2GwGSswAFQT7KZeZQ2qyXCOTKQ33w28JFBFuPIvuKGsoD+Vmd3d1WUCjuPmkmJe
# b6q6Y9vhdANJuCdHTBoUlPDlVbKVZ3fN9ofcoHh6gkF5n1cKhHb9BETbHhKy89NW
# GlE=
# SIG # End signature block
