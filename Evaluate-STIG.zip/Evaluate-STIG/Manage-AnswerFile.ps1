<#
    .Synopsis
    Check and modify Answer File.
    .DESCRIPTION
    Generates a list of Vuln IDs from CKL and compares them with an Answer File.  The Answer File can then be edited.
    .EXAMPLE
    PS C:\> Manage-AnswerFile.ps1
#>

Function ConvertTo-CSVReport {
  $AnswerFileData = New-Object System.Collections.Generic.List[System.Object]
  $AnswerFileData = Foreach ($Vuln in $AFItems){
    Foreach ($AK in $Vuln.AnswerKeys){
      New-Object psobject -Property ([ordered]@{
        VulnID            = $Vuln.VulnID
        AnswerKey         = $AK.AnswerKey
        ExpectedStatus    = $AK.ExpectedStatus
        ValidationCode    = $AK.ValidationCode
        ValidTrueStatus   = $AK.ValidTrueStatus
        ValidTrueComment  = $AK.ValidTrueComment
        ValidFalseStatus  = $AK.ValidFalseStatus
        ValidFalseComment = $AK.ValidFalseComment
      })
    }
  }
  $AnswerFileData | Export-Csv -Path "$($AFFilePath.replace('.xml','')).csv" -NoTypeInformation
}
Function ConvertTo-HTMLReport {
      [xml]$AFTransform = @'
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
     <xsl:template match="/STIGComments">
          <html>
               <head>
                    <style type="text/css">
                         .styled-table {
                              border-collapse: collapse;
                              margin: 25px 0;
                              font-size: 0.9em;
                              font-family: sans-serif;
                              min-width: 400px;
                              box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                              width: 100%
                         }
                         .styled-table thead tr {
                              background-color: #2E86C1;
                              color: #ffffff;
                              text-align: left;
                         }
                         .styled-table th,
                         .styled-table td {
                              padding: 12px 15px;
                         }
                         .styled-table tbody tr {
                              border-bottom: thin solid #dddddd;
                         }
                         .styled-table tbody tr:last-of-type {
                              border-bottom: 2px solid #3498DB;
                         }
                         .styled-table tbody tr.active-row {
                              font-weight: bold;
                              color: #3498DB;
                         }
                         .hidden {
                              visibility: hidden;
                         }
                         .button {
                              color: #494949 !important;
                              text-align: center;
                              text-transform: uppercase;
                              text-decoration: none;
                              backgrond: #AED6F1;
                              background-color: #AED6F1;
                              padding: 20px;
                              border: 4px solid #494949 !important;
                              display: inline-block;
                              transition: all 0.4s ease 0s;
                              width: 250px;
                              height: 20px;
                              margin: 5px;
                         }
                         .stig_button {
                              color: #494949 !important;
                              text-align: center;
                              text-transform: uppercase;
                              text-decoration: none;
                              backgrond: #ffffff;
                              padding: 20px;
                              border: 4px solid #494949 !important;
                              display: inline-block;
                              transition: all 0.4s ease 0s;
                              width: 450px;
                              height: 10px;
                         }
                         .button:hover{
                              color: #ffffff !important;
                              background: #f6b93b;
                              border-color: #f6b93b !important;
                              transition: all 0.4s ease 0s;
                              cursor: pointer;
                         }
                         .stig_button:hover{
                              color: #ffffff !important;
                              background: #f6b93b;
                              border-color: #f6b93b !important;
                              transition: all 0.4s ease 0s;
                              cursor: pointer;
                         }
                         #topbtn{
                              position: fixed;
                              bottom: 20px;
                              right: 30px;
                              z-index: 99;
                              font-size: 18px;
                              border: none;
                              outline: none;
                              background-color: red;
                              color: white;
                              cursor: pointer;
                              padding: 15px;
                              border-radius: 4px;
                         }
                         #topbtn:hover{
                              background-color: #555;
                         }
                         code {
                             background-color: #eef;
                             display: block;
                         }
                    </style>
                    <script>
                         var topbutton = document.getElementById("topbtn");
                         window.onscroll = function() {scrollFunction()};

                         function scrollFunction() {
                              if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                                   topbutton.style.display = "block";
                              } else {
                                   topbutton.style.display = "none";
                              }
                         }
                         function topFunction() {
                              document.body.scrollTop = 0;
                              document.documentElement.scrollTop = 0;
                         }
                         function change(table_value) {
                              var x = document.getElementById(table_value);
                              if (x.style.display === "none") {
                                   x.style.display = "table";
                              } else {
                                   x.style.display = "none";
                              }
                         }
                    </script>
               </head>
               <body>
                    <button onclick="topFunction()" id="topbtn" title="Go to Top">Top</button>
                    <h1 align="center"><xsl:value-of select="@Name" /> STIG Answer File</h1>
                    <p><!--**************************************************************************************<br />
                        <b>This file contains answers for known opens and findings that cannot be evaluated through technical means.<br />
                        <b>&lt;STIGComments Name&gt;</b> must match the STIG name in STIGList.xml.  When a match is found, this answer file will automatically for the STIG.<br />
                        <b>&lt;Vuln ID&gt;</b> is the STIG VulnID.  Multiple Vuln ID sections may be specified in a single Answer File.<br />
                        <b>&lt;AnswerKey Name&gt;</b> is the name of the key assigned to the answer.  "DEFAULT" can be used to apply the comment to any asset.  Multiple AnswerKey Name sections may be configured within a single Vuln ID section.<br />
                        <b> *Note: If the Answer Key matches the hostname *exactly*, it will supersede any other key for the Vulnerability ID.<br />
                        <b>  Multiple hostnames can be used, separated by either a space or a comma.<br />
                        <b>&lt;ExpectedStatus&gt;</b> is the initial status after the checklist is created.  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".<br />
                        <b>&lt;ValidationCode&gt;</b> must be Powershell code that returns a True/False value.  If blank, "true" is assumed.<br />
                        <b> *Note: If Validation Code returns a PSCustomObject, the Object MUST contain both "Results" and "Valid" keys.  "Results" will be written to the Comments field of the STIG check.<br />
                        <b>&lt;ValidTrueStatus&gt;</b> is the status the check should be set to if ValidationCode returns "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <b>&lt;ExpectedStatus&gt;</b> is assumed.<br />
                        <b>&lt;ValidTrueComment&gt;</b> is the verbiage to add to the Comments section if ValidationCode returns "true".<br />
                        <b>&lt;ValidFalseStatus&gt;</b> is the status the check should be set to if ValidationCode DOES NOT return "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <b>&lt;ExpectedStatus&gt;</b> is assumed.<br />
                        <b>&lt;ValidFalseComment&gt;</b> is the verbiage to add to the Comments section if ValidationCode DOES NOT return "true".<br />
                        <br />
                        **************************************************************************************--></p>
                </body>
            </html>
        <xsl:for-each select="Vuln">
                <tbody><tr>
                    <td><div class="button_cont"><a class="stig_button" id="button" onclick="change('{@ID}')" title="Show/Hide {@ID}"><xsl:value-of select="@ID" /></a></div></td>
                </tr></tbody>
                    <td><table id="{@ID}" class="styled-table" style="display:none">
                        <thead><tr>
                            <th>Name</th>
                            <th>Expected Status</th>
                            <th>Validation Code</th>
                            <th>Valid True Status</th>
                            <th>Valid True Comment</th>
                            <th>Valid False Status</th>
                            <th>Valid False Comment</th>
                        </tr></thead>
                        <xsl:for-each select="AnswerKey">
                            <tbody><tr>
                                    <td><xsl:value-of select="@Name" /></td>
                                    <td><xsl:value-of select="ExpectedStatus" /></td>
                                    <td><code><xsl:value-of select="ValidationCode" /></code></td>
                                    <td><xsl:value-of select="ValidTrueStatus" /></td>
                                    <td><xsl:value-of select="ValidTrueComment" /></td>
                                    <td><xsl:value-of select="ValidFalseStatus" /></td>
                                    <td><xsl:value-of select="ValidFalseComment" /></td>
                            </tr></tbody>
                        </xsl:for-each>
                    </table></td>
        </xsl:for-each>
     </xsl:template>
</xsl:stylesheet>
'@

    $AFxslt = New-Object System.Xml.Xsl.XslCompiledTransform
    $AFxslt.load($AFTransform)
    $AFxslt.Transform($AFFilePath, "$($AFFilePath.replace('.xml','')).html")
}

Function Close-Form {
  Param (
    [Parameter(Mandatory = $true)]
    [String]$Message
  )

  [System.Windows.MessageBox]::Show($Message, "Maintain Answer File Error", "OK", "Error")
  &$handler_formclose
}

Function Disable-Form {
  $SaveAFKeyLabel.Text = "Save Changes to $($AFKeys.Text)"

  $SaveAFKeyLabel.Visible = $True
  $SaveAFKeyButton.Visible = $True
  $DiscardAFKeyButton.Visible = $True

  $CreateAFKeyButton.Enabled = $False
  $RemoveAFKeyButton.Enabled = $False
  $RenameAFKeyButton.Enabled = $False
  $VulnIDRefreshButton.Enabled = $False
  $AFErrorRefreshButton.Enabled = $False
  $AFErrorRemVulnIDButton.Enabled = $False
  $SaveButton.Enabled = $False
  $StartOverButton.Enabled = $False
  $AFKeys.Enabled = $False
  $VulnIDBox.Enabled = $False
  $AFErrorBox.Enabled = $False
  $VulnIDStepLabel.Visible = $False
  $OpenAddDelKeyLabel.Visible = $False
}

Function Test-AnswerFile{

  $SupportedVer = [Version]"1.2107.0"
  Get-Content (Join-Path -Path $PsScriptRoot -ChildPath "Evaluate-STIG.ps1") | ForEach-Object {
    If ($_ -like '*$EvaluateStigVersion = *') {
        $Script:Version = [Version]((($_ -split "=")[1]).Trim() -replace '"','')
    }
  }
  If (!($Version -ge $SupportedVer)) {
      Close-Form -Message "Error: Evaluate-STIG $SupportedVer or greater required.  Found $Version.  Please update Evaluate-STIG to a supported version."
  }

  if ((($STIGs | Where-Object { $_.Name -contains $STIG_Name }).Name -eq $AFXML.STIGComments.Name) -or (($STIGs | Where-Object { $_.Name -contains $STIG_Name }).ShortName -eq $AFXML.STIGComments.Name)) {
    Foreach ($AFItem in $AFItems){
      $AFItem.AnswerKeys | Group-Object AnswerKey | ForEach-Object { if ($_.Count -gt 1) { $AFErrorBox.Items.Add($AFItem.VulnID).SubItems.Add("Dupe AnswerKey")}}
      If ($AFItem.VulnID -notin $STIGItems.VulnID){ $AFErrorBox.Items.Add($AFItem.VulnID).SubItems.Add("VulnID not in CKL")}
    }
  }
  else{
    Close-Form -Message "Error: Answer File ($($AFXML.STIGComments.Name)) does not match with Template CKL ($(($STIGs | Where-Object { $_.Name -contains $STIG_Name}).Name))."
  }

}
Function New-AnswerFileItems {

  $STIGLabel.Text = "$STIG_Name AnswerFile"
  $OpenButton.Visible = $False
  $CreateButton.Visible = $False

  $Script:AFItems = New-Object System.Collections.Generic.List[System.Object]
  ForEach ($Object in $AFXML.STIGComments.Vuln) {
    if ($AFItems.VulnID -contains $Object.ID) {
      $AFVulnKeys = ($AFItems | Where-Object {$_.VulnID -contains $Object.ID}).AnswerKeys
      $count = 1
      Foreach ($AFObject in $Object.AnswerKey) {
        $NewObj = [PSCustomObject]@{
          AnswerKey         = $AFObject.Name
          ExpectedStatus    = $AFObject.ExpectedStatus
          ValidationCode    = $AFObject.ValidationCode
          ValidTrueStatus   = $AFObject.ValidTrueStatus
          ValidTrueComment  = $AFObject.ValidTrueComment
          ValidFalseStatus  = $AFObject.ValidFalseStatus
          ValidFalseComment = $AFObject.ValidFalseComment
        }
        if ($AFVulnKeys | Where-Object { $_.AnswerKey -contains $NewObj.AnswerKey }) { $NewObj.AnswerKey = "$($NewObj.AnswerKey)_Copy$count"; $Count++ }
        ($AFItems | Where-Object { $_.VulnID -eq $Object.ID }).AnswerKeys.Add($NewObj)
      }
    }
    else {
      $AFVulnKeys = New-Object System.Collections.Generic.List[System.Object]
      $count = 1
      Foreach ($AFObject in $Object.AnswerKey) {
        $NewObj = [PSCustomObject]@{
          AnswerKey         = $AFObject.Name
          ExpectedStatus    = $AFObject.ExpectedStatus
          ValidationCode    = $AFObject.ValidationCode
          ValidTrueStatus   = $AFObject.ValidTrueStatus
          ValidTrueComment  = $AFObject.ValidTrueComment
          ValidFalseStatus  = $AFObject.ValidFalseStatus
          ValidFalseComment = $AFObject.ValidFalseComment
        }
        if ($AFVulnKeys | Where-Object { $_.AnswerKey -contains $NewObj.AnswerKey }) { $NewObj.AnswerKey = "$($NewObj.AnswerKey)_Copy$count"; $Count++ }
        $AFVulnKeys.Add($NewObj)
      }
      $NewObj = [PSCustomObject]@{
        VulnID     = $object.ID
        AnswerKeys = $AFVulnKeys
      }
      $AFItems.Add($NewObj)
    }
  }

  Test-AnswerFile

  $SaveButton.Visible = $True
  $SaveButton.Enabled = $False
  $StartOverButton.Visible = $True
  $StartOverButton.Enabled = $True
  $AddOutputLabel.Visible = $True
  $CSVCheckBox.Visible = $True
  $HTMLCheckBox.Visible = $True
  $AFPathLabel.Visible = $True
  $AFFileLabel.Visible = $True

  $NextStepLabel.Visible = $False
  $VulnIDStepLabel.Visible = $True

  $AFErrorRefreshButton.Visible = $True
  $AFErrorRemVulnIDButton.Visible = $True

  for ($i = 0; $i -lt $VulnIDBox.Items.Count; $i++) {
    if ($AFItems -match $VulnIDBox.Items[$i].SubItems[0].Text) {
      $VulnIDBox.Items[$i].SubItems[1].Text = "*"
    }
  }
}

Function New-AnswerFile {
  Param (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String]$NewAFpath,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$STIG_Name
  )

  $EmptyVulns = New-Object System.Collections.Generic.List[System.Object]

  Foreach ($Vuln in $AFItems){
    $EmptyAK = 0
    if ($null -eq $vuln.VulnID){
      $EmptyAK++
    }
    elseif (($vuln.AnswerKeys).count -eq 0) {
      $EmptyAK++
    }
    else{
      Foreach ($AK in $Vuln.AnswerKeys){
        if ($AK.AnswerKey -eq ""){
          $EmptyAK++
        }
      }
    }

    if ($EmptyAK -gt 0) {
      $EmptyVulns.Add($($AFItems | Where-Object { $_.VulnID -eq $Vuln.VulnID }))
    }
  }

  $EmptyVulns | ForEach-Object {$AFItems.Remove($_)}
  $AFItems = $AFItems | Sort-Object -Property VulnID

  $Encoding = [System.Text.Encoding]::UTF8
  $XmlWriter = New-Object System.Xml.XmlTextWriter($NewAFpath, $Encoding)

  $XmlWriter.Formatting = "Indented"
  $XmlWriter.Indentation = 2

  $XmlWriter.WriteStartDocument()

  $XmlWriter.WriteComment('**************************************************************************************
  This file contains answers for known opens and findings that cannot be evaluated through technical means.
  <STIGComments Name> must match the STIG ShortName or Name in -ListSupportedProducts.  When a match is found, this answer file will automatically for the STIG.
  <Vuln ID> is the STIG VulnID.  Multiple Vuln ID sections may be specified in a single Answer File.
  <AnswerKey Name> is the name of the key assigned to the answer.  "DEFAULT" can be used to apply the comment to any asset.  Multiple AnswerKey Name sections may be configured within a single Vuln ID section.
    *Note: If the Answer Key matches the hostname *exactly*, it will supersede any other key for the Vulnerability ID.  
     Multiple hostnames can be used, separated by either a space or a comma.
  <ExpectedStatus> is the initial status after the checklist is created.  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".
  <ValidationCode> must be Powershell code that returns a True/False value or a PSCustomObject.  If blank, "true" is assumed.
    *Note: If Validation Code returns a PSCustomObject, the Object MUST contain both "Results" and "Valid" keys.  "Results" will be written to the Comments field of the STIG check.
  <ValidTrueStatus> is the status the check should be set to if ValidationCode returns "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
  <ValidTrueComment> is the verbiage to add to the Comments section if ValidationCode returns "true".
  <ValidFalseStatus> is the status the check should be set to if ValidationCode DOES NOT return "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
  <ValidFalseComment> is the verbiage to add to the Comments section if ValidationCode DOES NOT return "true".
  **************************************************************************************')

  $XmlWriter.WriteStartElement("STIGComments")
  $XmlWriter.WriteAttributeString("Name", $STIG_Name)

  Foreach($Item in $AFItems){
    $XmlWriter.WriteStartElement("Vuln")
    $XmlWriter.WriteAttributeString("ID", $Item.VulnID)
    $XmlWriter.WriteComment($(($STIGItems | Where-Object { $_.VulnID -eq $Item.VulnID }).RuleTitle))
    Foreach ($AKItem in $Item.AnswerKeys){
      if ($null -ne $AKItem.AnswerKey){
        $XmlWriter.WriteStartElement("AnswerKey")
        $XmlWriter.WriteAttributeString("Name", $AKItem.AnswerKey)

        $XmlWriter.WriteStartElement("ExpectedStatus")
        If ($AKItem.ExpectedStatus) {
            $XmlWriter.WriteString($AKItem.ExpectedStatus)
        }
        Else {
            $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteStartElement("ValidationCode")
        If ($AKItem.ValidationCode) {
          $XmlWriter.WriteString($AKItem.ValidationCode)
        }
        Else {
          $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteStartElement("ValidTrueStatus")
        If ($AKItem.ValidTrueStatus) {
          $XmlWriter.WriteString($AKItem.ValidTrueStatus)
        }
        Else {
          $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteStartElement("ValidTrueComment")
        If ($AKItem.ValidTrueComment) {
          $XmlWriter.WriteString($AKItem.ValidTrueComment)
        }
        Else {
          $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteStartElement("ValidFalseStatus")
        If ($AKItem.ValidFalseStatus) {
          $XmlWriter.WriteString($AKItem.ValidFalseStatus)
        }
        Else {
          $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteStartElement("ValidFalseComment")
        If ($AKItem.ValidFalseComment) {
          $XmlWriter.WriteString($AKItem.ValidFalseComment)
        }
        Else {
          $XmlWriter.WriteWhitespace("")
        }
        $XmlWriter.WriteFullEndElement()
        $XmlWriter.WriteEndElement()
      }
    }
    $XmlWriter.WriteEndElement()
  }

  $XmlWriter.WriteEndElement()
  $XmlWriter.WriteEnddocument()
  $XmlWriter.Flush()
  $XmlWriter.Close()
}

function Reset-ListViewColumn {
  <#
    .SYNOPSIS
        Sort the ListView's item using the specified column.

    .DESCRIPTION
        Sort the ListView's item using the specified column.
        This function uses Add-Type to define a class that sort the items.
        The ListView's Tag property is used to keep track of the sorting.

    .PARAMETER ListView
        The ListView control to sort.

    .PARAMETER ColumnIndex
        The index of the column to use for sorting.

    .PARAMETER SortOrder
        The direction to sort the items. If not specified or set to None, it will toggle.

    .EXAMPLE
        Set-WFListViewColumn -ListView $listview1 -ColumnIndex 0

    .NOTES
        SAPIEN Technologies, Inc.
        http://www.sapien.com/
#>
  param (
    [ValidateNotNull()]
    [Parameter(Mandatory = $true)]
    [System.Windows.Forms.ListView]$ListView,

    [Parameter(Mandatory = $true)]
    [int]$ColumnIndex,

    [System.Windows.Forms.SortOrder]$SortOrder = 'None')

  if (($ListView.Items.Count -eq 0) -or ($ColumnIndex -lt 0) -or ($ColumnIndex -ge $ListView.Columns.Count)) {
    return;
  }

  #region Define ListViewItemComparer
  try {
    $local:type = [ListViewItemComparer]
  }
  catch {
    Add-Type -ReferencedAssemblies ('System.Windows.Forms') -TypeDefinition  @"
    using System;
    using System.Windows.Forms;
    using System.Collections;
    public class ListViewItemComparer : IComparer
    {
        public int column;
        public SortOrder sortOrder;
        public ListViewItemComparer()
        {
            column = 0;
            sortOrder = SortOrder.Ascending;
        }
        public ListViewItemComparer(int column, SortOrder sort)
        {
            this.column = column;
            sortOrder = sort;
        }
        public int Compare(object x, object y)
        {
            if(column >= ((ListViewItem)x).SubItems.Count)
                return sortOrder == SortOrder.Ascending ? -1 : 1;

            if(column >= ((ListViewItem)y).SubItems.Count)
                return sortOrder == SortOrder.Ascending ? 1 : -1;

            if(sortOrder == SortOrder.Ascending)
                return String.Compare(((ListViewItem)x).SubItems[column].Text, ((ListViewItem)y).SubItems[column].Text);
            else
                return String.Compare(((ListViewItem)y).SubItems[column].Text, ((ListViewItem)x).SubItems[column].Text);
        }
    }
"@ | Out-Null
  }
  #endregion

  if ($ListView.Tag -is [ListViewItemComparer]) {
    #Toggle the Sort Order
    if ($SortOrder -eq [System.Windows.Forms.SortOrder]::None) {
      if ($ListView.Tag.column -eq $ColumnIndex -and $ListView.Tag.sortOrder -eq 'Ascending') {
        $ListView.Tag.sortOrder = 'Descending'
      }
      else {
        $ListView.Tag.sortOrder = 'Ascending'
      }
    }
    else {
      $ListView.Tag.sortOrder = $SortOrder
    }

    $ListView.Tag.column = $ColumnIndex
    $ListView.Sort() #Sort the items
  }
  else {
    if ($SortOrder -eq [System.Windows.Forms.SortOrder]::None) {
      $SortOrder = [System.Windows.Forms.SortOrder]::Ascending
    }

    #Set to Tag because for some reason in PowerShell ListViewItemSorter prop returns null
    $ListView.Tag = New-Object ListViewItemComparer ($ColumnIndex, $SortOrder)
    $ListView.ListViewItemSorter = $ListView.Tag #Automatically sorts
  }
}

add-type -AssemblyName System.Windows.Forms
add-type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName PresentationFramework
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public class ProcessDPI {
    [DllImport("user32.dll", SetLastError=true)]
    public static extern bool SetProcessDPIAware();
}
'@

$null = [ProcessDPI]::SetProcessDPIAware()

$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState

$TitleFont = New-Object System.Drawing.Font("Calibri",24,[Drawing.FontStyle]::Bold)
$BodyFont = New-Object System.Drawing.Font("Calibri",18,[Drawing.FontStyle]::Bold)
$BoxFont = New-Object System.Drawing.Font("Calibri", 12, [Drawing.FontStyle]::Regular)
$BoldBoxFont = New-Object System.Drawing.Font("Calibri", 12, [Drawing.FontStyle]::Bold)

$HLine = New-Object System.Windows.Forms.Label
$VLine = New-Object System.Windows.Forms.Label

$STIGLabel = New-Object System.Windows.Forms.Label
$CKLLabel = New-Object System.Windows.Forms.Label
$AFPathLabel = New-Object System.Windows.Forms.Label
$AFFileLabel = New-Object System.Windows.Forms.Label
$AFKeyLabel = New-Object System.Windows.Forms.Label
$AFExpectedLabel = New-Object System.Windows.Forms.Label
$AFValCodeLabel = New-Object System.Windows.Forms.Label
$AFValTSLabel = New-Object System.Windows.Forms.Label
$AFValTCommLabel = New-Object System.Windows.Forms.Label
$AFValFSLabel = New-Object System.Windows.Forms.Label
$AFValFCommLabel = New-Object System.Windows.Forms.Label
$StartHereLabel = New-Object System.Windows.Forms.Label
$NextStepLabel = New-Object System.Windows.Forms.Label
$VulnIDStepLabel = New-Object System.Windows.Forms.Label
$AddOutputLabel = New-Object System.Windows.Forms.Label
$SaveAFKeyLabel = New-Object System.Windows.Forms.Label
$OpenAddDelKeyLabel = New-Object System.Windows.Forms.Label
$AFErrorLabel = New-Object System.Windows.Forms.Label
$AFMarkLabel = New-Object System.Windows.Forms.Label
$DefaultAFKeyLabel = New-Object System.Windows.Forms.Label

$AFValCodeBox = New-Object System.Windows.Forms.TextBox
$AFValTCommBox = New-Object System.Windows.Forms.TextBox
$AFValFCommBox = New-Object System.Windows.Forms.TextBox

$CKLInfoBox = New-Object System.Windows.Forms.RichTextBox

$OpenButton = New-Object System.Windows.Forms.Button
$CreateButton = New-Object System.Windows.Forms.Button
$SaveButton = New-Object System.Windows.Forms.Button
$SaveAFKeyButton = New-Object System.Windows.Forms.Button
$DiscardAFKeyButton = New-Object System.Windows.Forms.Button
$CreateAFKeyButton = New-Object System.Windows.Forms.Button
$RemoveAFKeyButton = New-Object System.Windows.Forms.Button
$RenameAFKeyButton = New-Object System.Windows.Forms.Button
$AFErrorRefreshButton = New-Object System.Windows.Forms.Button
$AFErrorRemVulnIDButton = New-Object System.Windows.Forms.Button
$VulnIDRefreshButton = New-Object System.Windows.Forms.Button
$AFValCodeIDEButton = New-Object System.Windows.Forms.Button
$DarkModeButton = New-Object System.Windows.Forms.Button
$StartOverButton = New-Object System.Windows.Forms.Button

$VulnIDBox = New-Object System.Windows.Forms.ListView
$AFErrorBox = New-Object System.Windows.Forms.ListView

$SupportedSTIGSBox = New-Object System.Windows.Forms.ListBox

$AFKeys = New-Object System.Windows.Forms.ComboBox
$AFExpectedBox = New-Object System.Windows.Forms.ComboBox
$AFValTSBox = New-Object System.Windows.Forms.ComboBox
$AFValFSBox = New-Object System.Windows.Forms.ComboBox

$HTMLCheckBox = New-Object System.Windows.Forms.CheckBox
$CSVCheckBox = New-Object System.Windows.Forms.CheckBox
$OpenCheckBox = New-Object System.Windows.Forms.CheckBox
$NFCheckBox = New-Object System.Windows.Forms.CheckBox
$NRCheckBox = New-Object System.Windows.Forms.CheckBox
$NACheckBox = New-Object System.Windows.Forms.CheckBox


#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------

$OnLoadForm_StateCorrection=
{#Correct the initial state of the form to prevent the .Net maximized form issue
  $form1.WindowState = $InitialFormWindowState

  $PowerShellVersion = $PsVersionTable.PSVersion

  If ($PowerShellVersion -lt [Version]"7.0") {
    Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions")
  }
  Else {
    Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions") -SkipEditionCheck
  }

  $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
  $Script:STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object Name, ShortName, StigContent -Unique

  ForEach ($STIG in $STIGs) {
    $null = $SupportedSTIGSBox.Items.Add($STIG.Name)
  }

  $CKLLabel.Text = "Supported STIGS"

  $Script:Preferences = (Select-Xml -Path $(Join-Path $PSScriptRoot -ChildPath Preferences.xml) -XPath /).Node

  ForEach ($Item in ($Preferences.Preferences.ManageAnswerFiles | Get-Member -MemberType Property | Where-Object Definition -MATCH string | Where-Object Name -NE '#comment').Name) {
    $Preferences.Preferences.ManageAnswerFiles.$Item = $Preferences.Preferences.ManageAnswerFiles.$Item -replace '"','' -replace "'",''
  }

  $Script:DefaultAFKey = $Preferences.Preferences.ManageAnswerFiles.DefaultAFKey
  $DefaultAFKeyLabel.Text = "Default AF Key:  $DefaultAFKey"

  $AFValCodeIDEButton.Text = (Get-Item $Preferences.Preferences.ManageAnswerFiles.PowerShell_IDE).BaseName
}

$handler_SupportedSTIGSBox_DoubleClick =
{
  $TemplateCKL = ($STIGs | Where-Object { $_.Name -contains $($SupportedSTIGSBox.SelectedItems) }).StigContent

  $CKLLabel.Visible = $True

  [xml]$Script:xml = New-Object xml
  $xml.Load($(Join-Path -Path $PsScriptRoot -ChildPath "STIGContent" | Join-Path -ChildPath $TemplateCKL))

  $Script:STIG_Name = ($STIGs | Where-Object { $_.Name -contains $($SupportedSTIGSBox.SelectedItems) }).Name

  $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
  $CKLLabel.Text = "$STIG_Name"

  $VulnIDBox.Items.Clear()

  $Script:STIGItems = New-Object System.Collections.Generic.List[System.Object]
  ForEach ($Object in $xml.Benchmark.Group) {
    Switch ($Object.Rule.Severity) {
        "high" {
            $Severity = "I"
        }
        "medium" {
            $Severity = "II"
        }
        "low" {
            $Severity = "III"
        }
    }
    $NewObj = [PSCustomObject]@{
      VulnID            = $Object.id
      Severity          = $Severity
      Status            = $null
      RuleTitle         = $Object.Rule.Title
      RuleVuln_Discuss  = $(Get-InnerXml -InnerXml $Object.Rule.description -Tag "VulnDiscussion")
      RuleCheck_Content = $Object.Rule.check."check-content"
    }
    $STIGItems.Add($NewObj)
  }

  [System.Windows.MessageBox]::Show("Select Evaluate-STIG Result for $($SupportedSTIGSBox.SelectedItems)", "Select Evaluate-STIG Result", "OK", "Exclamation")

  if ($Preferences.Preferences.ManageAnswerFiles.EvaluateSTIG_Results){
    $InitialDir = $Preferences.Preferences.ManageAnswerFiles.EvaluateSTIG_Results
  }
  else{
    If ($IsLinux) {
      $InitialDir = "/opt/STIG_Compliance"
    }
    Else {
      $InitialDir = "$env:PUBLIC\Documents\STIG_Compliance"
    }
  }

  $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    InitialDirectory = $InitialDir
    Filter           = "Checklist Files (*.ckl,*.cklb)|*.ckl;*.cklb"
  }

  $Result = $FileBrowser.ShowDialog()

  $Valid = $False
  if ($Result -eq "OK") {
    $CKLFilePath = $FileBrowser.FileName

    Switch ($((Get-Item $CKLFilePath).Extension)) {
      ".ckl" {
          [xml]$CKLXML = New-Object xml
          $CKLXML.Load($CKLFilePath)

          if ($xml.Benchmark.id -in $CKLXML.CHECKLIST.stigs.iSTIG.STIG_INFO.SelectSingleNode('./SI_DATA[SID_NAME="stigid"]/SID_DATA').InnerText){
            if (($xml.Benchmark.version -in $CKLXML.CHECKLIST.stigs.iSTIG.STIG_INFO.SelectSingleNode('./SI_DATA[SID_NAME="version"]/SID_DATA').InnerText) -and (($xml.Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text' -in $CKLXML.CHECKLIST.stigs.iSTIG.STIG_INFO.SelectSingleNode('./SI_DATA[SID_NAME="releaseinfo"]/SID_DATA').InnerText)){

              $CKLXMLID = ($CKLXML.CHECKLIST.STIGS.iSTIG | Where-Object {$_.STIG_INFO.SelectSingleNode('./SI_DATA[SID_NAME="stigid"]/SID_DATA').InnerText -eq $xml.Benchmark.id})
              ForEach ($STIG in $CKLXMLID.VULN) {
                ($STIGItems | Where-Object { $_.VulnID -eq $($STIG.SelectSingleNode('./STIG_DATA[VULN_ATTRIBUTE="Vuln_Num"]/ATTRIBUTE_DATA').InnerText) }).Status = $STIG.Status
              }
              $Valid = $True
            }
            else{
              [System.Windows.MessageBox]::Show("$CKLFilePath is an outdated CKL file.  Please run Evaluate-STIG $Version against the host.", "Select Evaluate-STIG Result", "OK", "Error")
            }
          }
          else{
            [System.Windows.MessageBox]::Show("$CKLFilePath does not match selected Supported STIG ($STIG_Name).", "Select Evaluate-STIG Result", "OK", "Error")
          }
        }

      ".cklb" {
        $CKLBJSON = Get-Content $CKLFilePath | ConvertFrom-Json

        if ($xml.Benchmark.id -in $CKLBJSON.stigs.stig_id){
          if (($xml.Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text' -in $CKLBJSON.stigs.release_info){

            $CKLJSONID = $CKLBJSON.stigs | Where-Object {$_.stig_id -eq $xml.Benchmark.id}
            ForEach ($Rule in $CKLJSONID.Rules) {
              ($STIGItems | Where-Object { $_.VulnID -eq $Rule.group_id }).Status = Convert-Status -InputObject $Rule.Status -Output CKL
            }
            $Valid = $True
          }
          else{
            [System.Windows.MessageBox]::Show("$CKLFilePath is an outdated CKLB file.  Please run Evaluate-STIG $Version against the host.", "Select Evaluate-STIG Result", "OK", "Error")
          }
        }
        else{
          [System.Windows.MessageBox]::Show("$CKLFilePath does not match selected Supported STIG ($STIG_Name).", "Select Evaluate-STIG Result", "OK", "Error")
        }
      }
    }
  }

  if ($Valid){
    &$handler_VulnIDRefreshButton_Click

    $AFPathLabel.Text = ""
    $AFFileLabel.Text = ""
    $AFExpectedBox.SelectedIndex = -1
    $AFValTSBox.SelectedIndex = -1
    $AFValFSBox.SelectedIndex = -1
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.TextBox] } | ForEach-Object { $_.Clear() }
    $null = $AFFilePath

    $OpenButton.Visible = $True
    $CreateButton.Visible = $True

    $OpenButton.Enabled = $True
    $CreateButton.Enabled = $True

    $StartHereLabel.Visible = $False
    $NextStepLabel.Visible = $True
  }
  else{
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.Textbox] } | ForEach-Object { $_.clear() }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.Items.Clear() }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListView] } | ForEach-Object { $_.Items.Clear() }

    $AFExpectedBox.SelectedIndex = -1
    $AFValTSBox.SelectedIndex = -1
    $AFValFSBox.SelectedIndex = -1

    $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
    $CKLLabel.Text = "Supported STIGS"
    $SupportedSTIGSBox.Visible = $True
    $StartHereLabel.Text = "Start by DoubleClicking STIG"
    $StartHereLabel.Visible = $True

    $SaveButton.Visible = $False
    $AFPathLabel.Visible = $False
    $AFFileLabel.Visible = $False
    $SaveAFKeyButton.Visible = $False
    $DiscardAFKeyButton.Visible = $False
    $CKLInfoBox.Visible = $False
    $CreateAFKeyButton.Visible = $False
    $RemoveAFKeyButton.Visible = $False
    $RenameAFKeyButton.Visible = $False
    $NextStepLabel.Visible = $False
    $VulnIDStepLabel.Visible = $False
    $AddOutputLabel.Visible = $False
    $CSVCheckBox.Visible = $False
    $HTMLCheckBox.Visible = $False
    $SaveAFKeyLabel.Visible = $False
    $OpenAddDelKeyLabel.Visible = $False
    $OpenCheckBox.Visible = $False
    $OpenCheckBox.Checked = $True
    $NRCheckBox.Visible = $False
    $NRCheckBox.Checked = $True
    $NFCheckBox.Visible = $False
    $NACheckBox.Visible = $False
    $AFMarkLabel.Visible = $False
    $VulnIDRefreshButton.Visible = $False
    $AFErrorRefreshButton.Visible = $False
    $AFErrorRemVulnIDButton.Visible = $False

    Remove-Variable * -ErrorAction SilentlyContinue
    $STIGItems.Clear()
    $null = $AFFilePath

    $form1.Refresh()
  }
}

$handler_AFValCodeIDE_Click = {
  Start-Process $Preferences.Preferences.ManageAnswerFiles.PowerShell_IDE
}

$handler_OpenButton_Click=
{
  if ($Preferences.Preferences.ManageAnswerFiles.AnswerFileDirectory){
    $InitialDir = $Preferences.Preferences.ManageAnswerFiles.AnswerFileDirectory
  }
  else{
    $InitialDir = [Environment]::GetFolderPath('Desktop')
  }

  $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    InitialDirectory = $InitialDir
    Filter           = "Answer Files (*.xml,*.csv)|*.xml;*.csv"
  }

  $Result = $FileBrowser.ShowDialog()

  if ($Result -eq "OK") {
    if ((Get-Item $FileBrowser.FileName).Extension -eq ".xml") {
      $Script:AFFilePath = $FileBrowser.FileName
      Try{
        [xml]$Script:AFXML = New-Object xml
        $AFXML.Load($AFFilePath)
      }
      Catch{
        Close-Form -Message "$AFFilePath `n`n$($_.Exception.Message)"
      }
    }
    else{
      $Filename = $STIG_Name.replace(" ", "_") + "_AnswerFile.xml"

      $Script:AFFilePath = Join-Path -Path $(Split-Path $FileBrowser.FileName) -ChildPath $Filename
      [xml]$AFXML = New-Object xml

      $NewItem = $AFXML.CreateElement("STIGComments")
      $NewItem.SetAttribute( "Name", "$STIG_Name")
      $null = $AFXML.AppendChild($NewItem)

      $AnswerFromCSV = Import-Csv -Path $FileBrowser.FileName
      ForEach ($AnswerVuln in $AnswerFromCSV){
        $Node = $AFXML.STIGComments.SelectSingleNode("./Vuln[@ID='$($AnswerVuln.VulnID)']")

        if (!($Node)){
          $NewVuln = $AFXML.CreateElement("Vuln")
          $NewVuln.SetAttribute( "ID", "$($AnswerVuln.VulnID)")
          $null = $AFXML.STIGComments.AppendChild($NewVuln)

          $Node = $AFXML.STIGComments.SelectSingleNode("./Vuln[@ID='$($AnswerVuln.VulnID)']")
        }

        $NewAK = $AFXML.CreateElement("AnswerKey")
        $NewAK.SetAttribute( "Name", "$($AnswerVuln.AnswerKey)")
        $null = $Node.AppendChild($NewAK)

        $NewItem = $AFXML.CreateElement("ExpectedStatus")
        $NewItem.InnerText = $AnswerVuln.ExpectedStatus
        $null = $NewAK.AppendChild($NewItem)
        $NewItem = $AFXML.CreateElement("ValidationCode")
        $NewItem.InnerText = $AnswerVuln.ValidationCode
        $null = $NewAK.AppendChild($NewItem)
        $NewItem = $AFXML.CreateElement("ValidTrueStatus")
        $NewItem.InnerText = $AnswerVuln.ValidTrueStatus
        $null = $NewAK.AppendChild($NewItem)
        $NewItem = $AFXML.CreateElement("ValidTrueComment")
        $NewItem.InnerText = $AnswerVuln.ValidTrueComment
        $null = $NewAK.AppendChild($NewItem)
        $NewItem = $AFXML.CreateElement("ValidFalseStatus")
        $NewItem.InnerText = $AnswerVuln.ValidFalseStatus
        $null = $NewAK.AppendChild($NewItem)
        $NewItem = $AFXML.CreateElement("ValidFalseComment")
        $NewItem.InnerText = $AnswerVuln.ValidFalseComment
        $null = $NewAK.AppendChild($NewItem)
      }

      $AFXML.Save($AFFilePath)

      Try {
        [xml]$Script:AFXML = New-Object xml
        $AFXML.Load($AFFilePath)
      }
      Catch {
        Close-Form -Message "$AFFilePath `n`n$($_.Exception.Message)"
      }
    }

    $AFPathLabel.Text = "AnswerFile Path: $(Split-Path -Path $FileBrowser.FileName -Parent)"
    $AFFileLabel.Text = "AnswerFile Name: $($FileBrowser.SafeFileName)"

    New-AnswerFileItems
  }
  else{
    $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
  }
}

$handler_CreateButton_Click =
{
  $Filename = $STIG_Name.replace(" ", "_") + "_AnswerFile.xml"

  $STIGLabel.Text = "$STIG_Name AnswerFile"

  if ($Preferences.Preferences.ManageAnswerFiles.AnswerFileDirectory){
    $RootDir = $Preferences.Preferences.ManageAnswerFiles.AnswerFileDirectory
  }
  else{
    $RootDir = $(Join-Path $PSScriptRoot -ChildPath AnswerFiles)
  }

  $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
    SelectedPath = "$RootDir\"
  }

  $Result = $FolderBrowser.ShowDialog()

  if ($Result -eq "OK") {
    $Script:AFFilePath = $(Join-Path $FolderBrowser.SelectedPath -ChildPath $Filename)

    New-AnswerFile $AFFilePath $STIG_Name
    [xml]$Script:AFXML = New-Object xml
    $AFXML.Load($AFFilePath)

    $AFPathLabel.Text = "AnswerFile Path: $($FolderBrowser.SelectedPath)"
    $AFFileLabel.Text = "AnswerFile Name: $FileName"

    New-AnswerFileItems
  }
  else {
    $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
  }
}

$handler_CreateAFKeyButton_Click =
{
  $title = "New Answer File Key"
  $msg = "Enter a new Answer File Key:"

  $NewAFKey = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)

  $NewObj = [PSCustomObject]@{
      AnswerKey        = $NewAFKey
      ExpectedStatus     = "Not_Reviewed"
      ValidationCode   = ""
      ValidTrueStatus   = ""
      ValidTrueComment = ""
      ValidFalseStatus  = ""
      ValidFalseComment = ""
    }

  if ($NewObj.AnswerKey -notin ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.AnswerKey) 
  { 
    ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Add($NewObj)
    $AFKeys.Items.Add($NewObj.AnswerKey)
    $AFKeys.SelectedItem = $NewObj.AnswerKey
  }
  else{
    [System.Windows.MessageBox]::Show("$NewAFKey Already Exists", "Answer Key Already Exists", "OK", "Exclamation")
  }
}

$handler_RemoveAFKeyButton_Click =
{
  $confirm = [System.Windows.MessageBox]::Show("Remove $($AFKeys.SelectedItem)?", "Confirmation", "YesNo", "Question")

  if ($confirm -eq "Yes"){
    ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Remove($TempObj)
    $AFKeys.Items.Remove($TempObj.AnswerKey)

    $AFExpectedBox.SelectedIndex = -1
    $AFValTSBox.SelectedIndex = -1
    $AFValFSBox.SelectedIndex = -1
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.TextBox] } | ForEach-Object { $_.Clear() }

    ($VulnIDBox.FindItemWithText("$VulnID")).SubItems[1].Text = "-"
  }

  $SaveButton.Enabled = $True
  $StartOverButton.Enabled = $True
}

$handler_RenameAFKeyButton_Click =
{
  $title = "New Answer File Key Name"
  $msg = "Enter a new Answer File Key Name:"

  $NewAFKey = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)

  ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Remove($TempObj)

  $NewObj = [PSCustomObject]@{
    AnswerKey         = $NewAFKey
    ExpectedStatus    = $AFExpectedBox.SelectedItem
    ValidationCode    = $AFValCodeBox.Text
    ValidTrueStatus   = $AFValTSBox.SelectedItem
    ValidTrueComment  = $AFValTCommBox.Text
    ValidFalseStatus  = $AFValFSBox.SelectedItem
    ValidFalseComment = $AFValFCommBox.Text
  }

  if (($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys -eq $NewObj.AnswerKey) { $NewObj.AnswerKey = "$($NewObj.AnswerKey)_Copy$((($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys -eq $NewObj.AnswerKey).count)" }
  ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Add($NewObj)

  $AFKeys.Items.Remove($TempObj.AnswerKey)
  $AFKeys.Items.Add($NewObj.AnswerKey)
  $AFKeys.SelectedItem = $NewObj.AnswerKey

  $SaveButton.Enabled = $True
  $StartOverButton.Enabled = $True
}

$handler_SaveAFKeyButton_Click =
{
  ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Remove($TempObj)

  $NewObj = [PSCustomObject]@{
    AnswerKey        = $AFKeys.SelectedItem
    ExpectedStatus     = $AFExpectedBox.SelectedItem
    ValidationCode   = $AFValCodeBox.Text
    ValidTrueStatus   = $AFValTSBox.SelectedItem
    ValidTrueComment  = $AFValTCommBox.Text
    ValidFalseStatus  = $AFValFSBox.SelectedItem
    ValidFalseComment = $AFValFCommBox.Text
  }
  ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys.Add($NewObj)

  ($VulnIDBox.FindItemWithText("$VulnID")).SubItems[1].Text = "+"

  $SaveAFKeyLabel.Visible = $False
  $SaveAFKeyButton.Visible = $False
  $DiscardAFKeyButton.Visible = $False

  $CreateAFKeyButton.Enabled = $True
  $RemoveAFKeyButton.Enabled = $True
  $RenameAFKeyButton.Enabled = $True
  $VulnIDRefreshButton.Enabled = $True
  $AFErrorRefreshButton.Enabled = $True
  $AFErrorRemVulnIDButton.Enabled = $True
  $SaveButton.Enabled = $True
  $StartOverButton.Enabled = $True
  $AFKeys.Enabled = $True
  $VulnIDBox.Enabled = $True
  $AFErrorBox.Enabled = $True
  $VulnIDStepLabel.Visible = $True
  $OpenAddDelKeyLabel.Visible = $True
}

$handler_DiscardAFKeyButton_Click =
{
  ($VulnIDBox.FindItemWithText("$VulnID")).SubItems[1].Text = ""

  $AFExpectedBox.Text = $TempObj.ExpectedStatus
  $AFValCodeBox.Text = $TempObj.ValidationCode
  $AFValTSBox.Text = $TempObj.ValidTrueStatus
  $AFValTCommBox.Text = $TempObj.ValidTrueComment
  $AFValFSBox.Text = $TempObj.ValidFalseStatus
  $AFValFCommBox.Text = $TempObj.ValidFalseComment

  $null = $TempObj

  $SaveAFKeyLabel.Visible = $False
  $SaveAFKeyButton.Visible = $False
  $DiscardAFKeyButton.Visible = $False

  $CreateAFKeyButton.Enabled = $True
  $RemoveAFKeyButton.Enabled = $True
  $RenameAFKeyButton.Enabled = $True
  $VulnIDRefreshButton.Enabled = $True
  $AFErrorRefreshButton.Enabled = $True
  $AFErrorRemVulnIDButton.Enabled = $True
  $SaveButton.Enabled = $True
  $StartOverButton.Enabled = $True
  $AFKeys.Enabled = $True
  $VulnIDBox.Enabled = $True
  $AFErrorBox.Enabled = $True
  $VulnIDStepLabel.Visible = $True
  $OpenAddDelKeyLabel.Visible = $True
}

$handler_SaveButton_Click =
{
  $null = Copy-Item $AFFilePath -Destination "$($AFFilePath.replace('.xml','')).bak" -Force

  New-AnswerFile $AFFilePath $STIG_Name

  $SaveButton.Enabled = $False
}

$handler_StartOverButton_Click =
{
  if (($SaveButton.Enabled -eq $True) -and ($SaveButton.Visible -eq $True)){
    $confirm = [System.Windows.MessageBox]::Show("$AFFilePath is not saved. Save and Exit?", "Confirmation", "YesNo", "Question")

    if ($confirm -eq "Yes") {
      &$handler_SaveButton_Click
    }
  }

  if ($HTMLCheckBox.Checked -eq $True){
    ConvertTo-HTMLReport
  }

  if ($CSVCheckBox.Checked -eq $True){
    ConvertTo-CSVReport
  }

  $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.Textbox] } | ForEach-Object { $_.clear() }
  $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.Items.Clear() }
  $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListView] } | ForEach-Object { $_.Items.Clear() }

  $AFExpectedBox.SelectedIndex = -1
  $AFValTSBox.SelectedIndex = -1
  $AFValFSBox.SelectedIndex = -1

  $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
  $CKLLabel.Text = "Supported STIGS"
  $SupportedSTIGSBox.Visible = $True
  $SupportedSTIGSBox.ClearSelected()
  $StartHereLabel.Text = "Start by DoubleClicking STIG"
  $StartHereLabel.Visible = $True

  $SaveButton.Visible = $False
  $StartOverButton.Visible = $False
  $AFPathLabel.Visible = $False
  $AFFileLabel.Visible = $False
  $SaveAFKeyButton.Visible = $False
  $DiscardAFKeyButton.Visible = $False
  $CKLInfoBox.Visible = $False
  $CreateAFKeyButton.Visible = $False
  $RemoveAFKeyButton.Visible = $False
  $RenameAFKeyButton.Visible = $False
  $NextStepLabel.Visible = $False
  $VulnIDStepLabel.Visible = $False
  $AddOutputLabel.Visible = $False
  $CSVCheckBox.Visible = $False
  $HTMLCheckBox.Visible = $False
  $SaveAFKeyLabel.Visible = $False
  $OpenAddDelKeyLabel.Visible = $False
  $OpenCheckBox.Visible = $False
  $OpenCheckBox.Checked = $True
  $NRCheckBox.Visible = $False
  $NRCheckBox.Checked = $True
  $NFCheckBox.Visible = $False
  $NACheckBox.Visible = $False
  $AFMarkLabel.Visible = $False
  $VulnIDRefreshButton.Visible = $False
  $AFErrorRefreshButton.Visible = $False
  $AFErrorRemVulnIDButton.Visible = $False

  Remove-Variable * -ErrorAction SilentlyContinue
  $AFItems.Clear()
  $STIGItems.Clear()
  $null = $AFFilePath

  $form1.Refresh()
}

$handler_AFErrorRemVulnIDButton_Click = {
  Foreach ($ErrorVulnID in $AFErrorBox.SelectedItems.Text) {
    $OldObj = ($AFItems | Where-Object { $_.VulnID -eq $ErrorVulnID })
    $AFItems.Remove($OldObj)
  }

  &$handler_AFErrorRefreshButton_Click
  $SaveButton.Enabled = $True
  $StartOverButton.Enabled = $True
}

$handler_AFErrorRefreshButton_Click = {
  $AFErrorBox.Items.Clear()
  Foreach ($AFItem in $AFItems) {
    $AFItem.AnswerKeys | Group-Object AnswerKey | ForEach-Object { if ($_.Count -gt 1) { $AFErrorBox.Items.Add($AFItem.VulnID).SubItems.Add("Dupe AnswerKey") } }
    If ($AFItem.VulnID -notin $STIGItems.VulnID) { $AFErrorBox.Items.Add($AFItem.VulnID).SubItems.Add("VulnID not in CKL") }
  }
}

$handler_VulnIDRefreshButton_Click = {
  $VulnIDBox.Items.Clear()

  If ($OpenCheckBox.Checked -eq $True) { $STIGItems | Where-Object { $_.Status -eq "Open" } | ForEach-Object { $item = New-Object System.Windows.Forms.ListViewItem($_.VulnID); $item.SubItems.Add(""); $item.SubItems.Add($_.Severity); $item.SubItems.Add($_.Status); $VulnIDBox.Items.AddRange($item) } }
  If ($NRCheckBox.Checked -eq $True) { $STIGItems | Where-Object { $_.Status -eq "Not_Reviewed" } | ForEach-Object { $item = New-Object System.Windows.Forms.ListViewItem($_.VulnID); $item.SubItems.Add(""); $item.SubItems.Add($_.Severity); $item.SubItems.Add($_.Status); $VulnIDBox.Items.AddRange($item) } }
  If ($NACheckBox.Checked -eq $True) { $STIGItems | Where-Object { $_.Status -eq "Not_Applicable" } | ForEach-Object { $item = New-Object System.Windows.Forms.ListViewItem($_.VulnID); $item.SubItems.Add(""); $item.SubItems.Add($_.Severity); $item.SubItems.Add($_.Status); $VulnIDBox.Items.AddRange($item) } }
  If ($NFCheckBox.Checked -eq $True) { $STIGItems | Where-Object { $_.Status -eq "NotAFinding" } | ForEach-Object { $item = New-Object System.Windows.Forms.ListViewItem($_.VulnID); $item.SubItems.Add(""); $item.SubItems.Add($_.Severity); $item.SubItems.Add($_.Status); $VulnIDBox.Items.AddRange($item) } }

  for ($i = 0; $i -lt $VulnIDBox.Items.Count; $i++) {
    switch ($VulnIDBox.Items[$i].SubItems[2].Text) {
      "Open" { $VulnIDBox.items[$i].ForeColor = 'Red' }
      "NotAFinding" { $VulnIDBox.items[$i].ForeColor = 'Green' }
      "Not_Reviewed" { $VulnIDBox.items[$i].ForeColor = 'Black' }
      "Not_Applicable" { $VulnIDBox.items[$i].ForeColor = 'Gray' }
    }
    if ($AFItems -match $VulnIDBox.Items[$i].SubItems[0].Text) {
      $VulnIDBox.Items[$i].SubItems[1].Text = "*"
    }
  }

  $OpenCheckBox.Visible = $True
  $NRCheckBox.Visible = $True
  $NFCheckBox.Visible = $True
  $NACheckBox.Visible = $True
  $AFMarkLabel.Visible = $True
  $VulnIDRefreshButton.Visible = $True
}

$handler_VulnIDBox_ColumnClick = {
  Reset-ListViewColumn $this $_.Column
}

$handler_VulnIDBox_MouseDown =
{
  $CKLInfoBox.Clear()
  $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.Textbox] } | ForEach-Object { $_.clear() }
  $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.Items.Clear() }

  $AFExpectedBox.SelectedIndex = -1
  $AFValTSBox.SelectedIndex = -1
  $AFValFSBox.SelectedIndex = -1

  $SupportedSTIGSBox.Visible = $False
  $CKLInfoBox.Visible = $True

  $handler_AFKeys_SelectedIndexChanged =
  {
    $Script:TempObj = ($AFItems | Where-Object { $_.VulnID -eq $VulnID }).AnswerKeys | Where-Object { $_.AnswerKey -eq $AFKeys.SelectedItem }
    
    $AFExpectedBox.SelectedIndex = -1
    $AFValTSBox.SelectedIndex = -1
    $AFValFSBox.SelectedIndex = -1

    $SaveAFKeyLabel.Visible = $False
    $SaveAFKeyButton.Visible = $False
    $DiscardAFKeyButton.Visible = $False

    $handler_AFExpectedBox_SelectionChangeCommitted =
    {
      Disable-Form
    }
    $handler_AFValTSBox_SelectionChangeCommitted =
    {
      Disable-Form
    }
    $handler_AFValFSBox_SelectionChangeCommitted =
    {
      Disable-Form
    }
    $handler_AFValCodeBox_KeyDown =
    {
      Disable-Form
    }
    $handler_AFValTCommBox_KeyDown =
    {
      Disable-Form
    }
    $handler_AFValFCommBox_KeyDown =
    {
      Disable-Form
    }

    $AFExpectedBox.add_SelectionChangeCommitted($handler_AFExpectedBox_SelectionChangeCommitted)
    $AFValTSBox.add_SelectionChangeCommitted($handler_AFValTSBox_SelectionChangeCommitted)
    $AFValFSBox.add_SelectionChangeCommitted($handler_AFValFSBox_SelectionChangeCommitted)
    $AFValCodeBox.add_KeyDown($handler_AFValCodeBox_KeyDown)
    $AFValTCommBox.add_KeyDown($handler_AFValTCommBox_KeyDown)
    $AFValFCommBox.add_KeyDown($handler_AFValFCommBox_KeyDown)

    $FoundVID = ($AFItems | Where-Object { $_.VulnID -eq $VulnID })
    $FoundAFKey =  $($FoundVID.AnswerKeys | Where-Object {$_.AnswerKey -eq $TempObj.AnswerKey})

    $AFExpectedBox.Text = $FoundAFKey.ExpectedStatus
    $AFValCodeBox.Text = $FoundAFKey.ValidationCode
    $AFValTSBox.Text = $FoundAFKey.ValidTrueStatus
    $AFValTCommBox.Text = $FoundAFKey.ValidTrueComment
    $AFValFSBox.Text = $FoundAFKey.ValidFalseStatus
    $AFValFCommBox.Text = $FoundAFKey.ValidFalseComment
  }

  $Script:VulnID = $VulnIDBox.SelectedItems.Text
  
  if ($OpenButton.Visible -eq $false) {
    if ($null -eq ($AFItems | Where-Object { $_.VulnID -eq $VulnID })) {
      $AFVulnKeys = New-Object System.Collections.Generic.List[System.Object]

      $NewObj = [PSCustomObject]@{
        AnswerKey         = $DefaultAFKey
        ExpectedStatus    = "Not_Reviewed"
        ValidationCode    = ""
        ValidTrueStatus   = ""
        ValidTrueComment  = ""
        ValidFalseStatus  = ""
        ValidFalseComment = ""
      }
      $AFVulnKeys.Add($NewObj)

      $NewObj = [PSCustomObject]@{
        VulnID     = $VulnID
        AnswerKeys = $AFVulnKeys
      }
      $AFItems.Add($NewObj)
    }

    $AFKeys.add_SelectedIndexChanged($handler_AFKeys_SelectedIndexChanged)
    $null = @("Not_Reviewed", "Open", "NotAFinding", "Not_Applicable") | ForEach-Object { $AFExpectedBox.Items.Add($_) }
    $null = @("Not_Reviewed", "Open", "NotAFinding", "Not_Applicable") | ForEach-Object { $AFValTSBox.Items.Add($_) }
    $null = @("Not_Reviewed", "Open", "NotAFinding", "Not_Applicable") | ForEach-Object { $AFValFSBox.Items.Add($_) }

    $STIGLabel.Text = "$STIG_Name AnswerFile ($VulnID)"
    if ($AFItems -match $VulnID){
      ForEach ($Key in ($AFItems -match $VulnID).AnswerKeys) {
        $null = $AFKeys.Items.Add($Key.AnswerKey)
        if ($DefaultAFKey){
          Try {
            $AFKeys.SelectedItem = $DefaultAFKey
          }
          Catch{}
        }
      }

      ($VulnIDBox.FindItemWithText("$VulnID")).SubItems[1].Text = "+"
    }
  }
  else{
    $STIGLabel.Text = "$STIG_Name (AnswerFile not loaded)"
  }

  $CKLInfoBox.SelectionFont = $BoldBoxFont
  $CKLInfoBox.AppendText("Rule Title: ")
  $CKLInfoBox.SelectionFont = $BoxFont
  $CKLInfoBox.AppendText("$(($STIGItems -match $VulnID).RuleTitle)`r`n`r`n")
  $CKLInfoBox.SelectionFont = $BoldBoxFont
  $CKLInfoBox.AppendText("Rule Discussion: ")
  $CKLInfoBox.SelectionFont = $BoxFont
  $CKLInfoBox.AppendText("$(($STIGItems -match $VulnID).RuleVuln_Discuss)`r`n`r`n")
  $CKLInfoBox.SelectionFont = $BoldBoxFont
  $CKLInfoBox.AppendText("Rule Check Text: ")
  $CKLInfoBox.SelectionFont = $BoxFont
  $CKLInfoBox.AppendText("$(($STIGItems -match $VulnID).RuleCheck_Content)")

  if ($AFItems){
    $OpenAddDelKeyLabel.Visible = $True
    $CreateAFKeyButton.Visible = $True
    $RemoveAFKeyButton.Visible = $True
    $RenameAFKeyButton.Visible = $True
  }
}

$handler_DarkModeButton_Click = {
  If ($DarkModeButton.Text -eq "Dark Mode Off"){
    $form1.BackColor = "DimGray"
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.Textbox] } | ForEach-Object { $_.BackColor = "Gray" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.BackColor = "Gray" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListView] } | ForEach-Object { $_.BackColor = "Gray" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListBox] } | ForEach-Object { $_.BackColor = "Gray" }
    $DarkModeButton.Text = "Dark Mode On"
  }
  elseif ($DarkModeButton.Text -eq "Dark Mode On") {
    $form1.BackColor = "Control"
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.Textbox] } | ForEach-Object { $_.BackColor = "White" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.BackColor = "White" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListView] } | ForEach-Object { $_.BackColor = "White" }
    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ListBox] } | ForEach-Object { $_.BackColor = "White" }
    $DarkModeButton.Text = "Dark Mode Off"
  }

  $AFValCodeBox.BackColor = "DarkBlue"
    $AFValCodeBox.ForeColor = "White"
}

$handler_formclose =
{
  if (($SaveButton.Enabled -eq $True) -and ($SaveButton.Visible -eq $True)){
    $confirm = [System.Windows.MessageBox]::Show("$AFFilePath is not saved. Save and Exit?", "Confirmation", "YesNo", "Question")

    if ($confirm -eq "Yes") {
      &$handler_SaveButton_Click
    }
  }

  1..3 | ForEach-Object {[GC]::Collect()}

  $form1.Dispose()
}

$form1 = New-Object System.Windows.Forms.Form
[Windows.Forms.Application]::EnableVisualStyles()

# Verify Evaluate-STIG files integrity
  if (Test-Path (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions")){
      # Import required modules
      $PowerShellVersion = $PsVersionTable.PSVersion

      If ($PowerShellVersion -lt [Version]"7.0") {
          Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions")
      }
      Else {
          Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions") -SkipEditionCheck
      }
  }
  else{
      Write-Host "ERROR: 'Modules' location detection failed.  Unable to continue." -ForegroundColor Red
      Return
  }

  $Verified = $true
  If (Test-Path (Join-Path -Path $PSScriptRoot -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
    [XML]$FileListXML = Get-Content -Path (Join-Path -Path $PSScriptRoot -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
    ForEach ($File in $FileListXML.FileList.File) {
      if ($File.ScanReq -eq "Required"){
        $Path = (Join-Path -Path $PsScriptRoot -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
        If (!(Test-Path $Path)) {
          $Verified = $false
        }
      }
    }
    If ($Verified -eq $False) {
        Write-Host "ERROR: One or more Evaluate-STIG files were not found.  Unable to continue." -ForegroundColor Yellow
        Return
    }
  }
  Else {
      Write-Host "ERROR: 'FileList.xml' not found.  Unable to verify content integrity." -ForegroundColor Red
      Return
  }

#----------------------------------------------
#region Generated Form Code

$form1.Text = "Manage AnswerFiles"
$form1.Name = "form1"
$form1.SuspendLayout()

$form1.AutoScaleDimensions =  New-Object System.Drawing.SizeF(96, 96)
$form1.AutoScaleMode  = [System.Windows.Forms.AutoScaleMode]::Dpi

$form1.FormBorderStyle = "FixedDialog"
$form1.StartPosition = "CenterScreen"
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1920
$System_Drawing_Size.Height = 1000
$form1.ClientSize = $System_Drawing_Size
$form1.StartPosition = "WindowsDefaultLocation"

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1150
$System_Drawing_Size.Height = 40
$STIGLabel.Size = $System_Drawing_Size
$STIGLabel.Text = "AnswerFile STIG Name"
$STIGLabel.AutoSize = $False
$STIGLabel.Font = $TitleFont
$STIGLabel.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 850
$System_Drawing_Point.Y = 5
$STIGLabel.Location = $System_Drawing_Point
$form1.Controls.Add($STIGLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 860
$System_Drawing_Size.Height = 40
$AFPathLabel.Size = $System_Drawing_Size
$AFPathLabel.Text = "AnswerFile Path"
$AFPathLabel.AutoSize = $false
$AFPathLabel.Font = $BoldBoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 915
$AFPathLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFPathLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 860
$System_Drawing_Size.Height = 40
$AFFileLabel.Size = $System_Drawing_Size
$AFFileLabel.Text = "AnswerFile FileName"
$AFFileLabel.AutoSize = $false
$AFFileLabel.Font = $BoldBoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 960
$AFFileLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFFileLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 480
$VulnIDBox.Size = $System_Drawing_Size
$VulnIDBox.Name = "VulnIDBox"
$VulnIDBox.View = "Details"
$VulnIDBox.MultiSelect = $false
$VulnIDBox.FullRowSelect = $true
$VulnIDBox.Font = $BoxFont
$VulnIDBox.HideSelection = $False
$NameColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $VulnIDBox.Columns.Add($NameColumn)
$NameColumn.text = "Vuln ID"
$NameColumn.width = "125"
$InAFColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $VulnIDBox.Columns.Add($InAFColumn)
$InAFColumn.text = "AF"
$InAFColumn.width = "40"
$CatColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $VulnIDBox.Columns.Add($CatColumn)
$CatColumn.text = "CAT"
$CatColumn.width = "50"
$StatusColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $VulnIDBox.Columns.Add($StatusColumn)
$StatusColumn.text = "CKL Status"
$StatusColumn.width = "245"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 70
$VulnIDBox.Location = $System_Drawing_Point
$VulnIDBox.add_ItemSelectionChanged($handler_VulnIDBox_MouseDown)
$VulnIDBox.add_ColumnClick($handler_VulnIDBox_ColumnClick)
$form1.Controls.Add($VulnIDBox)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 320
$AFErrorBox.Size = $System_Drawing_Size
$AFErrorBox.Name = "AFErrorBox"
$AFErrorBox.View = "Details"
$AFErrorBox.MultiSelect = $True
$AFErrorBox.FullRowSelect = $true
$AFErrorBox.Font = $BoxFont
$NameColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $AFErrorBox.Columns.Add($NameColumn)
$NameColumn.text = "Vuln ID"
$NameColumn.width = "150"
$ErrorColumn = New-Object System.Windows.Forms.ColumnHeader
$null = $AFErrorBox.Columns.Add($ErrorColumn)
$ErrorColumn.text = "Error"
$ErrorColumn.width = "260"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 645
$AFErrorBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFErrorBox)

$OpenButton.Name = "OpenButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 125
$System_Drawing_Size.Height = 80
$OpenButton.Size = $System_Drawing_Size
$OpenButton.UseVisualStyleBackColor = $True
$OpenButton.Text = "Open AnswerFile (XML/CSV)"
$OpenButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1660
$System_Drawing_Point.Y = 920
$OpenButton.Location = $System_Drawing_Point
$OpenButton.DataBindings.DefaultDataSourceUpdateMode = 0
$OpenButton.add_Click($handler_OpenButton_Click)
$form1.Controls.Add($OpenButton)
$OpenButton.Enabled = $False

$CreateButton.Name = "CreateButton"
$CreateButton.Size = $System_Drawing_Size
$CreateButton.UseVisualStyleBackColor = $True
$CreateButton.Text = "Create AnswerFile"
$CreateButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1795
$System_Drawing_Point.Y = 920
$CreateButton.Location = $System_Drawing_Point
$CreateButton.DataBindings.DefaultDataSourceUpdateMode = 0
$CreateButton.add_Click($handler_CreateButton_Click)
$form1.Controls.Add($CreateButton)
$CreateButton.Enabled = $False

$SaveButton.Name = "SaveButton"
$SaveButton.Size = $System_Drawing_Size
$SaveButton.UseVisualStyleBackColor = $True
$SaveButton.Text = "Save AnswerFile (XML)"
$SaveButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1790
$System_Drawing_Point.Y = 920
$SaveButton.Location = $System_Drawing_Point
$SaveButton.DataBindings.DefaultDataSourceUpdateMode = 0
$SaveButton.add_Click($handler_SaveButton_Click)
$form1.Controls.Add($SaveButton)

$StartOverButton.Name = "StartOverButton"
$StartOverButton.Size = $System_Drawing_Size
$StartOverButton.UseVisualStyleBackColor = $True
$StartOverButton.Text = "Close Answer File (XML)"
$StartOverButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1660
$System_Drawing_Point.Y = 920
$StartOverButton.Location = $System_Drawing_Point
$StartOverButton.add_Click($handler_StartOverButton_Click)
$form1.Controls.Add($StartOverButton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 400
$System_Drawing_Size.Height = 875
$SupportedSTIGSBox.Size = $System_Drawing_Size
$SupportedSTIGSBox.Name = "SupportedSTIGSBox"
$SupportedSTIGSBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 40
$System_Drawing_Point.Y = 50
$SupportedSTIGSBox.Location = $System_Drawing_Point
$SupportedSTIGSBox.add_DoubleClick($handler_SupportedSTIGSBox_DoubleClick)
$form1.Controls.Add($SupportedSTIGSBox)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 435
$System_Drawing_Size.Height = 855
$CKLInfoBox.Size = $System_Drawing_Size
$CKLInfoBox.Name = "CKLInfoBox"
$CKLInfoBox.Multiline = $True
$CKLInfoBox.Scrollbars = "Both"
$CKLInfoBox.Readonly = $True
$CKLInfoBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 10
$System_Drawing_Point.Y = 70
$CKLInfoBox.Location = $System_Drawing_Point
$form1.Controls.Add($CKLInfoBox)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 800
$System_Drawing_Size.Height = 40
$CKLLabel.Size = $System_Drawing_Size
$CKLLabel.AutoSize = $False
$CKLLabel.Font = $TitleFont
$CKLLabel.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 5
$CKLLabel.Location = $System_Drawing_Point
$form1.Controls.Add($CKLLabel)

$SaveAFKeyButton.Name = "SaveAFKeyButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 125
$System_Drawing_Size.Height = 45
$SaveAFKeyButton.Size = $System_Drawing_Size
$SaveAFKeyButton.UseVisualStyleBackColor = $True
$SaveAFKeyButton.Text = "Save Answer Key Changes"
$SaveAFKeyButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1775
$System_Drawing_Point.Y = 115
$SaveAFKeyButton.Location = $System_Drawing_Point
$SaveAFKeyButton.DataBindings.DefaultDataSourceUpdateMode = 0
$SaveAFKeyButton.add_Click($handler_SaveAFKeyButton_Click)
$form1.Controls.Add($SaveAFKeyButton)

$DiscardAFKeyButton.Name = "DiscardAFKeyButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 125
$System_Drawing_Size.Height = 45
$DiscardAFKeyButton.Size = $System_Drawing_Size
$DiscardAFKeyButton.UseVisualStyleBackColor = $True
$DiscardAFKeyButton.Text = "Discard Answer Key Changes"
$DiscardAFKeyButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1650
$System_Drawing_Point.Y = 115
$DiscardAFKeyButton.Location = $System_Drawing_Point
$DiscardAFKeyButton.DataBindings.DefaultDataSourceUpdateMode = 0
$DiscardAFKeyButton.add_Click($handler_DiscardAFKeyButton_Click)
$form1.Controls.Add($DiscardAFKeyButton)

$CreateAFKeyButton.Name = "CreateAFKeyButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 100
$System_Drawing_Size.Height = 30
$CreateAFKeyButton.Size = $System_Drawing_Size
$CreateAFKeyButton.UseVisualStyleBackColor = $True
$CreateAFKeyButton.Text = "New Key"
$CreateAFKeyButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1230
$System_Drawing_Point.Y = 55
$CreateAFKeyButton.Location = $System_Drawing_Point
$CreateAFKeyButton.DataBindings.DefaultDataSourceUpdateMode = 0
$CreateAFKeyButton.add_Click($handler_CreateAFKeyButton_Click)
$form1.Controls.Add($CreateAFKeyButton)

$RemoveAFKeyButton.Name = "RemoveAFKeyButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 100
$System_Drawing_Size.Height = 30
$RemoveAFKeyButton.Size = $System_Drawing_Size
$RemoveAFKeyButton.UseVisualStyleBackColor = $True
$RemoveAFKeyButton.Text = "Delete Key"
$RemoveAFKeyButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1330
$System_Drawing_Point.Y = 55
$RemoveAFKeyButton.Location = $System_Drawing_Point
$RemoveAFKeyButton.DataBindings.DefaultDataSourceUpdateMode = 0
$RemoveAFKeyButton.add_Click($handler_RemoveAFKeyButton_Click)
$form1.Controls.Add($RemoveAFKeyButton)

$RenameAFKeyButton.Name = "RenameAFKeyButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 100
$System_Drawing_Size.Height = 30
$RenameAFKeyButton.Size = $System_Drawing_Size
$RenameAFKeyButton.UseVisualStyleBackColor = $True
$RenameAFKeyButton.Text = "Rename Key"
$RenameAFKeyButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1430
$System_Drawing_Point.Y = 55
$RenameAFKeyButton.Location = $System_Drawing_Point
$RenameAFKeyButton.DataBindings.DefaultDataSourceUpdateMode = 0
$RenameAFKeyButton.add_Click($handler_RenameAFKeyButton_Click)
$form1.Controls.Add($RenameAFKeyButton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 250
$System_Drawing_Size.Height = 30
$AFKeyLabel.Size = $System_Drawing_Size
$AFKeyLabel.Text = "AnswerKey:"
$AFKeyLabel.AutoSize = $false
$AFKeyLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 50
$AFKeyLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFKeyLabel)

$AFExpectedLabel.Size = $System_Drawing_Size
$AFExpectedLabel.Text = "Expected Status:"
$AFExpectedLabel.AutoSize = $false
$AFExpectedLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 120
$AFExpectedLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFExpectedLabel)

$AFValCodeLabel.Size = $System_Drawing_Size
$AFValCodeLabel.Text = "Validate Code:"
$AFValCodeLabel.AutoSize = $false
$AFValCodeLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 170
$AFValCodeLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFValCodeLabel)

$AFValTSLabel.Size = $System_Drawing_Size
$AFValTSLabel.Text = "Valid True Status:"
$AFValTSLabel.AutoSize = $false
$AFValTSLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 405
$AFValTSLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFValTSLabel)

$AFValTCommLabel.Size = $System_Drawing_Size
$AFValTCommLabel.Text = "Valid True Comment:"
$AFValTCommLabel.AutoSize = $false
$AFValTCommLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 455
$AFValTCommLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFValTCommLabel)

$AFValFSLabel.Size = $System_Drawing_Size
$AFValFSLabel.Text = "Valid False Status:"
$AFValFSLabel.AutoSize = $false
$AFValFSLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 650
$AFValFSLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFValFSLabel)

$AFValFCommLabel.Size = $System_Drawing_Size
$AFValFCommLabel.Text = "Valid False Comment:"
$AFValFCommLabel.AutoSize = $false
$AFValFCommLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 710
$AFValFCommLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFValFCommLabel)

$AFValCodeIDEButton.Name = "AFValCodeIDEButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 120
$System_Drawing_Size.Height = 60
$AFValCodeIDEButton.Size = $System_Drawing_Size
$AFValCodeIDEButton.UseVisualStyleBackColor = $True
$AFValCodeIDEButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 800
$System_Drawing_Point.Y = 205
$AFValCodeIDEButton.Location = $System_Drawing_Point
$AFValCodeIDEButton.add_Click($handler_AFValCodeIDE_Click)
$form1.Controls.Add($AFValCodeIDEButton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 30
$StartHereLabel.Size = $System_Drawing_Size
$StartHereLabel.Text = "Start by DoubleClicking STIG"
$StartHereLabel.AutoSize = $false
$StartHereLabel.Font = $BodyFont
$StartHereLabel.ForeColor = "Green"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 70
$System_Drawing_Point.Y = 940
$StartHereLabel.Location = $System_Drawing_Point
$form1.Controls.Add($StartHereLabel)

$NextStepLabel.Size = $System_Drawing_Size
$NextStepLabel.Text = "Open/Create Answer File ->"
$NextStepLabel.AutoSize = $false
$NextStepLabel.Font = $BodyFont
$NextStepLabel.ForeColor = "Green"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1325
$System_Drawing_Point.Y = 940
$NextStepLabel.Location = $System_Drawing_Point
$form1.Controls.Add($NextStepLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 350
$System_Drawing_Size.Height = 30
$OpenAddDelKeyLabel.Size = $System_Drawing_Size
$OpenAddDelKeyLabel.Text = "<- Select/Manage AnswerKey"
$OpenAddDelKeyLabel.AutoSize = $false
$OpenAddDelKeyLabel.Font = $BodyFont
$OpenAddDelKeyLabel.ForeColor = "Green"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1530
$System_Drawing_Point.Y = 50
$OpenAddDelKeyLabel.Location = $System_Drawing_Point
$form1.Controls.Add($OpenAddDelKeyLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 500
$System_Drawing_Size.Height = 30
$SaveAFKeyLabel.Size = $System_Drawing_Size
$SaveAFKeyLabel.AutoSize = $false
$SaveAFKeyLabel.Font = $BodyFont
$SaveAFKeyLabel.ForeColor = "Red"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 120
$SaveAFKeyLabel.Location = $System_Drawing_Point
$form1.Controls.Add($SaveAFKeyLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 250
$System_Drawing_Size.Height = 30
$VulnIDStepLabel.Size = $System_Drawing_Size
$VulnIDStepLabel.Text = "Select Vuln ID from CKL"
$VulnIDStepLabel.AutoSize = $false
$VulnIDStepLabel.Font = $BodyFont
$VulnIDStepLabel.ForeColor = "Green"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 490
$System_Drawing_Point.Y = 40
$VulnIDStepLabel.Location = $System_Drawing_Point
$form1.Controls.Add($VulnIDStepLabel)

$AFErrorLabel.Size = $System_Drawing_Size
$AFErrorLabel.Text = "AnswerFile Errors"
$AFErrorLabel.AutoSize = $false
$AFErrorLabel.Font = $BodyFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 515
$System_Drawing_Point.Y = 605
$AFErrorLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFErrorLabel)

$AFErrorRemVulnIDButton.Name = "AFErrorRemVulnIDButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 170
$System_Drawing_Size.Height = 30
$AFErrorRemVulnIDButton.Size = $System_Drawing_Size
$AFErrorRemVulnIDButton.UseVisualStyleBackColor = $True
$AFErrorRemVulnIDButton.Text = "Delete VulnID"
$AFErrorRemVulnIDButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 965
$AFErrorRemVulnIDButton.Location = $System_Drawing_Point
$AFErrorRemVulnIDButton.DataBindings.DefaultDataSourceUpdateMode = 0
$AFErrorRemVulnIDButton.add_Click($handler_AFErrorRemVulnIDButton_Click)
$form1.Controls.Add($AFErrorRemVulnIDButton)

$AFErrorRefreshButton.Name = "AFErrorRefreshButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 130
$System_Drawing_Size.Height = 30
$AFErrorRefreshButton.Size = $System_Drawing_Size
$AFErrorRefreshButton.UseVisualStyleBackColor = $True
$AFErrorRefreshButton.Text = "Refresh Error List"
$AFErrorRefreshButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 635
$System_Drawing_Point.Y = 965
$AFErrorRefreshButton.Location = $System_Drawing_Point
$AFErrorRefreshButton.DataBindings.DefaultDataSourceUpdateMode = 0
$AFErrorRefreshButton.add_Click($handler_AFErrorRefreshButton_Click)
$form1.Controls.Add($AFErrorRefreshButton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 100
$AddOutputLabel.Size = $System_Drawing_Size
$AddOutputLabel.Text = "Additional Output Types:"
$AddOutputLabel.AutoSize = $false
$AddOutputLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1610
$System_Drawing_Point.Y = 895
$AddOutputLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AddOutputLabel)

$AFKeys.Name = "AFKeys"
$AFKeys.Font = $BoxFont
$AFKeys.Width = 150
$AFKeys.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 55
$AFKeys.Location = $System_Drawing_Point
$form1.Controls.Add($AFKeys)

$HLine.Text = ""
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1070
$System_Drawing_Size.Height = 2
$HLine.Size = $System_Drawing_Size
$HLine.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 100
$HLine.Location = $System_Drawing_Point
$form1.Controls.Add($HLine)

$VLine.Text = ""
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 2
$System_Drawing_Size.Height = 1900
$VLine.Size = $System_Drawing_Size
$VLine.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 0
$VLine.Location = $System_Drawing_Point
$form1.Controls.Add($VLine)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 850
$System_Drawing_Size.Height = 210
$AFValCodeBox.Size = $System_Drawing_Size
$AFValCodeBox.Name = "AFValCodeBox"
$AFValCodeBox.Multiline = $True
$AFValCodeBox.Scrollbars = "Vertical"
$AFValCodeBox.Font = $BoxFont
$AFValCodeBox.BackColor = "DarkBlue"
$AFValCodeBox.ForeColor = "White"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 170
$AFValCodeBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFValCodeBox)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 850
$System_Drawing_Size.Height = 180
$AFValTCommBox.Size = $System_Drawing_Size
$AFValTCommBox.Name = "AFValTCommBox"
$AFValTCommBox.Multiline = $True
$AFValTCommBox.Scrollbars = "Vertical"
$AFValTCommBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 455
$AFValTCommBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFValTCommBox)

$AFValFCommBox.Size = $System_Drawing_Size
$AFValFCommBox.Name = "AFValFCommBox"
$AFValFCommBox.Multiline = $True
$AFValFCommBox.Scrollbars = "Vertical"
$AFValFCommBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 710
$AFValFCommBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFValFCommBox)

$AFExpectedBox.Name = "AFExpectedBox"
$AFExpectedBox.Font = $BoxFont
$AFExpectedBox.Width = 125
$AFExpectedBox.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 125
$AFExpectedBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFExpectedBox)

$AFValTSBox.Name = "AFValTSBox"
$AFValTSBox.Font = $BoxFont
$AFValTSBox.Width = 125
$AFValTSBox.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 405
$AFValTSBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFValTSBox)

$AFValFSBox.Name = "AFValFSBox"
$AFValFSBox.Font = $BoxFont
$AFValFSBox.Width = 125
$AFValFSBox.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1050
$System_Drawing_Point.Y = 655
$AFValFSBox.Location = $System_Drawing_Point
$form1.Controls.Add($AFValFSBox)

$HTMLCheckBox.Name = "HTMLCheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 50
$HTMLCheckBox.Size = $System_Drawing_Size
$HTMLCheckBox.Text = "HTML"
$HTMLCheckBox.Font = $BoxFont
$HTMLCheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1795
$System_Drawing_Point.Y = 885
$HTMLCheckBox.Location = $System_Drawing_Point
$HTMLCheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($HTMLCheckBox)

$CSVCheckBox.Name = "CSVCheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 50
$System_Drawing_Size.Height = 50
$CSVCheckBox.Size = $System_Drawing_Size
$CSVCheckBox.Text = "CSV"
$CSVCheckBox.Font = $BoxFont
$CSVCheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1870
$System_Drawing_Point.Y = 885
$CSVCheckBox.Location = $System_Drawing_Point
$CSVCheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($CSVCheckBox)

$OpenCheckBox.Name = "OpenCheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 35
$System_Drawing_Size.Height = 50
$OpenCheckBox.Size = $System_Drawing_Size
$OpenCheckBox.Text = "O"
$OpenCheckBox.Font = $BoxFont
$OpenCheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 535
$OpenCheckBox.Location = $System_Drawing_Point
$OpenCheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($OpenCheckBox)

$NRCheckBox.Name = "NRCheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 45
$System_Drawing_Size.Height = 50
$NRCheckBox.Size = $System_Drawing_Size
$NRCheckBox.Text = "NR"
$NRCheckBox.Font = $BoxFont
$NRCheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 515
$System_Drawing_Point.Y = 535
$NRCheckBox.Location = $System_Drawing_Point
$NRCheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($NRCheckBox)

$NFCheckBox.Name = "NFCheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 45
$System_Drawing_Size.Height = 50
$NFCheckBox.Size = $System_Drawing_Size
$NFCheckBox.Text = "NF"
$NFCheckBox.Font = $BoxFont
$NFCheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 580
$System_Drawing_Point.Y = 535
$NFCheckBox.Location = $System_Drawing_Point
$NFCheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($NFCheckBox)

$NACheckBox.Name = "NACheckBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 45
$System_Drawing_Size.Height = 50
$NACheckBox.Size = $System_Drawing_Size
$NACheckBox.Text = "NA"
$NACheckBox.Font = $BoxFont
$NACheckBox.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 645
$System_Drawing_Point.Y = 535
$NACheckBox.Location = $System_Drawing_Point
$NACheckBox.UseVisualStyleBackColor = $True
$form1.Controls.Add($NACheckBox)

$VulnIDRefreshButton.Name = "VulnIDRefreshButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 65
$System_Drawing_Size.Height = 30
$VulnIDRefreshButton.Size = $System_Drawing_Size
$VulnIDRefreshButton.UseVisualStyleBackColor = $True
$VulnIDRefreshButton.Text = "Refresh"
$VulnIDRefreshButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 700
$System_Drawing_Point.Y = 550
$VulnIDRefreshButton.Location = $System_Drawing_Point
$VulnIDRefreshButton.add_Click($handler_VulnIDRefreshButton_Click)
$form1.Controls.Add($VulnIDRefreshButton)

$DarkModeButton.Name = "DarkModeButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 120
$System_Drawing_Size.Height = 20
$DarkModeButton.Size = $System_Drawing_Size
$DarkModeButton.UseVisualStyleBackColor = $True
$DarkModeButton.Text = "Dark Mode Off"
$DarkModeButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 975
$DarkModeButton.Location = $System_Drawing_Point
$DarkModeButton.add_Click($handler_DarkModeButton_Click)
$form1.Controls.Add($DarkModeButton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 30
$AFMarkLabel.Size = $System_Drawing_Size
$AFMarkLabel.Text = "*Key in AF +Key Added Saved -Key Removed"
$AFMarkLabel.AutoSize = $false
$AFMarkLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 580
$AFMarkLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFMarkLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 20
$DefaultAFKeyLabel.Size = $System_Drawing_Size
$DefaultAFKeyLabel.AutoSize = $false
$DefaultAFKeyLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 940
$System_Drawing_Point.Y = 80
$DefaultAFKeyLabel.Location = $System_Drawing_Point
$form1.Controls.Add($DefaultAFKeyLabel)

$form1.ResumeLayout()

$SaveButton.Visible = $False
$StartOverButton.Visible = $False
$AFPathLabel.Visible = $False
$AFFileLabel.Visible = $False
$SaveAFKeyButton.Visible = $False
$DiscardAFKeyButton.Visible = $False
$CKLInfoBox.Visible = $False
$CreateAFKeyButton.Visible = $False
$RemoveAFKeyButton.Visible = $False
$RenameAFKeyButton.Visible = $False
$NextStepLabel.Visible = $False
$VulnIDStepLabel.Visible = $False
$AddOutputLabel.Visible = $False
$CSVCheckBox.Visible = $False
$HTMLCheckBox.Visible = $False
$SaveAFKeyLabel.Visible = $False
$OpenAddDelKeyLabel.Visible = $False
$OpenCheckBox.Visible = $False
$OpenCheckBox.Checked = $True
$NRCheckBox.Visible = $False
$NRCheckBox.Checked = $True
$NFCheckBox.Visible = $False
$NACheckBox.Visible = $False
$AFMarkLabel.Visible = $False
$VulnIDRefreshButton.Visible = $False
$AFErrorRefreshButton.Visible = $False
$AFErrorRemVulnIDButton.Visible = $False

#Init the OnLoad event to correct the initial state of the form
$InitialFormWindowState = $form1.WindowState

#Save the initial state of the form
$form1.add_Load($OnLoadForm_StateCorrection)

$form1.Add_FormClosed($handler_formclose)
#Show the Form
$null = [Windows.Forms.Application]::Run($form1)

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCTPMQHgD+sin8U
# PaiMOLQUafOyBA3ZEHMYXMSge6OUlqCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIK5ZeQk/
# B6cTFb6x9rDiEY3XO8SufXWLb86fXw1mMaFtMA0GCSqGSIb3DQEBAQUABIIBADBq
# huaVqCpHWSVeVs8sAWaHyXG4sRdvjbfZRrfMSyaovDUkBXzoOk+iWdy6Nq7qnfYf
# IBaY9Y9nklRZUqAnwCouR3jsHJkQfJxtBltOyYhLGuZGYsVIOu9h2R2noGb85UT9
# KGEM8RMoeK8xy+lW8XN+Cx8jNDb018RJM3rpYOMS3yaowA8r7KtNm25jass39AHA
# Vb+lsNfakJrE9dV0fbFti9p06L75NGT0G9l0qczgDFqdBe6KHnFWyTtw//qVdjUw
# aZCkO8FHw3h1sbEwjW9UsCR+whmyMQpcrk2S5D8ASjcEazS+tOraRCvE+bQRBlqM
# X0GQLr2E/0HvWJNy2RahggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNDA3MTI1OTQzWjAv
# BgkqhkiG9w0BCQQxIgQgbbsrhFxjXja4AZmCpeyhjVPLJHu2wv5ez4YE29PTnhIw
# DQYJKoZIhvcNAQEBBQAEggIAggRTkCKU3uUaUEYXbhbft55m1DsjfxDJigqEfoZ+
# vw9Fomn1T4Qci+TE9fJVbTk0HJPRKUKr86Gzz34Kk3VJZaKfUCTGD45tiNzNfmWT
# ME0HF5yxpMp1OQfkvgAFMqEnGw01MtmsKIC4dB3LlZeYgB/AjtvQsIiUovTsOfuD
# 0WzFkwPIDRWCK3N7Q03iP7IDs5QVYSNePvc0hKc9UW150w66I3OUvvl71EmHDhta
# QNBAn+Daedhn/9U+z/r4OElGfYY6TA/19OqmAI3GoglOHNvIUC5AB3rlIPCxCSNS
# /cI2VANQdjHuhfn37VH7DUBUSaDBwFEltscBDGgop/8nItqLu2OZTRTnseg3l7pj
# tK8jeSF/iwoj0QKI/UgCmb9s1ciFeRV6zi8M5ekluwxuW/OkAu4Jzgq3dp5Zls1A
# 8kJFJja5W55xNGGW27tufkfBZECXBpf8mTZrZpLCM2MKOhON88OD0CXgVN10FjAt
# foxMe+TTsxbhKI94d63MHJ17xOkyVFKJiq/o5oHGpFYcA9fzYZU07JWHzRio2pBE
# pASaVjjl6Y0B7WtVsAJzeQ6iEmFVNrO8x1PlVK4YVD7fWbWDeZZAreoSPkFsimYe
# h3aCKZsEioMXRtKGsPj4RMD6W/a9TK7SkJNgUX7o6PTRtO6OTs7rnoshVlzldoEt
# aG8=
# SIG # End signature block
