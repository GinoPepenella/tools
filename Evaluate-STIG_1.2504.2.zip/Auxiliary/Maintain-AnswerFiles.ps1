<#
    .Synopsis
    Performs maintenance on Evaluate-STIG answer files.
    .DESCRIPTION
    Performs simple maintenance on Evaluate-STIG Answer Files.  Updates Vuln IDs to new STIGs that have been converted to DISA's new conten management system.  It also identifies and optionally removes answers for Vuln IDs that have been removed from the STIG.  Finally, it will convert answer files from previous format to new format compatible with 1.2104.3 and greater.

    Unless -NoBackup is specified, a backup of an answer file that is determined to need updating is automatically created with a .bak extension and stored in the same path as the answer file.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG'

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be noted but not changed.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -RemoveMissingVulnIDs

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -RemoveMissingVulnIDs -NoBackup

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.  Disables backup of answer files that are updated.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -AFPath '\\Server1\AnswerFiles' -RemoveMissingVulnIDs -NoBackup

    This will analyze all answer files found in \\Server1\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.  Disables backup of answer files that are updated.
    .INPUTS
    -ESPath
    Path to the Evaluate-STIG directory.  This is a required parameter.

    -AFPath
    Path that contains XML answer files.  If not specified, defaults to <ESPath>\AnswerFiles.

    -NoBackup
    Disables the creation of a backup file (.bak) for answer files that are updated.

    -RemoveMissingVulnIDs
    When specified, will automatically omit any vuln IDs in the current Answer File that is not in the STIG from the new Answer File.  Useful for cleaning up answers for STIG items that have been removed.  This parameter is optional.
    .LINK
    Evaluate-STIG
    https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig
#>
[CmdletBinding(DefaultParameterSetName='None')]
Param (
    [Parameter(Mandatory=$true)]
    [String]$ESPath,

    [Parameter(Mandatory = $false)]
    [String]$AFPath,

    [Parameter(Mandatory=$false)]
    [Switch]$NoBackup,

    [Parameter(Mandatory=$false)]
    [Switch]$RemoveMissingVulnIDs
    )

Function Test-XmlValidation {
    # Based on code samples from https://stackoverflow.com/questions/822907/how-do-i-use-powershell-to-validate-xml-files-against-an-xsd

    Param (
        [Parameter(Mandatory = $true)]
        [String] $XmlFile,

        [Parameter(Mandatory = $true)]
        [String] $SchemaFile
    )

    Try {
        Get-ChildItem $XmlFile -ErrorAction Stop | Out-Null
        Get-ChildItem $SchemaFile -ErrorAction Stop | Out-Null

        $XmlErrors = New-Object System.Collections.Generic.List[System.Object]
        [Scriptblock] $ValidationEventHandler = {
            If ($_.Exception.LineNumber) {
                $Message = "$($_.Exception.Message) Line $($_.Exception.LineNumber), position $($_.Exception.LinePosition)."
            }
            Else {
                $Message = ($_.Exception.Message)
            }

            $NewObj = [PSCustomObject]@{
                Message = $Message
            }
            $XmlErrors.Add($NewObj)
        }

        $ReaderSettings = New-Object -TypeName System.Xml.XmlReaderSettings
        $ReaderSettings.ValidationType = [System.Xml.ValidationType]::Schema
        $ReaderSettings.ValidationFlags = [System.Xml.Schema.XmlSchemaValidationFlags]::ProcessIdentityConstraints -bor [System.Xml.Schema.XmlSchemaValidationFlags]::ProcessSchemaLocation -bor [System.Xml.Schema.XmlSchemaValidationFlags]::ReportValidationWarnings
        $ReaderSettings.Schemas.Add($null, $SchemaFile) | Out-Null
        $readerSettings.add_ValidationEventHandler($ValidationEventHandler)

        Try {
            $Reader = [System.Xml.XmlReader]::Create($XmlFile, $ReaderSettings)
            While ($Reader.Read()) {
            }
        }
        Catch {
            $NewObj = [PSCustomObject]@{
                Message = ($_.Exception.Message)
            }
            $XmlErrors.Add($NewObj)
        }
        Finally {
            $Reader.Close()
        }

        If ($XmlErrors) {
            Return $XmlErrors
        }
        Else {
            Return $true
        }
    }
    Catch {
        Return $_.Exception.Message
    }
}

Try {
    $ErrorActionPreference = "Stop"

    If (-Not($AFPath)) {
        $AFPath = Join-Path -Path $ESPath -ChildPath "AnswerFiles"
    }

    # Verify version of Evaluate-STIG is supported version.
    $SupportedVer = [Version]"1.2401.0"
    Get-Content (Join-Path -Path $ESPath -ChildPath "Evaluate-STIG.ps1") | ForEach-Object {
        If ($_ -like '*$EvaluateStigVersion = *') {
            $Version = [Version]((($_ -split "=")[1]).Trim() -replace '"','')
            Return
        }
    }
    If (-Not($Version -ge $SupportedVer)) {
        Throw "Error: Evaluate-STIG $SupportedVer or greater required.  Found $Version.  Please update Evaluate-STIG to a supported version before using this script."
    }

    # Validate STIGList.xml and answer file for proper schema usage.
    $STIGList_xsd = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
    $AnswerFile_xsd = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "Schema_AnswerFile.xsd"

    # STIGList.xml validation
    $XmlFile = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
    If (-Not(Test-Path $XmlFile)) {
        Throw "Error: '$XmlFile' - file not found.  Cannot continue."
    }
    ElseIf (-Not(Test-Path $STIGList_xsd)) {
        Throw "Error: '$STIGList_xsd' - file not found.  Cannot continue."
    }
    ElseIf (-Not(Test-Path $AnswerFile_xsd)) {
        Throw "Error: '$AnswerFile_xsd' - file not found.  Cannot continue."
    }

    $Result = Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd
    If ($Result -ne $true) {
        ForEach ($Item in $Result.Message) {
            $Message += $Item | Out-String
        }
        Throw $Message
    }

    # Get list of supported STIGs
    [XML]$STIGList = Get-Content (Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml")
    $STIGsToProcess = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($Node in $STIGList.List.ChildNodes) {
        $NewObj = [PSCustomObject]@{
            Name        = $Node.Name
            ShortName   = $Node.ShortName
            StigContent = $Node.StigContent
        }
        $STIGsToProcess.Add($NewObj)
    }

    # Get STIG AnswerFiles
    $AnswerFileList = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($Item in (Get-ChildItem -Path $AFPath | Sort-Object LastWriteTime | Where-Object Extension -eq ".xml")) {
        Try {
            $CurrentSchema = $true
            If ((Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $AnswerFile_xsd) -ne $true) {
                $CurrentSchema = $false
            }

            [XML]$Content = Get-Content $Item.FullName
            If ($Content.STIGComments.Name) {
                If (-Not(($Content.STIGComments.Name -in $STIGsToProcess.Name) -or ($Content.STIGComments.Name -in $STIGsToProcess.ShortName))) {
                    Write-Host "'$($Item.Name)' is for '$($Content.STIGComments.Name)' which is not listed in -ListSupportedProducts.  Will ignore this Answer file." -ForegroundColor Yellow
                }
                Else {
                    $StigContent = ($STIGsToProcess | Where-Object {($_.Name -eq $Content.STIGComments.Name) -or ($_.ShortName -eq $Content.STIGComments.Name)}).StigContent
                    $Template = Join-Path -Path $ESPath -ChildPath "StigContent" | Join-Path -ChildPath $StigContent
                    $NewObj = [PSCustomObject]@{
                        STIG           = $Content.STIGComments.Name
                        AnswerFile     = $Item.Name
                        AnswerFilePath = $Item.FullName
                        Template       = $Template
                        CurrentSchema  = $CurrentSchema
                    }
                    $AnswerFileList.Add($NewObj)
                }
            }
            Else {
                Write-Host "'$($Item.FullName)' is a duplicate Answer File for '$($Content.STIGComments.Name)'.  Will ignore this Answer File." -ForegroundColor Yellow
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        }
    }

    ForEach ($File in $AnswerFileList) {
        Write-Host ""
        Write-Host "Processing $($File.AnswerFilePath) ..." -ForegroundColor Gray
        $AnswerFileText = [XML](Get-Content $File.AnswerFilePath)
        $ChecklistXML = [XML](Get-Content $File.Template)
        $STIGItems = New-Object System.Collections.Generic.List[System.Object]
        $LegacyIDs = New-Object System.Collections.ArrayList
        ForEach ($Object in $ChecklistXML.Benchmark.Group) {
            If ($Object.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"}) {
                Foreach ($legacy in ($Object.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"} | Sort-Object '#text')) {
                    $null = $LegacyIDs.Add($($legacy.'#text'))
                }
            }
            $NewObj = [PSCustomObject]@{
                RuleTitle = $Object.rule.title
                LegacyVulnID = (Select-String -InputObject $LegacyIDS -Pattern "V-\d{4,}" | ForEach-Object {$_.Matches}).Value
                VulnID = $($Object.id)
                }
            $STIGItems.Add($NewObj)
            }

        $UpdateAnswerFile = $false
        ForEach ($Element in $AnswerFileText.STIGComments.Vuln) {
            If ($Element.ID -in $STIGItems.LegacyVulnID) {
                $UpdateAnswerFile = $true
                Write-Host "  Converting '$($Element.ID)' in Answer File to '$(($STIGItems | Where-Object LegacyVulnID -eq $Element.ID).VulnID)'" -ForegroundColor Gray
                $Element.ID = "$(($STIGItems | Where-Object LegacyVulnID -eq $Element.ID).VulnID)"
                If ($Element.'#comment' -ne ($STIGItems | Where-Object VulnID -eq $Element.ID).RuleTitle) {
                    $UpdateAnswerFile = $true
                    Write-Host "  Adding Rule Title as comment to '$($Element.ID)'" -ForegroundColor Gray
                }
            }
            ElseIf ($Element.ID -notin $STIGItems.VulnID) {
                If ($RemoveMissingVulnIDs) {
                    $UpdateAnswerFile = $true
                    Write-Host "  '$($Element.ID)' is not found in the STIG and has been removed from '$($File.AnswerFile)'" -ForegroundColor Yellow
                    $null = $Element.ParentNode.RemoveChild($Element)
                }
                Else {
                    Write-Host "  '$($Element.ID)' is not found in the STIG and may be removed from '$($File.AnswerFile)'" -ForegroundColor Yellow
                }
            }
            ElseIf ($Element.'#comment' -ne ($STIGItems | Where-Object VulnID -eq $Element.ID).RuleTitle) {
                $UpdateAnswerFile = $true
                If ($Element.ID -in $STIGItems.VulnID) {
                    Write-Host "  Adding Rule Title as comment to '$($Element.ID)'" -ForegroundColor Gray
                }
            }
        }
        If ($UpdateAnswerFile -eq $true -or $File.CurrentSchema -ne $true) {
            If (-Not($NoBackup)) {
                $BackupPath = Join-Path -Path $AFPath -ChildPath "Backup"
                If (-Not(Test-Path $BackupPath)) {
                    Write-Host "  Creating backup folder" -ForegroundColor Gray
                    New-Item -Path $BackupPath -ItemType Directory | Out-Null
                }
                Write-Host "  Creating copy of $($File.AnswerFile) under $($BackupPath)" -ForegroundColor Gray
                $BackupPath = Join-Path -Path $AFPath -ChildPath "Backup"
                Copy-Item $File.AnswerFilePath -Destination "$($BackupPath)\$($File.AnswerFile).bak" | Out-Null
            }

            If ($File.CurrentSchema -ne $true) {
                Write-Host "  Converting Answer File to new schema" -ForegroundColor Gray
            }

            # Write new Answer File
            $NewAnswerFile = $File.AnswerFilePath

            $Encoding = [System.Text.Encoding]::UTF8
            $XmlWriter = New-Object System.Xml.XmlTextWriter($NewAnswerFile, $Encoding)
            $XmlWriter.Formatting = "Indented"
            $XmlWriter.Indentation = 2

            $XmlWriter.WriteStartDocument()

            # Add Comment section
            $XmlWriter.WriteComment('**************************************************************************************
            This file contains answers for known opens and findings that cannot be evaluated through technical means.
            <STIGComments Name> must match the STIG ShortName or Name in -ListSupportedProducts.  When a match is found, this answer file will automatically for the STIG.
            <Vuln ID> is the STIG VulnID.  Multiple Vuln ID sections may be specified in a single Answer File.
            <AnswerKey Name> is the name of the key assigned to the answer.  "DEFAULT" can be used to apply the comment to any asset.  Multiple AnswerKey Name sections may be configured within a single Vuln ID section.
              *Note: If the Answer Key matches the hostname *exactly*, it will supersede any other key for the Vulnerability ID.  
               Multiple hostnames can be used, separated by either a space or a comma.
            <ExpectedStatus> is the initial status after the checklist is created.  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".
            <ValidationCode> must be Powershell code that returns a True/False value or a PSCustomObject.  If blank, "true" is assumed.
              *Note: If Validation Code returns a PSCustomObject, the Object MUST contain both "Results" and "Valid" keys.  "Results" will be written to the Comments field of the STIG check.
            <ValidTrueStatus> is the status the check should be set to if ValidationCode returns "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
            <ValidTrueComment> is the verbiage to add to the Comments section if ValidationCode returns "true".
            <ValidFalseStatus> is the status the check should be set to if ValidationCode DOES NOT return "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
            <ValidFalseComment> is the verbiage to add to the Comments section if ValidationCode DOES NOT return "true".
            **************************************************************************************')

            # Create STIGComments node
            $att_Name = $AnswerFileText.STIGComments.Name
            $XmlWriter.WriteStartElement("STIGComments")
            $XmlWriter.WriteAttributeString("Name", $att_Name)

            # Create Vuln nodes
            ForEach ($Vuln in $AnswerFileText.STIGComments.Vuln) {
                $att_ID = $Vuln.ID
                $XmlWriter.WriteStartElement("Vuln")
                $XmlWriter.WriteAttributeString("ID", $att_ID)
                If ($STIGItems | Where-Object VulnID -eq $Vuln.ID) {
                    $XmlWriter.WriteComment(($STIGItems | Where-Object VulnID -eq $Vuln.ID).RuleTitle)
                }
                Else {
                    $XmlWriter.WriteComment("WARNING: $($Vuln.ID) is not part of the STIG and may be removed from this answer file.")
                }

                # Create AnswerKey nodes
                ForEach ($Key in $Vuln.AnswerKey) {
                    $att_Name = $Key.Name
                    $XmlWriter.WriteStartElement("AnswerKey")
                    $XmlWriter.WriteAttributeString("Name", $att_Name)

                    #Create sub nodes
                    $XmlWriter.WriteStartElement("ExpectedStatus")
                    $XmlWriter.WriteString($Key.ExpectedStatus)
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidationCode")
                    If ($Key.ValidationCode) {
                        $XmlWriter.WriteString($Key.ValidationCode)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidTrueStatus")
                    If ($File.CurrentSchema -eq $true) {
                        If ($Key.ValidTrueStatus) {
                            $XmlWriter.WriteString($Key.ValidTrueStatus)
                        }
                        Else {
                            $XmlWriter.WriteWhitespace("")
                        }
                    }
                    Else {
                        $XmlWriter.WriteString($Key.FinalStatus)
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidTrueComment")
                    If ($File.CurrentSchema -eq $true) {
                        If ($Key.ValidTrueComment) {
                            $XmlWriter.WriteString($Key.ValidTrueComment)
                        }
                        Else {
                            $XmlWriter.WriteWhitespace("")
                        }
                    }
                    Else {
                        $XmlWriter.WriteString($Key.ApprovedComment)
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidFalseStatus")
                    If ($Key.ValidFalseStatus) {
                        $XmlWriter.WriteString($Key.ValidFalseStatus)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidFalseComment")
                    If ($Key.ValidFalseComment) {
                        $XmlWriter.WriteString($Key.ValidFalseComment)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    # Close AnswerKey node
                    $XmlWriter.WriteEndElement()
                }
                # Close Vuln node
                $XmlWriter.WriteEndElement()
            }
            $XmlWriter.WriteEndElement()

            $XmlWriter.WriteEnddocument()
            $XmlWriter.Flush()
            $XmlWriter.Close()

            Write-Host "  $($File.AnswerFile) successfully updated." -ForegroundColor DarkGreen
        }
        Else {
            Write-Host "  $($File.AnswerFile) does not require updating." -ForegroundColor Cyan
        }
    }
    Write-Host
    Write-Host "Processing complete!" -ForegroundColor Green
}
Catch {
    Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDSYpXso5FSS3p5
# zIx4zQB4cTkVaxdnafDmzczuWCtxoKCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIN3Anf7f
# DqksRG6Ic9T14Ewh2nZqf/ezBtW+CT7tJRVOMA0GCSqGSIb3DQEBAQUABIIBAC74
# dvCUZJsY7R1ilRLca9iYJ9NhI8I3TqVMYZqeWWcFx/neoRuzmrR4aKSeQvjhH20d
# HS3s2RVNuG8Eqjy1GlOTiCtOqHouvQ27Qj/mLpxhVOf7iHGG+8MYnUKTLBJRwPCb
# DENWf0tXZuTzGkb2ibk9i7FhynT196yehhkxXf+IDCPxcuQ0535pjI9AOF+Epa4h
# 2oLYm9K6jLR/QtE6vLoFBDfRLmqwQX1RFFzCtDnhyuo3nClbjpTBnygQ1iBSnBZX
# OXn2Ie+x5WEe7zdhI9yiEIPP2d0Hh0N1YM2N1s9xPJmcobZWJKbiCvsXSg0RoPWZ
# 9qyUj9wSjrZbTmfZrEyhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNDA3MTI1MzU3WjAv
# BgkqhkiG9w0BCQQxIgQgUZh/T66VSJlrrT7vQ9KSKEdb2uCDMyaWhnKp7zirltgw
# DQYJKoZIhvcNAQEBBQAEggIAgUmWZgnDuaq1tNfokZsJ8i490ObfRfumsksGL/xC
# oHepqHrTeRMpuJbbOF5BGAmBiqY0hfFI2zSZ68IGZZvm5nYRdJbqn37/gS9TE/6M
# fRjcLpW7bHLss7RBxF6VdWs/oSfXCo+LvrFigVAZPPegwvAXd4oTZH7po1/tUygk
# TZeSFYG/M2aodp4E/Gf1ce8VJ10kgJ4xCunQsh7qltcp6uzMX0Z61IVYpil2AubB
# B5fwyojmDAEEXrMP+JSRH4RRtUZrWie5TKlVqxenNfGSpKaHxWURHpNxCJbeZsjL
# BP7kuxILzLe4VPAhNSql/QXHZ4khzNG74DTPu98piw4KUKlVAr30L1A3dfUmhMam
# sVwykW5ma96AyNCzYOmsdEh5jEIifD72c2M07cnrfF/P1pdWTBIE1rvgKoFdFlJW
# z98zByMHs3ghPraxOYJAC+yMXNcmEucnjso8ljTH/Jnfxaa4b+7SGs9t4DJKVbwY
# 921QhsPC73WHLFIo9dn3Mdxg3JPNGXxOjxICpyKA8NTbRml/jEEixWC1fzwANCfI
# epHH1ia/o7j0epNDFrWv6I3NfBa5oAhAZ+LucaWo6lDdJJrNpWPz0k313ejsPv79
# yCBCrns5JPV8sxHkI4Se9yIyTq7aAp2cqLL3eqbmmTsvKVaoZhFOEE9fstGnCtz3
# YYE=
# SIG # End signature block
