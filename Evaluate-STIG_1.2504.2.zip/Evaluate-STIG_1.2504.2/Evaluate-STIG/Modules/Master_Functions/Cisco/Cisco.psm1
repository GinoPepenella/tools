#####################################
# Cisco functions for Evaluate-STIG #
#####################################

Function Get-CiscoShowTechData {
    Param (
        [Parameter(Mandatory = $true)]
        [psobject]$ShowTech,

        [Parameter(Mandatory = $true)]
        [ValidateSet("Inventory", "RunningConfig", "Version")]
        [String]$DataType
    )

    Try {
        Switch ($DataType) {
            "Inventory" {
                #This pulls show inventory section from show tech config file
                $startSTR = "^-{18} show inventory -{18}"
                $endSTR = "^-{18} show *"
                $startIndex = ($ShowTech | Select-String $startSTR | Select-Object -First 1).LineNumber[0]
                $endIndex = ($ShowTech | Select-String ($ShowTech | Select-Object -Index ($startIndex..$ShowTech.Count) | Select-String $endSTR | Select-Object -First 1)[0]).LineNumber[0]
                $Result = $ShowTech | Select-Object -Index (($startIndex - 1)..($endIndex - 2))
            }
            "RunningConfig" {
                #This pulls show running-config section from show tech config file
                $startSTR = "^-{18} show running-config -{18}"
                $endSTR = "^-{18} show *"
                $startIndex = ($ShowTech | Select-String $startSTR | Select-Object -First 1).LineNumber[0]
                $endIndex = ($ShowTech | Select-String ($ShowTech | Select-Object -Index ($startIndex..$ShowTech.Count) | Select-String $endSTR | Select-Object -First 1)[0]).LineNumber[0]
                $Result = $ShowTech | Select-Object -Index (($startIndex - 1)..($endIndex - 2))
            }
            "Version" {
                #This pulls show version section from show tech config file
                Switch -Regex ($ShowTech) {
                    "^-{18} show version -{18}" {
                        $startSTR = "^-{18} show version -{18}"
                    }
                    # Maybe ASA here one day? {}
                }

                $endSTR = "^-{18} show *"
                $startIndex = ($ShowTech | Select-String $startSTR | Select-Object -First 1).LineNumber[0]
                $endIndex = ($ShowTech | Select-String ($ShowTech | Select-Object -Index ($startIndex..$ShowTech.Count) | Select-String $endSTR | Select-Object -First 1)[0]).LineNumber[0]
                $Result = $ShowTech | Select-Object -Index (($startIndex - 1)..($endIndex - 2))
            }
        }

        Return $Result
    }
    Catch {
        Return "Unable to find 'show version' section"
    }
}

Function Get-CiscoDeviceInfo {
    Param (
        [Parameter(Mandatory = $true)]
        [psobject]$ShowTech
    )

    Try {
        $Result = New-Object System.Collections.Generic.List[System.Object]

        # Get software information from Version data
        $ShowVersion = Get-CiscoShowTechData -ShowTech $ShowTech -DataType Version
        If ($ShowVersion) {
            # Determine software type
            Switch -Regex ($ShowVersion) {
                "^Cisco IOS[ -]XE [Ss]oftware, Copyright" {
                    $CiscoOS = "IOS-XE"
                }
                "^Cisco IOS [Ss]oftware," {
                    $CiscoOS = "IOS"
                }
            }
            If (-Not($CiscoOS)) {
                Throw "Unable to determine IOS type"
            }

            # Get software info
            $Pattern1 = "^Cisco IOS.*\(.*\), Version" # Pattern for line that has all of the info we need.
            $Pattern2 = ", Version .*\s{1}" # Pattern for Version
            $Pattern3 = "\w{0,}\s{0,}\w{1,}\s{1,}Software \(.*\)," # Pattern for Software
            $StartLine = ($ShowVersion | Select-String $Pattern1).LineNumber - 1
            $DeviceSoftwareInfo = ($ShowVersion[$($StartLine)].Split(",")).Trim()
            If ($ShowVersion[$($StartLine)] -match $Pattern2) {
                $CiscoOSVer = (($matches[0] -replace ",", "" -replace "Version\s{1,}", "").TrimStart()).Split(" ")[0]
            }
            Else {
                Throw "Unable to determine IOS version"
            }
            If ($ShowVersion[$($StartLine)] -match $Pattern3) {
                $CiscoSoftware = ($matches[0] -replace ",", "" -replace "\s{2,}", " ").Trim()
            }
            Else {
                Throw "Unable to determine Cisco software"
            }

            # Determine if Router Operating Mode exists
            If ($ShowVersion -match "Router Operating Mode") {
                $IsRouter = $true
            }

            # Get device type
            Switch -WildCard ($CiscoSoftware) {
                {($_ -like "*Switch*Software*")} {
                    $DeviceType = "Switch"
                }
                {($_ -like "*ASR*Software*") -or ($_ -like "*CSR*Software*") -or ($_ -like "*ISR*Software*") -or ($_ -like "*Virtual*XE*Software*") -or $IsRouter} {
                    $DeviceType = "Router"
                }
                Default {
                    Throw "'$CiscoSoftware' does not match an expected CiscoSoftware output."
                }
            }
        }
        Else {
            Throw "Unable to find 'Show Version' section"
        }

        # Get the serial number from Inventory data
        $Inventory = Get-CiscoShowTechData -ShowTech $ShowTech -DataType Inventory
        If ($Inventory) {
            Switch -Regex ($Inventory) {
                "^Name:\s+`"{1}.*Stack`"{1}," {
                    $Model = ((($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Stack`"{1}," | Select-Object -First 1).LineNumber]) -Split "PID:")[1] -split ",")[0].Trim()
                    $SerialNumber = (($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Stack`"{1}," | Select-Object -First 1).LineNumber]) -Split "SN:")[1].Trim()
                }
                "^Name:\s+`"{1}.*Chassis`"{1}," {
                    $Model = ((($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Chassis`"{1}," | Select-Object -First 1).LineNumber]) -Split "PID:")[1] -split ",")[0].Trim()
                    $SerialNumber = (($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Chassis`"{1}," | Select-Object -First 1).LineNumber]) -Split "SN:")[1].Trim()
                }
                "^Name:\s+`"{1}.*Switch System`"{1}," {
                    $Model = ((($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Switch System`"{1}," | Select-Object -First 1).LineNumber]) -Split "PID:")[1] -split ",")[0].Trim()
                    $SerialNumber = (($Inventory[($Inventory | Select-String "^Name:\s+`"{1}.*Switch System`"{1}," | Select-Object -First 1).LineNumber]) -Split "SN:")[1].Trim()
                }
            }
        }
        Else {
            Throw "unable to find 'Show Inventory' section"
        }

        # Get hostname
        $Hostname = ((Get-CiscoShowTechData -ShowTech $ShowTech -DataType RunningConfig | Select-String -Pattern "^hostname\s+" | Select-Object -First 1 | Out-String).Replace("hostname", "")).Trim().ToUpper()
        If (-Not($Hostname)) {
            # If 'hostname' not found, try Device Name in Show Version
            $Hostname = ((Get-CiscoShowTechData -ShowTech $ShowTech -DataType Version | Select-String -Pattern "^\s*Device name:" | Select-Object -First 1 | Out-String).Replace("Device name:", "")).Trim().ToUpper()
        }
        If (-Not($Hostname)) {
            # If 'hostname'STILL empty set static
            $Hostname = "NameNotFound"
        }

        # Get domain
        $DomainName = ((Get-CiscoShowTechData -ShowTech $ShowTech -DataType RunningConfig | Select-String -Pattern "^ip domain-name" | Select-Object -First 1 | Out-String).Replace("ip domain-name", "")).Trim()

        # Get MAC (if available)
        $MACAddress = ((Get-CiscoShowTechData -ShowTech $ShowTech -DataType Version | Select-String -Pattern "^Base Ethernet MAC Address\s*:" | Select-Object -First 1 | Out-String) -Replace "Base Ethernet MAC Address\s*:", "").Trim()

        # Put found data into an object and return it
        $NewObj = [PSCustomObject]@{
            Hostname      = $Hostname
            DomainName    = $DomainName
            MACAddress    = $MACAddress
            DeviceInfo    = $DeviceSoftwareInfo
            CiscoOS       = $CiscoOS
            CiscoOSVer    = $CiscoOSVer
            CiscoSoftware = $CiscoSoftware
            SerialNumber  = $SerialNumber
            Model         = $Model
            DeviceType    = $DeviceType
        }
        $Result.Add($NewObj)

        Return $Result
    }
    Catch {
        Return $_.Exception.Message
    }
}

Function Get-Section {
    param(
        [String[]] $configData,
        [String] $sectionName
    )

    $pattern = '(?:^(!)\s*$)|(?:^[\s]+(.+)$)'
    $inSection = $false
    ForEach ($line in $configData) {
        # Skip empty lines
        If ($line -match '^\s*$') {
            Continue
        }
        If ($line -eq $sectionName) {
            $inSection = $true
            Continue
        }
        If ($inSection) {
            If ($line -match $pattern) {
                [Regex]::Matches($line, $pattern) | ForEach-Object {
                    If ($_.Groups[1].Success) {
                        $_.Groups[1].Value
                    }
                    Else {
                        $_.Groups[2].Value
                    }
                }
            }
            Else {
                $inSection = $false
            }
            If (-not($inSection)) {
                Break
            }
        }
    }
}

Function Invoke-ConfigFileScan {
    Param (
        # Evaluate-STIG parameters
        [Parameter(Mandatory = $true)]
        [String[]]$CiscoConfig,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Unclassified", "Classified")]
        [String]$ScanType = "Unclassified",

        [Parameter(Mandatory = $false)]
        [String]$Marking,

        [Parameter(Mandatory = $false)]
        [String]$TargetComments,

        [Parameter(Mandatory = $false)]
        [Int]$VulnTimeout = 15,

        [Parameter(Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [String]$AFPath,

        [Parameter(Mandatory = $false)]
        [String]$AnswerKey = "DEFAULT",

        [Parameter(Mandatory = $false)]
        [String[]]$Output = "",

        [Parameter(Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [String]$OutputPath,

        [Parameter(Mandatory = $false)]
        [Int]$PreviousToKeep = 0,

        [Parameter(Mandatory = $false)]
        [SecureString]$SMPassphrase,

        [Parameter(Mandatory = $false)]
        [String]$SMCollection,

        [Parameter(Mandatory = $false)]
        [Switch]$AllowDeprecated,

        [Parameter(Mandatory = $false)]
        [Switch]$AllowSeverityOverride,

        [Parameter(Mandatory = $false)]
        [Switch]$AllowIntegrityViolations,

        [Parameter(Mandatory = $false)]
        [Array]$SelectSTIG,

        [Parameter(Mandatory = $false)]
        [Array]$SelectVuln,

        [Parameter(Mandatory = $false)]
        [Array]$ExcludeVuln,

        [Parameter(Mandatory = $false)]
        [Array]$OutputPayload,

        [Parameter(Mandatory = $false)]
        [Array]$ExcludeSTIG,

        [Parameter(Mandatory = $false)]
        [Array]$ForceSTIG,

        [Parameter(Mandatory = $false)]
        [Int]$ThrottleLimit = 10,

        # Config file scan parameters
        [Parameter(Mandatory = $true)]
        [String]$ESVersion,

        [Parameter(Mandatory = $true)]
        [String]$LogComponent,

        [Parameter(Mandatory = $true)]
        [String]$OSPlatform,

        [Parameter(Mandatory = $true)]
        [String] $ES_Path,

        [Parameter(Mandatory = $true)]
        [String] $PowerShellVersion,

        [Parameter(Mandatory = $true)]
        [String] $CiscoScanDir,

        [Parameter(Mandatory = $true)]
        [String] $CiscoWorkingDir
    )

    Try {
        $ConfigEvalStart = Get-Date
        $ProgressId = 1
        $ProgressActivity = "Evaluate-STIG (Version: $ESVersion | Scan Type: $ScanType | Answer Key: $AnswerKey)"

        $STIGLog_Cisco = Join-Path -Path $CiscoScanDir -ChildPath "Evaluate-STIG_Cisco.log"
        If (Test-Path $STIGLog_Cisco) {
            Remove-Item $STIGLog_Cisco -Force
        }
        $STIGLog_STIGManager = Join-Path -Path $CiscoScanDir -ChildPath "Evaluate-STIG_STIGManager.log"
        If (Test-Path $STIGLog_STIGManager) {
            Remove-Item $STIGLog_STIGManager -Force
        }
        $STIGLog_Splunk = Join-Path -Path $CiscoScanDir -ChildPath "Evaluate-STIG_Splunk.log"
        If (Test-Path $STIGLog_Splunk) {
            Remove-Item $STIGLog_Splunk -Force
        }

        # Reconstruct command line for logging purposes
        $ParamsNotForLog = @("ESVersion", "LogComponent", "OSPlatform", "ES_Path", "PowerShellVersion") # Parameters not be be written to log
        $CommandLine = Get-CommandLine -CommandName "Evaluate-STIG.ps1" -BoundParameters $PSBoundParameters -IgnoreParams $ParamsNotForLog

        # Begin logging
        Write-Log -Path $STIGLog_Cisco -Message "Executing: $($CommandLine)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

        # Verify Evaluate-STIG files integrity
        $FileIntegrityPass = $true
        $Verified = $true
        Write-Log -Path $STIGLog_Cisco -Message "Verifying Evaluate-STIG file integrity" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        If (Test-Path (Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
            [XML]$FileListXML = Get-Content -Path (Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
            If ((Test-XmlSignature -checkxml $FileListXML -Force) -ne $true) {
                $FileIntegrityPass = $false
                Write-Log -Path $STIGLog_Cisco -Message "ERROR: 'FileList.xml' failed authenticity check. Unable to verify content integrity." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            }
            Else {
                ForEach ($File in $FileListXML.FileList.File) {
                    $Path = (Join-Path -Path $ES_Path -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                    If (Test-Path $Path) {
                        If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                            $FileIntegrityPass = $false
                            $Verified = $false
                            Write-Log -Path $STIGLog_Cisco -Message "WARNING: '$($Path)' failed integrity check." -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                        }
                    }
                    Else {
                        If ($File.ScanReq -eq "Required") {
                            $Verified = $false
                            Write-Log -Path $STIGLog_Cisco -Message "ERROR: '$($File.Name)' is a required file but not found. Scan results may be incomplete." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                        }
                    }
                }
                If ($Verified -eq $true) {
                    Write-Log -Path $STIGLog_Cisco -Message "Evaluate-STIG file integrity check passed." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                }
                Else {
                    Write-Log -Path $STIGLog_Cisco -Message "WARNING: One or more Evaluate-STIG files failed integrity check." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                }
            }
        }
        Else {
            Throw "'FileList.xml' not found."
        }
        If ($FileIntegrityPass -ne $true) {
            If ($AllowIntegrityViolations -ne $true) {
                Write-Log -Path $STIGLog_Cisco -Message "File integrity checks failed - refer to $STIGLog_Cisco.  Aborting scan" -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                Return
            }
            Else {
                Write-Log -Path $STIGLog_Cisco -Message "-AllowIntegrityViolations specified so continuing with scan." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
            }
        }

        # Schema Files
        $STIGList_xsd = Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
        $AnswerFile_xsd = Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "Schema_AnswerFile.xsd"
        $Checklist_xsd = Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "U_Checklist_Schema_V2.xsd"
        $Checklist_json = Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "CKLB.schema.json"
        If (-Not(Test-Path $STIGList_xsd)) {
            Throw "'$STIGList_xsd' - file not found."
        }
        ElseIf (-Not(Test-Path $AnswerFile_xsd)) {
            Throw "'$AnswerFile_xsd' - file not found."
        }
        ElseIf (-Not(Test-Path $Checklist_xsd)) {
            Throw "'$Checklist_xsd' - file not found."
        }
        ElseIf (-Not(Test-Path $Checklist_json)) {
            Throw "'$Checklist_json' - file not found."
        }

        # STIGList.xml validation
        $XmlFile = Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (-Not(Test-Path $XmlFile)) {
            Throw "'$XmlFile' - file not found."
        }
        Else {
            $Result = Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd
            If ($Result -ne $true) {
                ForEach ($Item in $Result.Message) {
                    Write-Log -Path $STIGLog_Cisco -Message $Item -Component $LogComponent -Type "Error" -WriteOutToStream -OSPlatform $OSPlatform
                }
                Throw "'$($XmlFile)' failed XML validation"
            }
        }

        Write-Log -Path $STIGLog_Cisco -Message "Evaluate-STIG Version: $ESVersion" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "Launching User: $([Environment]::Username)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "OS Platform: $OSPlatform" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "PS Version: $PowerShellVersion" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "Scan Type: $ScanType" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "Answer Key: $AnswerKey" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "Answer File Path: $AFPath" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "Output Path: $OutputPath" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Log -Path $STIGLog_Cisco -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

        # ++++++++++++++++++++++ Begin processing ++++++++++++++++++++++
        Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Initializing and generating list of required STIGs"

        # --- Begin Answer File validation
        Write-Log -Path $STIGLog_Cisco -Message "Validating answer files" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        $AnswerFileList = New-Object System.Collections.Generic.List[System.Object]
        $XmlFiles = Get-ChildItem -Path $AFPath | Where-Object Extension -EQ ".xml"
        # Verify answer files for proper format
        ForEach ($Item in $XmlFiles) {
            $Validation = (Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $AnswerFile_xsd)
            If ($Validation -eq $true) {
                Write-Log -Path $STIGLog_Cisco -Message "$($Item.Name) : Passed" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                [XML]$Content = Get-Content $Item.FullName
                If ($Content.STIGComments.Name) {
                    $NewObj = [PSCustomObject]@{
                        STIG          = $Content.STIGComments.Name
                        Name          = $Item.Name
                        FullName      = $Item.FullName
                        LastWriteTime = $Item.LastWriteTime
                    }
                    $AnswerFileList.Add($NewObj)
                }
            }
            Else {
                Write-Log -Path $STIGLog_Cisco -Message "ERROR: $($Item.Name) : Error - Answer file failed schema validation and will be ignored.  Please correct or remove." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                Write-Log -Path $STIGLog_Cisco -Message "$($Validation.Message)" -Component $LogComponent -Type "Error" -WriteOutToStream -OSPlatform $OSPlatform
                Write-Host ""
            }
        }
        $AnswerFileList = $AnswerFileList | Sort-Object LastWriteTime -Descending
        Write-Log -Path $STIGLog_Cisco -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        # --- End Answer File validation

        # Build list of valid configs to scan
        [XML]$STIGList = Get-Content (Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml")
        $STIGsToDetect = New-Object System.Collections.Generic.List[System.Object]

        If ($SelectSTIG) {
            ForEach ($Item in $SelectSTIG) {
                If (($STIGList.List.STIG | Where-Object ShortName -EQ $Item).AssetType -notin @('Cisco')) {
                    Write-Log -Path $STIGLog_Cisco -Message "WARNING: Scan for '$(($STIGList.List.STIG | Where-Object ShortName -EQ $Item).Name)' request with SelectSTIG but cannot be performed in this context. Ignoring." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                }
                Else {
                    $Node = $STIGList.List.STIG | Where-Object ShortName -EQ $Item

                    # Determine deprecation
                    $Deprecated = $false
                    If ($Node.DisaStatus -eq "Deprecated") {
                        $Deprecated = $true
                    }

                    $NewObj = [PSCustomObject]@{
                        Name           = $Node.Name
                        Shortname      = $Node.ShortName
                        StigContent    = $Node.StigContent
                        DetectionCode  = $Node.DetectionCode
                        PsModule       = $Node.PsModule
                        PsModuleVer    = $Node.PsModuleVer
                        CanCombine     = $Node.CanCombine
                        Classification = $Node.Classification
                        CklTechArea    = $Node.CklTechArea
                        Deprecated     = $Deprecated
                        Forced         = $false
                    }
                    $STIGsToDetect.Add($NewObj)
                }
            }
        }
        Else {
            ForEach ($Node in ($STIGList.List.STIG | Where-Object {($_.AssetType -in @("Cisco") -and $_.ShortName -notin $ExcludeSTIG)})) {
                # Determine deprecation
                $Deprecated = $false
                If ($Node.DisaStatus -eq "Deprecated") {
                    $Deprecated = $true
                }

                $NewObj = [PSCustomObject]@{
                    Name           = $Node.Name
                    Shortname      = $Node.ShortName
                    StigContent    = $Node.StigContent
                    DetectionCode  = $Node.DetectionCode
                    PsModule       = $Node.PsModule
                    PsModuleVer    = $Node.PsModuleVer
                    CanCombine     = $Node.CanCombine
                    Classification = $Node.Classification
                    CklTechArea    = $Node.CklTechArea
                    Deprecated     = $Deprecated
                    Forced         = $false
                }
                $STIGsToDetect.Add($NewObj)
            }
        }

        If ($ForceSTIG) {
            ForEach ($Item in $ForceSTIG) {
                If (($STIGList.List.STIG | Where-Object ShortName -EQ $Item).AssetType -notin @("Cisco")) {
                    Write-Log -Path $STIGLog_Cisco -Message "WARNING: Scan for '$(($STIGList.List.STIG | Where-Object ShortName -EQ $Item).Name)' request with -ForceSTIG but cannot be performed in this context. Ignoring." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                }
                Else {
                    If ($STIGsToDetect.ShortName -eq $Item) {
                        ($STIGsToDetect | Where-Object Shortname -EQ $Item).Forced = $true
                    }
                    Else {
                        # Determine deprecation
                        $Deprecated = $false
                        If ($Node.DisaStatus -eq "Deprecated") {
                            $Deprecated = $true
                        }

                        $Node = $STIGList.List.STIG | Where-Object ShortName -EQ $Item
                        $NewObj = [PSCustomObject]@{
                            Name           = $Node.Name
                            Shortname      = $Node.ShortName
                            StigContent    = $Node.StigContent
                            DetectionCode  = $Node.DetectionCode
                            PsModule       = $Node.PsModule
                            PsModuleVer    = $Node.PsModuleVer
                            CanCombine     = $Node.CanCombine
                            Classification = $Node.Classification
                            CklTechArea    = $Node.CklTechArea
                            Deprecated     = $Deprecated
                            Forced         = $true
                        }
                        $STIGsToDetect.Add($NewObj)
                    }
                }
            }
        }
        If (-Not($STIGsToDetect)) {
            Throw "No config file based STIGs selected to scan."
        }
        $ConfigFiles = New-Object System.Collections.Generic.List[System.Object]
        Write-Log -Path $STIGLog_Cisco -Message "Looking for supported Cisco files" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Host "Refer to '$($CiscoScanDir)\Evaluate-STIG_Cisco.log' for info on detected files" -ForegroundColor DarkGray
        ForEach ($Item in $CiscoConfig) {
            [System.GC]::Collect()
            $CurrentSubStep = 1
            Write-Progress $ProgressId -Activity $ProgressActivity -Status "Looking for supported Cisco files in $Item"
            $Files = Get-ChildItem $Item -Recurse -File
            ForEach ($File in $Files.FullName) {
                $TCLOutput = $false
                Write-Progress -Id ($ProgressId + 1) -ParentId $ProgressId -Activity " " -Status $File -PercentComplete ($CurrentSubStep / $Files.Count * 100)
                $ShowTech = [System.IO.File]::OpenText($File).ReadToEnd() -split "`r`n" -split "`r" -split "`n"
                # If 'show inventory', 'show running-config', and 'show version' sections do not exist then this file isn't a valid show tech-support file.
                If (-Not(($ShowTech | Select-String "^-{18} show inventory -{18}") -and ($ShowTech | Select-String "^-{18} show running-config -{18}") -and ($ShowTech | Select-String "^-{18} show version -{18}"))) {
                    # DISABLE TCL logging:  Write-Log -Path $STIGLog_Cisco -Message "ERROR: Unsupported file : $($File) [Not an output produced by Get-ESCiscoConfig.tcl or 'show tech-support'.]" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog_Cisco -Message "ERROR: Unsupported file : $($File) [Not an output 'show tech-support'.]" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                    Continue
                }

                # If this is an Evaluate-STIG TCL output file, get just the Evaluate-STIG section.
                $startSTR = "^-{18} Show Evaluate-STIG Cisco .* -{18}$"
                $endSTR = "^-{18} End Evaluate-STIG Cisco Configuration -{18}$"
                If (($ShowTech | Select-String $startSTR) -and ($ShowTech | Select-String $endSTR)) {
                    $TCLOutput = $true
                    $startIndex = ($ShowTech | Select-String $startSTR | Select-Object -First 1).LineNumber
                    $endIndex = ($ShowTech | Select-String ($ShowTech | Select-Object -Index ($startIndex..$ShowTech.Count) | Select-String $endSTR | Select-Object -First 1)[0]).LineNumber
                    $ShowTech = $ShowTech | Select-Object -Index (($startIndex - 1)..($endIndex - 1))
                }

                $DeviceInfo = Get-CiscoDeviceInfo -ShowTech $ShowTech
                If (($DeviceInfo).DeviceType -notin @("Router", "Switch")) {
                    Write-Log -Path $STIGLog_Cisco -Message "ERROR: Unsupported file : $($File) [File is not from a supported device. Refer to the supported STIGs list.]" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                }
                Else {
                    If ($File -notin $ConfigFiles.File) {
                        If ($TCLOutput -eq $true) {
                            Write-Log -Path $STIGLog_Cisco -Message "Supported TCL file : $($File)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        }
                        Else {
                            # DISABLE TCL logging:  Write-Log -Path $STIGLog_Cisco -Message "WARNING: Supported Non-TCL file : $($File) [Please consider generating output with Get-ESCiscoConfig.tcl for maximum compatibility.]" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                        }
                        $NewObj = [PSCustomObject]@{
                            ShowTech          = $ShowTech
                            DeviceInfo        = $DeviceInfo
                            ShowRunningConfig = $(Get-CiscoShowTechData -ShowTech $ShowTech -DataType RunningConfig)
                            File              = $File
                        }
                        $ConfigFiles.Add($NewObj)
                    }
                }
                $CurrentSubStep++
                Write-Progress -Id ($ProgressId + 1) -ParentId $ProgressId -Activity " " -Completed
            }
        }
        Write-Log -Path $STIGLog_Cisco -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        Write-Progress -Id $ProgressId -Activity $ProgressActivity -Completed

        # Create runspace pool to include required modules.
        $runspaces = New-Object System.Collections.ArrayList
        $SessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
        $SessionState.ImportPSModule($(Join-Path -Path $ES_Path -ChildPath Modules | Join-Path -ChildPath Master_Functions))
        $RunspacePool = [runspacefactory]::CreateRunspacePool(1, $throttlelimit, $SessionState, $Host)
        $RunspacePool.Open()
        $RunspaceResults = @{}

        # Create pipeline input and output (results) object
        $RSObject = New-Object 'System.Management.Automation.PSDataCollection[PSObject]'

        ForEach ($Item in $ConfigFiles) {
            # Build arguments hashtable
            $HashArguments = @{
                ShowTech          = $($Item.ShowTech)
                ShowRunningConfig = $($Item.ShowRunningConfig)
                DeviceInfo        = $($Item.DeviceInfo)
                CiscoConfig       = $($Item.File)
                ScanType          = $($ScanType)
                VulnTimeout       = $($VulnTimeout)
                AFPath            = $($AFPath)
                AnswerKey         = $($AnswerKey)
                OutputPath        = $($OutputPath)
                ESVersion         = $($ESVersion)
                LogComponent      = $($LogComponent)
                OSPlatform        = $($OSPlatform)
                ES_Path           = $($ES_Path)
                PowerShellVersion = $($PowerShellVersion)
                CiscoWorkingDir   = $($CiscoWorkingDir)
                Checklist_xsd     = $($Checklist_xsd)
                Checklist_json    = $($Checklist_json)
                STIGList          = $($STIGList)
                STIGsToDetect     = $($STIGsToDetect)
                STIGLog_Cisco     = $($STIGLog_Cisco)
                CiscoConfigLog    = $(Join-Path -Path $CiscoWorkingDir -ChildPath "Evaluate-STIG_Cisco_$(Split-Path $Item.File -Leaf).log")
            }
            If ($Marking) {
                $HashArguments.Add("Marking", $Marking)
            }
            If ($TargetComments) {
                $HashArguments.Add("TargetComments", $TargetComments)
            }
            If ($Output) {
                $HashArguments.Add("Output", $Output)

                If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$|^Summary$|^OQE$)")) {
                    $HashArguments.Add("PreviousToKeep", $PreviousToKeep)
                }

                If (($Output -split ",").Trim() -match "^STIGManager$") {
                    if ($SMPassphrase){
                        $HashArguments.SMPassphrase = $SMPassphrase
                    }
                    if ($SMCollection){
                        $HashArguments.SMCollection = $SMCollection
                    }
                }

                If (($Output -split ",").Trim() -match "^Splunk$") {
                    if ($SplunkHECName){
                        $HashArguments.SplunkHECName = $SplunkHECName
                    }
                }

                If (($Output -Split ",").Trim() -match @("(^CSV$|^CombinedCSV$|^Splunk$)")){
                    If ($OutputPayload) {
                        $HashArguments.OutputPayload = $OutputPayload
                    }
                }
            }
            If ($AllowDeprecated) {
                $HashArguments.Add("AllowDeprecated", $true)
            }
            If ($AllowSeverityOverride) {
                $HashArguments.Add("AllowSeverityOverride", $true)
            }
            If ($AllowIntegrityViolations) {
                $HashArguments.Add("AllowIntegrityViolations", $true)
            }
            If ($SelectSTIG) {
                $HashArguments.Add("SelectSTIG", $SelectSTIG)
            }
            If ($SelectVuln) {
                $HashArguments.Add("SelectVuln", $SelectVuln)
            }
            If ($ExcludeVuln) {
                $HashArguments.Add("ExcludeVuln", $ExcludeVuln)
            }
            If ($ForceSTIG) {
                $HashArguments.Add("ForceSTIG", $ForceSTIG)
            }
            If ($AnswerFileList) {
                $HashArguments.Add("AnswerFileList", $AnswerFileList)
            }

            $CiscoBlock = {
                Param (
                    # Evaluate-STIG parameters
                    $ShowTech,
                    $ShowRunningConfig,
                    $DeviceInfo,
                    $ScanType,
                    $Marking,
                    $TargetComments,
                    $VulnTimeout,
                    $AFPath,
                    $AnswerKey,
                    $Output,
                    $OutputPath,
                    $PreviousToKeep,
                    $SMPassphrase,
                    $SMCollection,
                    $AllowDeprecated,
                    $AllowIntegrityViolations,
                    $SelectSTIG,
                    $SelectVuln,
                    $ExcludeVuln,
                    $OutputPayload,
                    $ForceSTIG,
                    $ThrottleLimit,
                    # Config file scan parameters
                    $ESVersion,
                    $LogComponent,
                    $OSPlatform,
                    $ES_Path,
                    $PowerShellVersion,
                    $Checklist_xsd,
                    $Checklist_json,
                    $CiscoWorkingDir,
                    $CiscoConfigLog,
                    $STIGLog_Cisco,
                    $CiscoConfig,
                    $STIGList,
                    $STIGsToDetect,
                    $AnswerFileList
                )

                Try {
                    $EvalStart = Get-Date
                    $ScanStartDate = (Get-Date -Format "MM/dd/yyyy")
                    If (Test-Path $CiscoConfigLog) {
                        Remove-Item $CiscoConfigLog -Force
                    }
                    Write-Log -Path $CiscoConfigLog -Message "Begin Config File Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                    $ProgressPreference = "SilentlyContinue"
                    [int]$TotalMainSteps = 1
                    [int]$CurrentMainStep = 1

                    # Build list of required STIGs
                    $DetectedSTIGs = New-Object System.Collections.Generic.List[System.Object]
                    ForEach ($Node in $STIGList.List.STIG | Where-Object {$_.AssetType -in @("Cisco")}) {
                        If ($Node.DetectionCode -and (Invoke-Expression $Node.DetectionCode) -eq $true) {
                            $NewObj = [PSCustomObject]@{
                                Name       = $Node.Name
                                Shortname  = $Node.ShortName
                                DISAStatus = $Node.DISAStatus
                            }
                            $DetectedSTIGs.Add($NewObj)
                        }
                    }

                    $STIGsToProcess = New-Object System.Collections.Generic.List[System.Object]
                    ForEach ($Node in $STIGsToDetect) {
                        If ($Node.ShortName -in $DetectedSTIGs.ShortName) {
                            If ((Test-STIGDependencyFiles -RootPath $ES_Path -STIGData $Node -LogPath $CiscoConfigLog -OSPlatform $OSPlatform) -eq $true) {
                                If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                                    $AFtoUse = ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]
                                }
                                Else {
                                    $AFtoUse = ""
                                }

                                # Determine deprecation
                                $Deprecated = $false
                                If ($Node.DisaStatus -eq "Deprecated") {
                                    $Deprecated = $true
                                }

                                $NewObj = [PSCustomObject]@{
                                    Name           = $Node.Name
                                    Shortname      = $Node.ShortName
                                    StigContent    = $Node.StigContent
                                    AnswerFile     = $AFtoUse
                                    PsModule       = $Node.PsModule
                                    PsModuleVer    = $Node.PsModuleVer
                                    CanCombine     = $Node.CanCombine
                                    Classification = $Node.Classification
                                    CklTechArea    = $Node.CklTechArea
                                    Deprecated     = $Deprecated
                                    Forced         = $false
                                }
                                $STIGsToProcess.Add($NewObj)
                            }
                        }
                        ElseIf ($Node.Forced -eq $true) {
                            Write-Log -Path $CiscoConfigLog -Message "WARNING: Scan for '$($Node.Name)' forced with -ForceSTIG. Evaluate-STIG results are not guaranteed with this option. Use at own risk." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                            If ((Test-STIGDependencyFiles -RootPath $ES_Path -STIGData $Node -LogPath $CiscoConfigLog -OSPlatform $OSPlatform) -eq $true) {
                                If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                                    $AFtoUse = ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]
                                }
                                Else {
                                    $AFtoUse = ""
                                }

                                # Determine deprecation
                                $Deprecated = $false
                                If ($Node.DisaStatus -eq "Deprecated") {
                                    $Deprecated = $true
                                }

                                $NewObj = [PSCustomObject]@{
                                    Name           = $Node.Name
                                    Shortname      = $Node.ShortName
                                    StigContent    = $Node.StigContent
                                    AnswerFile     = $AFtoUse
                                    PsModule       = $Node.PsModule
                                    PsModuleVer    = $Node.PsModuleVer
                                    CanCombine     = $Node.CanCombine
                                    Classification = $Node.Classification
                                    CklTechArea    = $Node.CklTechArea
                                    Deprecated     = $Deprecated
                                    Forced         = $true
                                }
                                $STIGsToProcess.Add($NewObj)
                            }
                        }
                    }
                    $CurrentSubStep++
                    [int]$TotalMainSteps = $TotalMainSteps + $STIGsToProcess.Count

                    $MachineName = $DeviceInfo.Hostname
                    $WorkingDir = Join-Path -Path $CiscoWorkingDir -ChildPath $MachineName
                    If (Test-Path $WorkingDir) {
                        Remove-Item $WorkingDir -Recurse -Force
                    }
                    $null = New-Item -Path $WorkingDir -ItemType Directory -ErrorAction Stop

                    If ($OutputPath) {
                        If ($SelectVuln) {
                            $ResultsPath = Join-Path -Path $OutputPath -ChildPath "_Partial_$MachineName"
                        }
                        Else {
                            $ResultsPath = Join-Path -Path $OutputPath -ChildPath $MachineName
                        }
                    }

                    Write-Log -Path $CiscoConfigLog -Message "Hostname: $MachineName" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $CiscoConfigLog -Message "File: $($CiscoConfig)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $CiscoConfigLog -Message "Executing scan" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                    # Get AssetData
                    $AssetData = Get-AssetData -OSPlatform Cisco -ShowRunningConfig $ShowRunningConfig -DeviceInfo $DeviceInfo

                    $STIGLog = Join-Path -Path $WorkingDir -ChildPath "Evaluate-STIG.log"
                    If ($Marking) {
                        Write-Log -Path $STIGLog -Message "                                                                                          $Marking                                                                                          " -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    }
                    Write-Log -Path $STIGLog -Message "Begin Local Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Evaluate-STIG Version: $ESVersion" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Launching User: $([Environment]::Username)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "File: $($CiscoConfig)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Hostname: $MachineName" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Manufacturer: $($AssetData.Manufacturer)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Model: $($AssetData.Model)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Operating System: Cisco" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Operating System Name: $($AssetData.OSName)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Operating System Version: $($AssetData.OSVersion)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Cisco Software: $($DeviceInfo.CiscoSoftware)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "Device Type: $($DeviceInfo.DeviceType)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                    # Write list of STIGs that will be evaluated to log
                    ForEach ($STIG in ($STIGsToProcess | Where-Object Forced -EQ $true)) {
                        Write-Log -Path $STIGLog -Message "WARNING: Scan for '$($Node.Name)' forced with -ForceSTIG. Evaluate-STIG results are not guaranteed with this option. Use at own risk." -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                    }

                    # Note ApplicableSTIGs in log (deprecated are not considered applicable given they no longer exist on cyber.mil)
                    Write-Log -Path $STIGLog -Message "The following STIGs are determined applicable:" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    ForEach ($STIG in ($DetectedSTIGs | Where-Object DISAStatus -NE "Deprecated") | Sort-Object Name) {
                        Write-Log -Path $STIGLog -Message "STIG: $($STIG.Name)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    }
                    Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                    $ApplicableSTIGs = @()
                    ForEach ($Item in ($DetectedSTIGs | Where-Object DISAStatus -NE "Deprecated")) {
                        $ApplicableSTIGs += ($STIGList.List.STIG | Where-Object ShortName -EQ $Item.ShortName)
                    }

                    # If no supported STIGs are applicable, log it and continue
                    If (($STIGsToProcess | Measure-Object).Count -eq 0) {
                        Write-Log -Path $STIGLog -Message "WARNING: $($CiscoConfig) : No Evaluate-STIG supported STIGs are applicable to this system." -WriteOutToStream -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                        Write-Log -Path $CiscoConfigLog -Message "WARNING: No Evaluate-STIG supported STIGs are applicable to this system." -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                        Write-Log -Path $CiscoConfigLog -Message "End Config File Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Cisco -Value $(Get-Content $CiscoConfigLog)
                        Remove-Item $CiscoConfigLog

                        $TempFiles = Get-Item -Path $WorkingDir
                        If ($TempFiles) {
                            ForEach ($Item in $TempFiles) {
                                Try {
                                    $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
                                }
                                Catch {
                                    Write-Log -Path $STIGLog -Message "$($_.Exception.Message)" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                                    Write-Log -Path $CiscoConfigLog -Message "$($_.Exception.Message)" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                                }
                            }
                        }
                    }
                    Else {
                        # Write list of STIGs that will be evaluated to log
                        Write-Log -Path $STIGLog -Message "The following STIGs will be evaluated:" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        ForEach ($STIG in $STIGsToProcess | Sort-Object Name) {
                            $AnswerFileMsg = ""
                            If ($STIG.AnswerFile) {
                                $AnswerFileMsg = "  |  AnswerFile: $($STIG.AnswerFile.Name) (Modified: $(Get-Date (Get-ChildItem $STIG.AnswerFile.FullName).LastWriteTime -Format "dd MMM yyyy HH:mm:ss"))"
                            }

                            If ($STIG.Deprecated -eq $true) {
                                Write-Log -Path $STIGLog -Message "STIG: $($STIG.Name) [Deprecated]$($AnswerFileMsg)" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                            }
                            Else {
                                Write-Log -Path $STIGLog -Message "STIG: $($STIG.Name)$($AnswerFileMsg)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            }
                        }
                        Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                        # Test connectivity to OutputPath and create folder for computer
                        Try {
                            If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$|^Summary$|^OQE$)")) {
                                If (-Not(Test-Path $ResultsPath)) {
                                    $null = New-Item $ResultsPath -ItemType Directory -ErrorAction Stop
                                    Start-Sleep 5
                                }
                            }
                        }
                        Catch {
                            Write-Log -Path $STIGLog -Message "ERROR: Failed to create output path $($ResultsPath)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                            Throw $_
                        }

                        # =========== Run the scans ===========
                        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$|^Summary$|^OQE$)")) {
                            # $tmpResultsPath is needed for all filetype Outputs needed for all filetype Outputs
                            $tmpResultsPath = $(Join-Path -Path $WorkingDir -ChildPath "Results")
                            If (-Not(Test-Path $tmpResultsPath)) {
                                $null = New-Item -Path $tmpResultsPath -ItemType Directory
                            }
                        }

                        $ApplicableSTIGsCount = [System.Collections.Generic.List[System.Object]]::new()
                        $ProcessedSTIGs = [System.Collections.Generic.List[System.Object]]::new()
                        $ScanObjects = [System.Collections.Generic.List[System.Object]]::new()
                        $ScanJobs = [System.Collections.Generic.List[System.Object]]::new()
                        # Get STIG instance counts and build list of jobs to be ran
                        $STIGsToDetect = [System.Collections.Generic.List[System.Object]]::new()
                        ForEach ($Item in $STIGsToProcess) {
                            $STIGsToDetect.Add($Item)
                        }
                        ForEach ($Item in $ApplicableSTIGs) {
                            If ($Item.ShortName -notin $STIGsToDetect.ShortName) {
                                $NewObj = [PSCustomObject]@{
                                    Name           = $Item.Name
                                    Shortname      = $Item.ShortName
                                    StigContent    = $Item.StigContent
                                    AnswerFile     = ""
                                    PsModule       = $Item.PsModule
                                    PsModuleVer    = $Item.PsModuleVer
                                    UserSettings   = $Item.UserSettings
                                    CanCombine     = $Item.CanCombine
                                    Classification = $Item.Classification
                                    CklTechArea    = $Item.CklTechArea
                                    Deprecated     = $Deprecated
                                    Forced         = $false
                                }
                                $STIGsToDetect.Add($NewObj)
                            }
                        }

                        Write-Log -Path $STIGLog -Message "Getting instance counts and building job list" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        ForEach ($Item in ($STIGsToDetect | Sort-Object Name)) {
                            Try {
                                # Create subjobs object for STIGs that may apply multiple times (IIS, SQL, etc.)
                                $SubJobs = [System.Collections.Generic.List[System.Object]]::new()

                                # Temporarily import scan module for access to custom functions
                                If ($PowerShellVersion -lt [Version]"7.0") {
                                    Import-Module (Join-Path -Path $ES_Path -ChildPath "Modules" | Join-Path -ChildPath $($Item.PsModule)) -ErrorAction Stop
                                }
                                Else {
                                    Import-Module (Join-Path -Path $ES_Path -ChildPath "Modules" | Join-Path -ChildPath $($Item.PsModule)) -SkipEditionCheck -ErrorAction Stop
                                }

                                # Set path to STIG .xccdf.xml and get needed data from it
                                $StigXmlPath = $(Join-Path -Path $ES_Path -ChildPath "StigContent" | Join-Path -ChildPath $Item.StigContent)
                                $STIGID = ((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.id).Trim()
                                $STIGTitle = ((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.Title).Trim()
                                $STIGVer = ((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.Version).Trim()
                                $STIGRel = ((((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text' -split 'Benchmark')[0].Trim() -split ' ')[1].Trim()
                                $STIGDate = (((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text' -split 'Date:')[1].Trim()
                                $STIGVersion = "V$($STIGVer)R$($STIGRel)"
                                $STIGStyleSheet = ((Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).'xml-stylesheet').Trim()
                                # Set STIG Classification
                                Switch -Regex ($STIGStyleSheet) {
                                    'STIG_unclass.xsl' {
                                        $Classification = "UNCLASSIFIED"
                                    }
                                    'STIG_cui.xsl' {
                                        $Classification = "CUI"
                                    }
                                    DEFAULT {
                                        $Classification = "No match in 'xml-stylesheet'."
                                    }
                                }

                                $STIGTargetKey = (Select-Xml -Path $StigXmlPath -XPath "/" | Select-Object -ExpandProperty Node).Benchmark.Group[0].Rule.reference.identifier

                                # Build STIGInfo Object
                                $STIGInfo = [ordered]@{
                                    STIGID         = $STIGID
                                    Title          = $STIGTitle
                                    Version        = $STIGVer
                                    Release        = $STIGRel
                                    ReleaseDate    = $STIGDate
                                    Classification = $Classification
                                    EvalScore      = 0
                                }

                                # Build TargetData Object
                                Switch -Regex ($AssetData.Role) {
                                    "Workstation" {
                                        $Role = "Workstation"
                                    }
                                    "Server" {
                                        $Role = "Member Server"
                                    }
                                    "Domain Controller" {
                                        $Role = "Domain Controller"
                                    }
                                    DEFAULT {
                                        $Role = $AssetData.Role
                                    }
                                }

                                $PrimaryIpAddress = ""
                                $PrimaryMacAddress = ""
                                If ($AssetData.ActiveAdapters) {
                                    $PrimaryAdapter = ($AssetData.ActiveAdapters | Sort-Object InterfaceIndex)[0]
                                    $PrimaryIpAddress = $($PrimaryAdapter[0]).IPv4Address
                                    $PrimaryMacAddress = $($PrimaryAdapter[0]).MacAddress
                                }
                                $TargetData = [ordered]@{
                                    Marking        = $Marking
                                    Hostname       = $AssetData.HostName
                                    IpAddress      = $PrimaryIpAddress
                                    MacAddress     = $PrimaryMacAddress
                                    FQDN           = $AssetData.FQDN
                                    TargetComments = $TargetComments
                                    Role           = $Role
                                    CklTechArea    = $Item.CklTechArea
                                }
                                $TargetData.Add("TargetKey", $STIGTargetKey)
                                $TargetData.Add("WebOrDatabase", $false) # Initialize 'WebOrDatabase'.  If required, set below.
                                $TargetData.Add("Site", "")              # Initialize 'Site'.  If required, set below.
                                $TargetData.Add("Instance", "")          # Initialize 'Instance'.  If required, set below.

                                $STIGData = @{
                                    StigXmlPath = $StigXmlPath
                                    StigVersion = $STIGVersion
                                    Name        = $Item.Name
                                    ShortName   = $Item.ShortName
                                    PsModule    = $Item.PsModule
                                    CanCombine  = $Item.CanCombine
                                }

                                # Reset WebOrDatabase, Site, and Instance for each STIG.
                                $TargetData.WebOrDatabase = $false
                                $TargetData.Site = ""
                                $TargetData.Instance = ""

                                # Set parameters for Invoke-STIGScan
                                $ScanArgs = @{
                                    StigXmlPath           = $StigXmlPath
                                    VulnTimeout           = $VulnTimeout
                                    Deprecated            = $Item.Deprecated
                                    AllowSeverityOverride = $AllowSeverityOverride
                                    SelectVuln            = $SelectVuln
                                    ExcludeVuln           = $ExcludeVuln
                                    Forced                = $Item.Forced
                                    ModulesPath           = $(Join-Path -Path $ES_Path -ChildPath "Modules")
                                    PsModule              = $Item.PsModule
                                    LogPath               = $STIGLog
                                    LogComponent          = $LogComponent
                                    OSPlatform            = $OSPlatform
                                    ProgressId            = $ProgressId
                                    ModuleArgs            = @{} # Initialze ModuleArgs object
                                }

                                # Set common arguments for scan module.  Additional variables and parameters may be added.
                                $ScanArgs.ModuleArgs.Add("ScanType", $ScanType)
                                if ($Item.AnswerFile.FullName) {
                                    $ScanArgs.ModuleArgs.Add("AnswerFile", "'$($Item.AnswerFile.FullName)'")
                                }
                                else {
                                    $ScanArgs.ModuleArgs.Add("AnswerFile", "")
                                }
                                $ScanArgs.ModuleArgs.Add("AnswerKey", $AnswerKey)
                                $ScanArgs.ModuleArgs.Add("Username", "NA")
                                $ScanArgs.ModuleArgs.Add("UserSID", "NA")
                                $ScanArgs.ModuleArgs.Add("ESVersion", $ESVersion)
                                $ScanArgs.ModuleArgs.Add("LogPath", $STIGLog)
                                $ScanArgs.ModuleArgs.Add("OSPlatform", $OSPlatform)
                                $ScanArgs.ModuleArgs.Add("LogComponent", $LogComponent)

                                # Add additional module arguments
                                $ScanArgs.ModuleArgs.Add("DeviceInfo", $DeviceInfo)
                                $ScanArgs.ModuleArgs.Add("ShowTech", $ShowTech)
                                $ScanArgs.ModuleArgs.Add("ShowRunningConfig", $ShowRunningConfig)

                                Try {
                                    # Set output filename
                                    $BaseFileName = Format-BaseFileName -Hostname $TargetData.HostName -STIGShortName $STIGData.ShortName -STIGVersion $STIGData.StigVersion

                                    # Build and add sub job
                                    $NewObj = [PSCustomObject]@{
                                        BaseFileName = $BaseFileName
                                        STIGInfo     = $STIGInfo
                                        TargetData   = $TargetData
                                        ScanArgs     = $ScanArgs
                                    }
                                    $SubJobs.Add($NewObj)
                                }
                                Catch {
                                    Throw $_
                                }

                                # Add instance count(s) for STIG if deemed applicable
                                If ($Item.ShortName -in $ApplicableSTIGs.ShortName) {
                                    $NewObj = [PSCustomObject]@{
                                        ShortName        = $Item.ShortName
                                        Total            = ($SubJobs | Measure-Object).Count
                                        DetectionSuccess = $true
                                    }
                                    $ApplicableSTIGsCount.Add($NewObj)
                                }

                                # Add scan job if selected for scanning
                                If ($Item.Shortname -in $STIGsToProcess.ShortName) {
                                    Write-Log -Path $STIGLog -Message "Creating scan job(s) for $($Item.ShortName)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                    $NewObj = [PSCustomObject]@{
                                        STIGData = $STIGData
                                        SubJobs  = $SubJobs
                                    }
                                    $ScanJobs.Add($NewObj)
                                }

                                # Add STIG to ProcessedSTIGs for AssetData.ScanSummary
                                If ($Item.ShortName -in $STIGsToProcess.ShortName) {
                                    $Flags = @()
                                    If ($Item.Deprecated) {
                                        $Flags += "[Deprecated]"
                                    }
                                    If ($Item.Forced) {
                                        $Flags += "[Forced]"
                                    }
                                    $NewObj = [PSCustomObject]@{
                                        ShortName = $Item.ShortName
                                        Flags     = $Flags
                                    }
                                    $ProcessedSTIGs.Add($NewObj)
                                }
                            }
                            Catch {
                                Write-Log -Path $STIGLog -Message "Unable to process $($Item.ShortName) - skipping" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                $ErrorData = $_ | Get-ErrorInformation
                                If ($STIGLog -and (Test-Path $STIGLog)) {
                                    ForEach ($Prop in ($ErrorData.PSObject.Properties).Name) {
                                        Write-Log -Path $STIGLog -Message "$($Prop) : $($ErrorData.$Prop)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                    }
                                }

                                # Add a single instance count for STIG if deemed applicable
                                If ($Item.ShortName -in $ApplicableSTIGs.ShortName) {
                                    $NewObj = [PSCustomObject]@{
                                        ShortName        = $Item.ShortName
                                        Total            = 1
                                        DetectionSuccess = $false
                                    }
                                    $ApplicableSTIGsCount.Add($NewObj)
                                }
                            }
                        }

                        # Execute the scans
                        $FailedCheck = $false
                        ForEach ($Job in $ScanJobs) {
                            Try {
                                Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                $CurrentMainStep++

                                Write-Log -Path $STIGLog -Message "Invoking scan" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                $ModError = ""
                                Try {
                                    Write-Log -Path $STIGLog -Message "Importing scan module: $($Job.STIGData.PsModule)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                    If ($PowerShellVersion -lt [Version]"7.0") {
                                        Import-Module (Join-Path -Path $ES_Path -ChildPath "Modules" | Join-Path -ChildPath $($Job.STIGData.PsModule)) -ErrorAction Stop
                                    }
                                    Else {
                                        Import-Module (Join-Path -Path $ES_Path -ChildPath "Modules" | Join-Path -ChildPath $($Job.STIGData.PsModule)) -SkipEditionCheck -ErrorAction Stop
                                    }
                                    $PsModule = (Get-Module $Job.STIGData.PsModule)
                                    Write-Log -Path $STIGLog -Message "Module Version: $($PsModule.Version)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                }
                                Catch {
                                    $ModError = $_.Exception.Message
                                }

                                If ($ModError) {
                                    # If module failed to import, display reason and continue to next STIG.
                                    Write-Log -Path $STIGLog -Message "ERROR: $($ModError)" -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                }
                                Else {
                                    # Build ESData Object
                                    $ESData = [Ordered]@{
                                        ESVersion     = $ESVersion
                                        StartTime     = (Get-Date -Format 'o')
                                        ModuleName    = $PsModule.Name
                                        ModuleVersion = $PsModule.Version
                                        STIGName      = $Job.STIGData.Name
                                        STIGShortName = $Job.STIGData.ShortName
                                        CanCombine    = $Job.STIGData.CanCombine
                                        STIGXMLName   = $($Job.STIGData.StigXmlPath | Split-Path -Leaf)
                                        FileName      = ""
                                    }

                                    # Set filename and additional requirements
                                    ForEach ($SubJob in $Job.SubJobs) {
                                        # Update BaseFileName if -SelectVuln is used
                                        If ($SelectVuln) {
                                            $SubJob.BaseFileName = "Partial_$($SubJob.BaseFileName)"
                                        }

                                        # Write Site/Intance info to log
                                        If ($SubJob.TargetData.Site) {
                                            Write-Log -Path $STIGLog -Message "Site: $($SubJob.TargetData.Site)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                        }
                                        If ($SubJob.TargetData.Instance) {
                                            Write-Log -Path $STIGLog -Message "Instance: $($SubJob.TargetData.Instance)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                        }

                                        # Execute scan
                                        $ScanArgs = $SubJob.ScanArgs
                                        $VulnResults = Invoke-STIGScan @ScanArgs

                                        # Look for any failed checks
                                        If ($VulnResults | Where-Object CheckError -EQ $true) {
                                            $FailedCheck = $true
                                        }

                                        # Calculate Score and add to STIGInfo : (NF + NA) / Total Checks * 100
                                        $EvalScore = [System.Math]::Round((($VulnResults | Where-Object Status -In @("NotAFinding", "Not_Applicable") | Measure-Object).Count / ($VulnResults | Measure-Object).Count * 100), 2)
                                        $SubJob.STIGInfo.EvalScore = $EvalScore
                                        Write-Log -Path $STIGLog -Message "EvalScore: $($EvalScore)%" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                                        # Build ScanObject
                                        $ScanObject = [System.Collections.Generic.List[System.Object]]::new()
                                        $NewObj = [PSCustomObject]@{
                                            AssetData   = $AssetData
                                            ESData      = $ESData
                                            STIGInfo    = $SubJob.STIGInfo
                                            TargetData  = $SubJob.TargetData
                                            VulnResults = $VulnResults
                                        }
                                        $ScanObject.Add($NewObj)

                                        # Send ScanObject to outputs (CKL, CKLB, CSV, XCCDF)
                                        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$)")) {
                                            $tmpChecklistPath = Join-Path -Path $tmpResultsPath -ChildPath "Checklist"
                                            If (-Not(Test-Path $tmpChecklistPath)) {
                                                $null = New-Item -Path $tmpChecklistPath -ItemType Directory
                                            }
                                            $GenerateSingleCKL = $false
                                            $GenerateSingleCKLB = $false
                                            $GenerateSingleCSV = $false
                                            If ("CKL" -in $Output) {
                                                $GenerateSingleCKL = $true
                                            }
                                            If ("CombinedCKL" -in $Output) {
                                                If ($ScanObject.ESData.CanCombine -ne $true) {
                                                    $GenerateSingleCKL = $true
                                                }
                                            }
                                            If ("CKLB" -in $Output) {
                                                $GenerateSingleCKLB = $true
                                            }
                                            If ("CombinedCKLB" -in $Output) {
                                                If ($ScanObject.ESData.CanCombine -ne $true) {
                                                    $GenerateSingleCKLB = $true
                                                }
                                            }
                                            If ("CSV" -in $Output) {
                                                $GenerateSingleCSV = $true
                                            }
                                            If ("CombinedCSV" -in $Output) {
                                                If ($ScanObject.ESData.CanCombine -ne $true) {
                                                    $GenerateSingleCSV = $true
                                                }
                                            }
                                            If ("XCCDF" -in $Output) {
                                                $GenerateSingleXCCDF = $true
                                            }

                                            If ($GenerateSingleCKL) {
                                                Write-Log -Path $STIGLog -Message "Creating CKL file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                                Write-Log -Path $STIGLog -Message "ESPath : $ES_Path" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                                $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($SubJob.BaseFileName)_$(Get-Date -Format yyyyMMdd-HHmmss).ckl")
                                                $ChecklistValid = Format-CKL -SchemaPath $Checklist_xsd -ScanObject $ScanObject -OutputPath $SaveFile -Marking $Marking -WorkingDir $WorkingDir -ESPath $ES_Path -OSPlatform $OSPlatform -LogComponent $LogComponent

                                                # Action for validation result
                                                If ($ChecklistValid) {
                                                    $ScanObject.ESData.FileName = $(Split-Path $SaveFile -Leaf)
                                                }
                                            }

                                            If ($GenerateSingleCKLB) {
                                                Write-Log -Path $STIGLog -Message "Creating CKLB file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                                $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($SubJob.BaseFileName)_$(Get-Date -Format yyyyMMdd-HHmmss).cklb")
                                                $ChecklistValid = Format-CKLB -SchemaPath $Checklist_json -ScanObject $ScanObject -OutputPath $SaveFile -Marking $Marking -WorkingDir $WorkingDir -ESPath $ES_Path -OSPlatform $OSPlatform -LogComponent $LogComponent

                                                # Action for validation result
                                                If ($ChecklistValid) {
                                                    $ScanObject.ESData.FileName = $(Split-Path $SaveFile -Leaf)
                                                }
                                            }

                                            if ($GenerateSingleCSV){
                                                Write-Log -Path $STIGLog -Message "Creating CSV file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                                $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($SubJob.BaseFileName)_$(Get-Date -Format yyyyMMdd-HHmmss).csv")
                                                Format-Object -ScanObject $ScanObject -OutputPayload $OutputPayload | Export-CSV -NoTypeInformation -Path $SaveFile

                                                $ScanObject.ESData.FileName = $(Split-Path $SaveFile -Leaf)
                                            }

                                            If ($GenerateSingleXCCDF) {
                                                Write-Log -Path $STIGLog -Message "Creating XCCDF file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                                $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($SubJob.BaseFileName)_$(Get-Date -Format yyyyMMdd-HHmmss).xccdf.xml")
                                                $XCCDF = Format-XCCDF -ScanObject $ScanObject -OutputPath $SaveFile -Marking $Marking -ESPath $ES_Path

                                                # Action for validation result
                                                If ($XCCDF -eq $true) {
                                                    $ScanObject.ESData.FileName = $(Split-Path $SaveFile -Leaf)
                                                }
                                                Else {
                                                    $XCCDF | Get-ErrorInformation
                                                    ForEach ($Prop in ($ErrorData.PSObject.Properties).Name) {
                                                        Write-Log -Path $STIGLog -Message "$($Prop) : $($ErrorData.$Prop)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                                    }
                                                }
                                            }
                                        }
                                        # Add to ScanObjects object console or combined checklist output
                                        $ScanObjects.Add($ScanObject)
                                    }

                                    Write-Log -Path $STIGLog -Message "Removing scan module from memory" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                    Remove-Module $Job.STIGData.PsModule -Force
                                    [System.GC]::Collect()
                                }
                            }
                            Catch {
                                $ErrorData = $_ | Get-ErrorInformation
                                If ($STIGLog -and (Test-Path $STIGLog)) {
                                    ForEach ($Prop in ($ErrorData.PSObject.Properties).Name) {
                                        Write-Log -Path $STIGLog -Message "$($Prop) : $($ErrorData.$Prop)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                    }
                                }
                                Write-Log -Path $STIGLog -Message "Continuing Processing" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                [System.GC]::Collect()
                            }
                        }

                        # Create combined checklists
                        If (($Output -split ",").Trim() -match @("(^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$)")) {
                            Write-Log -Path $STIGLog -Message "-" -TemplateMessage  LineBreak-Dash  -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            If ("CombinedCKL" -in $Output) {
                                Write-Log -Path $STIGLog -Message "Creating combined CKL file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                # Set combined checklist filename
                                If ($SelectVuln) {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "Partial_$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).ckl")
                                }
                                Else {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).ckl")
                                }
                                Format-CKL -SchemaPath $Checklist_xsd -ScanObject $ScanObjects -OutputPath $SaveFile -Marking $Marking -WorkingDir $WorkingDir -ESPath $ES_Path -OSPlatform $OSPlatform -LogComponent $LogComponent
                            }
                            If ("CombinedCKLB" -in $Output) {
                                Write-Log -Path $STIGLog -Message "Creating combined CKLB file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                # Set combined checklist filename
                                If ($SelectVuln) {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "Partial_$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).cklb")
                                }
                                Else {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).cklb")
                                }
                                Format-CKLB -SchemaPath $Checklist_json -ScanObject $ScanObjects -OutputPath $SaveFile -Marking $Marking -WorkingDir $WorkingDir -ESPath $ES_Path -OSPlatform $OSPlatform -LogComponent $LogComponent
                            }
                            If (($Output -split ",").Trim() -match @("(^CombinedCSV$)")) {
                                Write-Log -Path $STIGLog -Message "Creating combined CSV file" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                # Set combined checklist filename
                                If ($SelectVuln) {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "Partial_$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).csv")
                                }
                                Else {
                                    $SaveFile = $(Join-Path -Path $tmpChecklistPath -ChildPath "$($MachineName)_COMBINED_$(Get-Date -Format yyyyMMdd-HHmmss).csv")
                                }
                                Format-Object -ScanObject $ScanObjects -OutputPayload $OutputPayload | Export-CSV -NoTypeInformation -Path $SaveFile
                            }
                        }

                        If ($FailedCheck -eq $true) {
                            Write-Log -Path $STIGLog -Message "Please report issues to https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig/-/issues" -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                        }

                        # Send results to STIG Manager
                        If (($Output -split ",").Trim() -match @("(^STIGManager$)")) {
                            Write-Log -Path $STIGLog -Message "-" -TemplateMessage  LineBreak-Dash  -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            Try {
                                if ($SMPassphrase){
                                    $SMImport_Params = Get-SMParameters -SMCollection $SMCollection -SMPassphrase $SMPassphrase -ScanObject $ScanObjects -ScriptRoot $ES_Path -WorkingDir $WorkingDir -OSPlatform $OSPlatform -LogComponent $LogComponent -Logpath $STIGLog
                                }
                                else{
                                    $SMImport_Params = Get-SMParameters -SMCollection $SMCollection -ScanObject $ScanObjects -ScriptRoot $ES_Path -WorkingDir $WorkingDir -OSPlatform $OSPlatform -LogComponent $LogComponent -Logpath $STIGLog
                                }

                                Import-Asset @SMImport_Params

                                # Copy Evaluate-STIG_STIGManager.log to results path
                                Copy-Item $(Join-Path -Path $WorkingDir -ChildPath "Evaluate-STIG_STIGManager.log") -Destination $ResultsPath -Force -ErrorAction Stop
                            }
                            Catch {
                                Write-Log -Path $STIGLog -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                            }
                        }

                        # Send results to Splunk
                        If (($Output -split ",").Trim() -match @("(^Splunk$)")) {
                            Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Importing to Splunk" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                            $CurrentMainStep++
                            Try {
                                $Splunk_Params = Get-SplunkParameters -SplunkHECName $SplunkHECName -OutputPayload $OutputPayload -ScanObject $ScanObjects -ScriptRoot $PsScriptRoot -WorkingDir $WorkingDir -OSPlatform $OSPlatform -LogComponent $LogComponent -Logpath $STIGLog

                                Import-Event @Splunk_Params
                            }
                            Catch {
                                Write-Log -Path $STIGLog -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                            }
                        }

                        Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                        # Get RiskScore
                        Write-Log -Path $STIGLog -Message "Calculating risk score..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        $RiskScoreObject = Get-RiskScore -ES_Path $ES_Path -ApplicableSTIGsCount $ApplicableSTIGsCount -ScanObjects $ScanObjects
                        $ScoreDataObject = [ordered]@{}
                        ForEach ($Key in $RiskScoreObject.Keys) {
                            Switch ($Key) {
                                "CountRetrievalSuccess" {
                                    If ($RiskScoreObject.$Key -ne 1) {
                                        Write-Log -Path $STIGLog -Message "Failed to get full CAT counts for grading.  Scoring will be inaccurate." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                                    }
                                }
                                "WeightedAvg" {
                                    Write-Log -Path $STIGLog -Message "$($Key): $($RiskScoreObject.$Key)%" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                }
                                DEFAULT {
                                    Write-Log -Path $STIGLog -Message "$($Key): $($RiskScoreObject.$Key)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                                }
                            }
                            $ScoreDataObject.Add($Key, $RiskScoreObject.$Key)
                        }
                        Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                        # Determine FullScan
                        $FullScan = $true
                        If ($SelectVuln -or $ExcludeVuln) {
                            # SelectVuln|ExcludeVuln automatically disqualifies as a full scan
                            $FullScan = $false
                        }
                        ForEach ($STIG in $ApplicableSTIGs.ShortName) {
                            If (-Not($ProcessedSTIGs.ShortName -match $STIG)) {
                                # Applicable STIG was not processed.  Not a full scan
                                $FullScan = $false
                            }
                        }

                        # Build ScanSummary object and add to AssetData
                        $ScanSummaryObject = [ordered]@{
                            ApplicableSTIGs = $ApplicableSTIGsCount | Sort-Object ShortName
                            ProcessedSTIGs  = $ProcessedSTIGs | Sort-Object Shortname
                            FullScan        = $FullScan
                            Score           = $ScoreDataObject
                        }
                        $AssetData.Add("ScanSummary", $ScanSummaryObject)

                        If (($Output -split ",").Trim() -match @("(^Summary$)")) {
                            # Collect AssetData from $ScanObjects
                            If (($ScanObjects.AssetData | Group-Object).Count -gt 1) {
                                $AssetData = $ScanObjects.AssetData[0]
                            }
                            Else {
                                $AssetData = $ScanObjects.AssetData
                            }

                            # Create summary report
                            Write-Log -Path $STIGLog -Message "Generating summary report" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            If ($Marking) {
                                Write-SummaryReport -AssetData $AssetData -RiskScoreObject $RiskScoreObject -ScanResult $ScanObjects -OutputPath $tmpResultsPath -ProcessedUser "NA" -Detail -Platform "Cisco" -ScanStartDate $ScanStartDate -ScanType $ScanType -Marking $Marking
                            }
                            Else {
                                Write-SummaryReport -AssetData $AssetData -RiskScoreObject $RiskScoreObject -ScanResult $ScanObjects -OutputPath $tmpResultsPath -ProcessedUser "NA" -Detail -Platform "Cisco" -ScanStartDate $ScanStartDate -ScanType $ScanType
                            }

                            # Create Summary HTML
                            $SummaryFile = Join-Path -Path $tmpResultsPath -ChildPath SummaryReport.xml
                            [xml]$TempSR = New-Object xml

                            $null = $TempSR.AppendChild($TempSR.CreateElement('Summaries'))
                            $summary = New-Object xml
                            $Summary.Load($SummaryFile)
                            $ImportedSummary = $TempSR.ImportNode($Summary.DocumentElement, $true)
                            $null = $TempSR.DocumentElement.AppendChild($ImportedSummary)

                            $TempSR.Summaries.Summary.Results.Result | ForEach-Object {
                                #Build STIG name
                                $STIGName = [String]"$($_.STIG -replace '_', ' ') V$($_.Version)R$($_.Release)"
                                If ($_.Site) {
                                    $STIGName = $STIGName + " ($($_.Site))"
                                }
                                If ($_.Instance) {
                                    $STIGName = $STIGName + " ($($_.Instance))"
                                }
                                $_.SetAttribute("STIG", $STIGName)
                                $_.SetAttribute("StartTime", [String]($_.StartTime -replace "\.\d+", ""))
                                $CurrentScoreNode = $_.AppendChild($TempSR.CreateElement('CurrentScore'))
                                $CurrentScore = ([int]$_.CAT_I.NotAFinding + [int]$_.CAT_II.NotAFinding + [int]$_.CAT_III.NotAFinding + [int]$_.CAT_I.Not_Applicable + [int]$_.CAT_II.Not_Applicable + [int]$_.CAT_III.Not_Applicable) / ([int]$_.CAT_I.Total + [int]$_.CAT_II.Total + [int]$_.CAT_III.Total)
                                $CurrentScoreNode.SetAttribute("Score", $CurrentScore)
                            }
                            $TempSR.Save($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml))

                            $SummaryReportXLST = New-Object System.XML.Xsl.XslCompiledTransform
                            $SummaryReportXLST.Load($(Join-Path -Path $ES_Path -ChildPath "xml" | Join-Path -ChildPath SummaryReport.xslt))
                            $SummaryReportXLST.Transform($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml), $(Join-Path -Path $tmpResultsPath -ChildPath SummaryReport.html))

                            if ($Marking) {
                                #Add Marking Header and Footer
                                $SRHTML = $(Join-Path -Path $tmpResultsPath -ChildPath SummaryReport.html)
                                (Get-Content $SRHTML) -replace "<body>", "<body>`n    <header align=`"center`">$Marking</header>" | Set-Content $SRHTML

                                Add-Content $(Join-Path -Path $tmpResultsPath -ChildPath SummaryReport.html) "<footer align=`"center`">$Marking</footer>"
                            }
                        }

                        # Manage previous results and move results to ResultsPath
                        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$|^Summary$|^OQE$)")) {
                            If ($SelectSTIG) {
                                $PreviousArgs = @{SelectedShortName = $SelectSTIG}
                                If (($Output -split ",").Trim() -match @("(^CombinedCKL$)")) {
                                    $PreviousArgs.Add("SelectedCombinedCKL",$true)
                                }
                                If (($Output -split ",").Trim() -match @("(^CombinedCKLB$)")) {
                                    $PreviousArgs.Add("SelectedCombinedCKLB", $true)
                                }
                                If (($Output -split ",").Trim() -match @("(^CombinedCSV$)")) {
                                    $PreviousArgs.Add("SelectedCombinedCSV", $true)
                                }
                                If (($Output -split ",").Trim() -match @("(^Summary$)")) {
                                    $PreviousArgs.Add("SelectedSummary", $true)
                                }
                                If (($Output -split ",").Trim() -match @("(^OQE$)")) {
                                    $PreviousArgs.Add("SelectedOQE", $true)
                                }
                                Initialize-PreviousProcessing -ResultsPath $ResultsPath -PreviousToKeep $PreviousToKeep @PreviousArgs -LogPath $STIGLog -LogComponent $LogComponent -OSPlatform $OSPlatform
                            }
                            Else {
                                Initialize-PreviousProcessing -ResultsPath $ResultsPath -PreviousToKeep $PreviousToKeep -LogPath $STIGLog -LogComponent $LogComponent -OSPlatform $OSPlatform
                            }

                            # Move results to ResultsPath
                            Write-Log -Path $STIGLog -Message "-" -TemplateMessage LineBreak-Dash -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            Write-Log -Path $STIGLog -Message "Copying output files to $ResultsPath" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                            Get-ChildItem $tmpResultsPath -Recurse | ForEach-Object {
                                If ($_.PSIsContainer) {
                                    If (-Not(Test-Path $(Join-Path $ResultsPath -ChildPath $_.Name))) {
                                        $null = New-Item -Path $(Join-Path $ResultsPath -ChildPath $_.Name) -ItemType Directory
                                    }
                                }
                                Else {
                                    Copy-Item -Path $_.FullName -Destination $(Join-Path -Path $ResultsPath -ChildPath $(($_.DirectoryName) -ireplace [regex]::Escape($tmpResultsPath), ""))
                                }
                            }
                        }

                        # Clean up
                        Invoke-ScanCleanup -WorkingDir $WorkingDir -Logpath $STIGLog -OSPlatform $OSPlatform -LogComponent $LogComponent

                        # Finalize log and get totals
                        $TimeToComplete = New-TimeSpan -Start $EvalStart -End (Get-Date)
                        $FormatedTime = "{0:c}" -f $TimeToComplete
                        Write-Log -Path $STIGLog -Message "Done!" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        Write-Log -Path $STIGLog -Message "Total Time : $($FormatedTime)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$)")) {
                            $TotalChecklists = (Get-ChildItem -Path "$ResultsPath\Checklist" | Where-Object {($_.Extension -In @(".ckl", ".cklb", ".csv") -or $_.Name -like "*.xccdf.xml")} | Measure-Object).Count
                            Write-Log -Path $STIGLog -Message "Total checklists in Results Directory : $($TotalChecklists)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        }
                        Write-Log -Path $STIGLog -Message "End Local Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        If ($Marking) {
                            Write-Log -Path $STIGLog -Message "                                                                                          $Marking                                                                                          " -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        }
                        Write-Log -Path $CiscoConfigLog -Message "Scan completed" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        Write-Log -Path $CiscoConfigLog -Message "Total Time : $($FormatedTime)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        Write-Log -Path $CiscoConfigLog -Message "End Config File Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Cisco -Value $(Get-Content $CiscoConfigLog)
                        Remove-Item $CiscoConfigLog

                        # Copy Evaluate-STIG.log to results path
                        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$|^Summary$|^OQE$)")) {
                            Copy-Item $STIGLog -Destination $ResultsPath -Force -ErrorAction Stop
                        }

                        # Remove temporary files
                        $TempFiles = Get-Item -Path $WorkingDir\* -Exclude Evaluate-STIG.log, Bad_CKL
                        If ($TempFiles) {
                            ForEach ($Item in $TempFiles) {
                                Try {
                                    $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
                                }
                                Catch {
                                    Write-Log -Path $STIGLog -Message "$($_.Exception.Message)" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                                    Write-Log -Path $CiscoConfigLog -Message "$($_.Exception.Message)" -Component $LogComponent -Type "Warning" -OSPlatform $OSPlatform
                                }
                            }
                        }

                        $ProgressPreference = "Continue"

                        # Build ScanResult
                        $ScanResult = @{}
                        $ScanResult.Add($MachineName, $ScanObjects)

                        Return $ScanResult
                    }
                }
                Catch {
                    $ErrorData = $_ | Get-ErrorInformation
                    If ($STIGLog -and (Test-Path $STIGLog)) {
                        ForEach ($Prop in ($ErrorData.PSObject.Properties).Name) {
                            Write-Log -Path $STIGLog -Message "$($Prop) : $($ErrorData.$Prop)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                            Write-Log -Path $CiscoConfigLog -Message "$($Prop) : $($ErrorData.$Prop)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                        }
                    }
#                    Write-Log -Path $STIGLog -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
#                    Write-Log -Path $STIGLog -Message "Terminated Processing" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
#                    Write-Log -Path $CiscoConfigLog -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
#                    Write-Log -Path $CiscoConfigLog -Message "Terminated Processing" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
#                    Write-Log -Path $CiscoConfigLog -Message "End Config File Logging" -TemplateMessage LineBreak-Text -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                }
            }

            $Job = [powershell]::Create().AddScript($CiscoBlock).AddParameters($HashArguments)
            $Job.Streams.ClearStreams()
            $Job.RunspacePool = $RunspacePool

            # Create a temporary collection for each runspace
            $temp = "" | Select-Object Job, Runspace, Hostname
            $Temp.Hostname = $Item.DeviceInfo.Hostname
            $temp.Job = $Job
            $temp.Runspace = [PSCustomObject]@{
                Instance = $Job
                State    = $Job.BeginInvoke($RSObject, $RSObject)
            }
            $null = $runspaces.Add($temp)
        }

        if (($runspaces | Measure-Object).count -gt 0) {
            Get-RunspaceData -Runspaces $Runspaces -Wait -Usage Cisco
        }

        If (($Output -split ",").Trim() -match @("(^Console$)")) {
            # Add to results to be returned to console
            If ($RSObject) {
                ForEach ($Object in $RSObject.Keys) {
                    If ($Object -in $RunspaceResults.Keys) {
                        Write-Log -Path $STIGLog_Cisco -Message "ERROR: Results for '$Object' are already added.  Cannot create multiple results for assets with the same name." -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                        Write-Host "ERROR: Results for '$Object' are already added.  Cannot create multiple results for assets with the same name." -ForegroundColor Red
                    }
                    Else {
                        Write-Log -Path $STIGLog_Cisco -Message "Adding results for '$Object'" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                        $RunspaceResults.Add($Object,$RSObject.$Object)
                    }
                }
            }
        }

        $RunspacePool.Close()
        $RunspacePool.Dispose()

        $TimeToComplete = New-TimeSpan -Start $ConfigEvalStart -End (Get-Date)
        $FormatedTime = "{0:c}" -f $TimeToComplete
        Write-Host "Done!" -ForegroundColor Green
        Write-Host "Total Time : $($FormatedTime)" -ForegroundColor Green
        Write-Host ""
        If (($Output -split ",").Trim() -match @("(^CKL$|^CKLB$|^CSV$|^XCCDF$|^CombinedCKL$|^CombinedCKLB$|^CombinedCSV$)")) {
            Write-Host "Results saved to " -ForegroundColor Green -NoNewline; Write-Host "$($OutputPath)" -ForegroundColor Cyan
            Write-Host ""
        }

        Return $RunspaceResults
    }
    Catch {
        Throw $_
    }
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAux4bypHwnYGuX
# /k7RezZJDuKnDR9Qla+QFqKrvH4gOKCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDzjYd6L
# 1X8oL66OIGajgwgEOkV4xI9djC2r0Nfld6LXMA0GCSqGSIb3DQEBAQUABIIBAFyI
# Mp8Wk01679g57mS2Pz+tOma1lpDX03fOThrmdp6A8vGoeWTssIHDPZRdR3FxPW+I
# qincZJjIsEGipLMECg8o6QCJHa73bUrhwswXuXO5Vechs5SIyg3Qy10W6JTwF7uN
# Eil53/sVSNEQOTTQNbWBOBgDG0gsNO4oThTTPONnYvZJ5qf6l5wMe4rLAzelOqyg
# kAu6NI1jQH9ODY5LL03yrqreh0RFHU8uHEieMtltgVkbdbOd9pXcQKOvwkMQj48N
# kRxBlEAM3YmoOHtlmhLh9BnYs5tztWI2PykbOpZH7Ycf3nrG14bmPv6le6/X1pKu
# Q4XQUU89ZwmDxRSF55uhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNjA5MTI0NDIyWjAv
# BgkqhkiG9w0BCQQxIgQgCIQuuRXzrvsLlfRzkO+09r+Ni/FPi6/3T18qdsqB+vQw
# DQYJKoZIhvcNAQEBBQAEggIAtDVp/vLXb2STpXAEk7rmLWFRkDOdeK/5NAWfen4B
# 8OO5+ZQh5UPdgXF+xxEg2kuTJS/NtRUY+mITEwvN4ADta2N3ZDxKZGVxM+ATVagP
# 8BSjgONTIgGklfoMtFWTIrZGNDwU/8rovDNWZDHRM2EDpuqdpj2exbGd7BAlqeup
# 3tb7t5exf7A27+P8jQxUcmhdghu5jQaCYJVMAjsH3PU/+FKvu02FhBu3qhwXYFRs
# s+dpiykjVmMO8jG4vA9r3pbqYQW1A9JAKQCnAyWTIC2OM+QIUbdIa+SlA92dZhUd
# xmI9IhOYOEsOwxXzFRYaA2rfSCnrQHaS7PtK5dv5nRcMO2VTXJSZRSH2RjbwMWNN
# 6CYBfz1rc1IphxNDJYoABpnyGhKgcu5u6aP3S7tx1+k4r803fIO/OzCTn4kqf/0g
# bTGYHFH4FhtcRrYA6TfG0tHtcFkIZlr/PLM9aVGD5T6fGSH8Ls5YrDug7k5Sku0f
# zvcdSV/jIk1Zzn4NQkWWkTQ+RS5yo8WWc2XRGCHKbdLrR/X4RkhhkEX151lSGykC
# lIbfQtPSPwqvlXJaY9geQN5J2lggJN+QVXx4J+Klyh5RW14ayEP9cFEV7cO9VUlo
# 3riObvU64VdUjsZ2d/zq6peOZyMB3yo9j919SKLTtioDSMCHBcQqLSJTseuIHh9F
# MSU=
# SIG # End signature block
