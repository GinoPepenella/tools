##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Microsoft DotNet Framework 4.0
# Version:  V2R6
# Class:    UNCLASSIFIED
# Updated:  5/19/2025
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-V225223 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225223
        STIG ID    : APPNET0031
        Rule ID    : SV-225223r961038_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : Digital signatures assigned to strongly named assemblies must be verified.
        DiscussMD5 : 5F04625CD2D79D5F38A2C408FA532398
        CheckMD5   : 5998A85DE437DBC8808C74AD505A745C
        FixMD5     : 280413122EF8E3E1BD92E3FF3A19D53E
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $Values = ""
    $Path = "HKLM:\SOFTWARE\Microsoft\StrongName\Verification"
    If (Test-Path $Path) {
        ForEach ($Item in (Get-Item $Path)) {
            If ($Item.Property) {
                $Values += "Path:`t`t`t$($Item.Name)" | Out-String
                $Values += "ValueName:`t$($Item.Property)" | Out-String
                $Values += "" | Out-String
            }
        }
        ForEach ($ChildItem in (Get-ChildItem $Path -Recurse)) {
            If ($ChildItem.Property) {
                $Values += "Path:`t`t`t$($ChildItem.Name)" | Out-String
                $Values += "ValueName:`t$($ChildItem.Property)" | Out-String
                $Values += "" | Out-String
            }
        }

        If (-Not($Values)) {
            $Status = "NotAFinding"
            $FindingDetails += "HKLM:\SOFTWARE\Microsoft\StrongName\Verification exists but no values were found within." | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "HKLM:\SOFTWARE\Microsoft\StrongName\Verification contains the following values:" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += $Values
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "HKLM:\SOFTWARE\Microsoft\StrongName\Verification does not exist" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225224 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225224
        STIG ID    : APPNET0046
        Rule ID    : SV-225224r961038_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : The Trust Providers Software Publishing State must be set to 0x23C00.
        DiscussMD5 : E829FB25D40FA75698D1565A15E9CA21
        CheckMD5   : 456345100F471F9AC3CF098F05FE5160
        FixMD5     : 1192A66371A8F773BEEED54DC2182FB4
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If ($ScanType -in @("Classified")) {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA." | Out-String
    }
    Else {
        $Compliant = $true

        $ProfileList = Get-UsersToEval

        $RegistryValueName = "State"
        ForEach ($UserProfile in $ProfileList) {
            $ProcessProfile = $false
            If (Test-Path -Path Registry::HKU\$($UserProfile.SID)) {
                $ProcessProfile = $true

                # User is logged in so check registry direcly
                $RegistryPathToCheck = "Registry::HKEY_USERS\$($UserProfile.SID)\SOFTWARE\Microsoft\Windows\CurrentVersion\WinTrust\Trust Providers\Software Publishing"
                $RegistryResult = Get-RegistryResult -Path $RegistryPathToCheck -ValueName $RegistryValueName
                $RegistryResult.Value = "0x{0:x8}" -f $RegistryResult.Value # Convert to hex and format to 0x00000000
            }
            ElseIf (Test-Path -Path "$($UserProfile.LocalPath)\NTUSER.DAT") {
                $ES_Hive_Tasks = @("Eval-STIG_LoadHive", "Eval-STIG_UnloadHive") # Potential scheduled tasks for user hive actions
                $ProcessProfile = $true

                # Load NTUSER.DAT to HKU:\ES_TEMP_(SID)
                $NTUSER_DAT = [Char]34 + "$($UserProfile.LocalPath)\NTUSER.DAT" + [Char]34
                Try {
                    $Result = Start-Process -FilePath REG -ArgumentList "LOAD HKU\ES_TEMP_$($UserProfile.SID) $($NTUSER_DAT)" -Wait -PassThru -WindowStyle Hidden
                    If ($Result.ExitCode -ne 0) {
                        Throw
                    }
                }
                Catch {
                    # REG command failed so attempt to do as SYSTEM
                    Try {
                        $Result = Invoke-TaskAsSYSTEM -TaskName $ES_Hive_Tasks[0] -FilePath REG -ArgumentList "LOAD HKU\ES_TEMP_$($UserProfile.SID) $($NTUSER_DAT)" -MaxRunInMinutes 1
                        If ($Result.LastTaskResult -ne 0) {
                            Throw "Failed to load user hive '$($NTUSER_DAT)'."
                        }
                    }
                    Catch {
                        Throw $_.Exception.Message
                    }
                }

                $RegistryPathToCheck = "Registry::HKEY_USERS\ES_TEMP_$($UserProfile.SID)\SOFTWARE\Microsoft\Windows\CurrentVersion\WinTrust\Trust Providers\Software Publishing"
                $RegistryResult = Get-RegistryResult -Path $RegistryPathToCheck -ValueName $RegistryValueName
                If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
                    $RegistryResult.Value = "0x{0:x8}" -f $RegistryResult.Value # Convert to hex and format to 0x00000000
                }

                # Unload HKU:\ES_TEMP_(SID)
                [System.GC]::Collect() # garbage collection to help unload the hive
                Start-Sleep -Seconds 1
                Try {
                    $Result = Start-Process -FilePath REG -ArgumentList "UNLOAD HKU\ES_TEMP_$($UserProfile.SID)" -Wait -PassThru -WindowStyle Hidden
                    If ($Result.ExitCode -ne 0) {
                        Throw
                    }
                }
                Catch {
                    # REG command failed so attempt to do as SYSTEM
                    Try {
                        $Result = Invoke-TaskAsSYSTEM -TaskName $ES_Hive_Tasks[1] -FilePath REG -ArgumentList "UNLOAD HKU\ES_TEMP_$($UserProfile.SID)" -MaxRunInMinutes 1
                        If ($Result.LastTaskResult -ne 0) {
                            Throw "Failed to unload user hive 'HKU\ES_TEMP_$($UserProfile.SID)'."
                        }
                    }
                    Catch {
                        Throw $_.Exception.Message
                    }
                }
            }

            If ($ProcessProfile -eq $true) {
                If (-Not($RegistryResult.Value -eq "0x00023c00" -and $RegistryResult.Type -eq "REG_DWORD")) {
                    $FindingDetails += "Username:`t$($UserProfile.Username)" | Out-String
                    $FindingDetails += "User SID:`t`t$($UserProfile.SID)" | Out-String
                    $FindingDetails += "Profile Path:`t$($UserProfile.LocalPath)" | Out-String
                    If ($RegistryResult.Type -eq "(NotFound)") {
                        $Compliant = $false
                        $FindingDetails += "Value Name:`t$RegistryValueName (Not found) [finding]" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value Name:`t$($RegistryResult.ValueName)" | Out-String
                    }
                    If ($RegistryResult.Value -ne "0x00023c00") {
                        $Compliant = $false
                        $FindingDetails += "Value:`t`t$($RegistryResult.Value) [expected '0x00023c00']" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t`t$($RegistryResult.Value)" | Out-String
                    }
                    If ($RegistryResult.Type -ne "REG_DWORD") {
                        $Compliant = $false
                        $FindingDetails += "Type:`t`t$($RegistryResult.Type) [expected 'REG_DWORD']" | Out-String
                    }
                    Else {
                        $FindingDetails += "Type:`t`t$($RegistryResult.Type)" | Out-String
                    }
                    $FindingDetails += "" | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails = "All user profiles have State configured to 0x00023c00"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225225 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225225
        STIG ID    : APPNET0048
        Rule ID    : SV-225225r961038_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : Developer certificates used with the .NET Publisher Membership Condition must be approved by the ISSO.
        DiscussMD5 : B6C699273C10A9BE6189F5DE2DE961C8
        CheckMD5   : 87B6F0C9EB05CCBEF1ED7877146287DC
        FixMD5     : 73F6127C03DCF4CE42285ED327E56A20
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    Switch ((Get-CimInstance win32_operatingsystem).OSArchitecture) {
        "32-bit" {
            $FrameworkPath = "$Env:SYSTEMROOT\Microsoft.NET\Framework\v4.0.30319"
        }
        "64-bit" {
            $FrameworkPath = "$Env:SYSTEMROOT\Microsoft.NET\Framework64\v4.0.30319"
        }
    }

    # Execute CASPOL command and trim header lines
    $CaspolCommand = "$FrameworkPath\caspol.exe -m -lg"
    [System.Collections.ArrayList]$CaspolOutput = Invoke-Expression -Command $CaspolCommand
    $i = 0
    ForEach ($Line in $CaspolOutput) {
        If ($Line -like "Please see http:*") {
            $CaspolOutput.RemoveRange(0, ($i + 1))
            Break
        }
        $i++
    }
    $CaspolOutput = $CaspolOutput | Where-Object { $_ } # Remove empty lines from array

    $IsMatching = $CaspolOutput | Select-String -Pattern '1.6.' -SimpleMatch
    If ($IsMatching) {
        $Status = 'Not_Reviewed'
        $FindingDetails += "Review the code groups below for FullTrust and publisher keys in section 1.6." | Out-String
        $FindingDetails += "" | Out-String
    }
    Else {
        $Status = 'NotAFinding'
        $FindingDetails += "Section 1.6 Publisher section does not exist.  No Publisher Membership Conditions are configured." | Out-String
        $FindingDetails += "" | Out-String
    }

    $FindingDetails += "Executed: $CaspolCommand" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += $CaspolOutput.Trim() | Out-String
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225226 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225226
        STIG ID    : APPNET0052
        Rule ID    : SV-225226r961041_rule
        CCI ID     : CCI-000186
        Rule Name  : SRG-APP-000176
        Rule Title : Encryption keys used for the .NET Strong Name Membership Condition must be protected.
        DiscussMD5 : A9EC90A60848125D4BA5783C1CAA9335
        CheckMD5   : 35339B0570CD4B9BB4238F50BEF7C36D
        FixMD5     : C4888D52A487CDCAB113A1A169BC0ACC
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $Compliant = $true

    Switch ((Get-CimInstance win32_operatingsystem).OSArchitecture) {
        "32-bit" {
            $FrameworkPath = "$Env:SYSTEMROOT\Microsoft.NET\Framework\v4.0.30319"
        }
        "64-bit" {
            $FrameworkPath = "$Env:SYSTEMROOT\Microsoft.NET\Framework64\v4.0.30319"
        }
    }

    # Execute CASPOL command and trim header lines
    $CaspolCommand = "$FrameworkPath\caspol.exe -all -lg"
    [System.Collections.ArrayList]$CaspolOutput = Invoke-Expression -Command $CaspolCommand
    $i = 0
    ForEach ($Line in $CaspolOutput) {
        If ($Line -like "Please see http:*") {
            $CaspolOutput.RemoveRange(0, ($i + 1))
            Break
        }
        $i++
    }
    $CaspolOutput = $CaspolOutput | Where-Object { $_ } # Remove empty lines from array

    $DefaultKeys = @("002400000480000094000000060200000024000052534131000400000100010007D1FA57C4AED9F0A32E84AA0FAEFD0DE9E8FD6AEC8F87FB03766C834C99921EB23BE79AD9D5DCC1DD9AD236132102900B723CF980957FC4E177108FC607774F29E8320E92EA05ECE4E821C0A5EFE8F1645C4C0C93C1AB99285D622CAA652C1DFAD63D745D6F2DE5F17E5EAF0FC4963D261C8A12436518206DC093344D5AD293", "00000000000000000400000000000000")
    $StrongNameValues = $CaspolOutput | Select-String "StrongName"
    $BetweenPattern = "StrongName - (.*?):"
    ForEach ($Line in $StrongNameValues) {
        $Result = [regex]::Match($Line, $BetweenPattern).Groups[1].Value
        If ($Result -notin $DefaultKeys) {
            $Compliant = $false
        }
    }

    If ($Compliant -eq $true) {
        $Status = "Not_Applicable"
        $FindingDetails += "Only operating system (COTS) default code groups have Strong Name Membership Conditions so this requirement is NA." | Out-String
        $FindingDetails += "" | Out-String
    }
    Else {
        $Status = "Not_Reviewed"
        $FindingDetails += "Strong Name Membership Condition detected for a not-default code group.  If the application(s) is COTS, this finding should be marked as Not Applicable.  Otherwise, ask the Systems Programmer how the private keys are protected."
        $FindingDetails += "" | Out-String
    }

    $FindingDetails += "Executed: $CaspolCommand" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += $caspolOutput.Trim() | Out-String
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225228 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225228
        STIG ID    : APPNET0060
        Rule ID    : SV-225228r1043178_rule
        CCI ID     : CCI-001184
        Rule Name  : SRG-APP-000219
        Rule Title : Remoting Services HTTP channels must utilize authentication and encryption.
        DiscussMD5 : 4DD3647667DF4CC530FC350D98C781AA
        CheckMD5   : 0DD08938703A1F8DD2A6C7FFEF7A7927
        FixMD5     : 068082AE10D66A14C5A484467AE36C20
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "channel"
        $XmlAttributeName = "ref"
        $XmlAttributeValue = "http server"
        $DotNetRemotingEnabled = $false
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "(machine\.config$|\.exe\.config$)"
        ForEach ($File in $allConfigFiles) {
            If (Test-Path $File) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $DotNetRemotingEnabled = $true
                        If ($Node.Port -ne "443") {
                            $Compliant = $false # Change compliance for this STIG item to false.
                            $FindingDetails += $File | Out-String
                            $FindingDetails += "Channel:`t$($XmlAttributeValue)" | Out-String
                            $FindingDetails += "Port:`t`t$($Node.Port)" | Out-String
                            $FindingDetails += "Confirm that this port is TLS encrypted." | Out-String
                            $FindingDetails += "" | Out-String
                        }
                    }
                }
            }
        }

        If ($DotNetRemotingEnabled -eq $false) {
            $Status = "Not_Applicable"
            $FindingDetails += "No machine.config or *.exe.config files found using .NET remoting with HTTP channel so this requirement is NA." | Out-String
        }
        ElseIf ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No misconfigured machine.config or *.exe.config files detected." | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225229 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225229
        STIG ID    : APPNET0061
        Rule ID    : SV-225229r961863_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : .Net Framework versions installed on the system must be supported.
        DiscussMD5 : 939B45DBECBBDA2CE7EB0E1EDA69BDB1
        CheckMD5   : 35383A8CDBED9AF6B9924CD62500191B
        FixMD5     : B9E18BC368F5AD3E1716CEC17E65725F
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $Compliant = $true

    # --- Begin Support Lifecycle list ---
    $EOLList = [System.Collections.Generic.List[System.Object]]::new()

    # .NET 3.5 SP1 (For Windows 10 1809+, Windows 11, and Windows Server 2019+)
    # https://learn.microsoft.com/en-us/lifecycle/products/microsoft-net-framework
    $NewObj = [PSCustomObject]@{
        Product     = "Net35"
        MinVersion  = [version]"2.0" # Minimum supported .NET version
        NextVersion = [version]"2.1" # Next .NET version
        EOL         = (Get-Date 01/09/2029)
    }
    $EOLList.Add($NewObj)

    # .NET 4
    # https://learn.microsoft.com/en-us/lifecycle/products/microsoft-net-framework
    $NewObj = [PSCustomObject]@{
        Product     = "Net4"
        MinVersion  = [version]"4.6.2" # Minimum supported .NET version
        NextVersion = [version]"4.7"   # Next .NET version
        EOL         = (Get-Date 01/12/2027)
    }
    $EOLList.Add($NewObj)

    # Windows Server 2012 R2 (.NET 3.5 only supported until Windows Server 2012 R2/2016 eol)
    # https://learn.microsoft.com/en-us/lifecycle/products/windows-server-2012-r2
    $NewObj = [PSCustomObject]@{
        Product     = "Server2012R2"
        MinVersion  = "NA" # Caption to be compared
        NextVersion = "NA" # Caption to be compared
        EOL         = (Get-Date 10/13/2026)
    }
    $EOLList.Add($NewObj)

    # Windows Server 2016 (.NET 3.5 only supported until Windows Server 2012 R2/2016 eol)
    # https://learn.microsoft.com/en-us/lifecycle/products/windows-server-2016
    $NewObj = [PSCustomObject]@{
        Product     = "Server2016"
        MinVersion  = "NA" # Caption to be compared
        NextVersion = "NA" # Caption to be compared
        EOL         = (Get-Date 01/12/2027)
    }
    $EOLList.Add($NewObj)
    # --- End Support Lifecycle list ---

    # Document operating system
    $OSName = (Get-CimInstance Win32_OperatingSystem).Caption
    If ("DisplayVersion" -in (Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").Property) {
        $DisplayVersion = Get-ItemPropertyValue "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name DisplayVersion
    }
    ElseIf ("ReleaseId" -in (Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").Property) {
        $DisplayVersion = Get-ItemPropertyValue "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name ReleaseId
    }
    If ($DisplayVersion) {
        $OSName = "$($OSName) [$($DisplayVersion)]"
    }
    $FindingDetails += "Operating system:" | Out-String
    $FindingDetails += "---------------------------------" | Out-String
    $FindingDetails += "Name:`t$($OSName)" | Out-String
    $FindingDetails += "Version:`t$((Get-CimInstance Win32_OperatingSystem).Version)" | Out-String
    $FindingDetails += "" | Out-String

    # Document enabled .NET features
    $NetFx3 = Get-WindowsFeatureState | Where-Object {$_.Name -match "(^NetFx3$|^NET-Framework-Core$)" -and $_.Enabled -eq $true}
    $NetFx4 = Get-WindowsFeatureState | Where-Object {$_.Name -match "(^NetFx4$|^NET-Framework-45-Core$|^NetFx4-AdvSrvs$|^Microsoft-Windows-NetFx4-US-OC-Package$)" -and $_.Enabled -eq $true}
    $NetFxFeatures = @($NetFx3, $NetFx4)
    If ($NetFxFeatures) {
        $FindingDetails += "Enabled .NET Windows features:" | Out-String
        $FindingDetails += "---------------------------------" | Out-String
        ForEach ($Feature in $NetFxFeatures) {
            $FindingDetails += $Feature.Name | Out-String
        }
    }
    Else {
        $FindingDetails += "No .NET Windows features are enabled" | Out-String
    }
    $FindingDetails += "" | Out-String

    # Get .Net Frameworks' mscorlib.dll
    $FrameworksPath = @("$env:SYSTEMROOT\Microsoft.NET\Framework", "$env:SYSTEMROOT\Microsoft.NET\Framework64")
    $LibraryFiles = @()
    ForEach ($Path in $FrameworksPath) {
        If (Test-Path $Path) {
            $LibraryFiles += Get-ChildItem -Path $Path -Recurse -Include mscorlib.dll
        }
    }
    If ($LibraryFiles) {
        $FindingDetails += "Library files:" | Out-String
        $FindingDetails += "---------------------------------" | Out-String
        ForEach ($File in $LibraryFiles) {
            $FindingDetails += "File Path:`t`t`t$($File.VersionInfo.Filename)" | Out-String
            If ($File.VersionInfo.ProductVersion -like "2.0*" -and $NetFx3) {
                Switch ($OSName) {
                    {$_ -like "*Windows 10*" -and [Version](Get-CimInstance Win32_OperatingSystem).Version -lt [Version]"10.0.17763"} {
                        If ([Version](Get-CimInstance Win32_OperatingSystem).Version -lt [Version]"10.0.17763") {
                            $Compliant = $false
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "OS Component:`t$true" | Out-String
                            $FindingDetails += "Support Ends:`t`tThis version of Windows 10 is EOL (see below) [finding]" | Out-String
                        }
                    }
                    {$_ -like "*Windows*Server 2012*R2*"} {
                        If ((Get-Date) -gt ($EOLList | Where-Object Product -EQ "Server2012R2").EOL) {
                            $Compliant = $false
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "OS Component:`t$true" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Server2012R2").EOL -Format MM/dd/yyyy) [finding]" | Out-String
                        }
                        Else {
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "OS Component:`t$true" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Server2012R2").EOL -Format MM/dd/yyyy)" | Out-String
                        }
                    }
                    {$_ -like "*Windows*Server 2016*"} {
                        If ((Get-Date) -gt ($EOLList | Where-Object Product -EQ "Server2016").EOL) {
                            $Compliant = $false
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "OS Component:`t$true" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Server2016").EOL -Format MM/dd/yyyy) [finding]" | Out-String
                        }
                        Else {
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "OS Component:`t$true" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Server2016").EOL -Format MM/dd/yyyy)" | Out-String
                        }
                    }
                    DEFAULT {
                        If ((Get-Date) -gt ($EOLList | Where-Object Product -EQ "Net35").EOL) {
                            $Compliant = $false
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Net35").EOL -Format MM/dd/yyyy) [finding]" | Out-String
                        }
                        Else {
                            $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                            $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Net35").EOL -Format MM/dd/yyyy)" | Out-String
                        }
                    }
                }
            }
            ElseIf ([version]$File.VersionInfo.ProductVersion -ge "4.0") {
                If ([version]$File.VersionInfo.ProductVersion -ge ($EOLList | Where-Object Product -EQ "Net4").MinVersion -and [version]$File.VersionInfo.ProductVersion -lt ($EOLList | Where-Object Product -EQ "Net4").NextVersion) {
                    If ((Get-Date) -gt ($EOLList | Where-Object Product -EQ "Net4").EOL) {
                        $Compliant = $false
                        $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                        $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Net4").EOL -Format MM/dd/yyyy) [finding]" | Out-String
                    }
                    Else {
                        $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                        $FindingDetails += "Support Ends:`t`t$(Get-Date ($EOLList | Where-Object Product -EQ "Net4").EOL -Format MM/dd/yyyy)" | Out-String
                    }
                }
                ElseIf ([version]$File.VersionInfo.ProductVersion -ge ($EOLList | Where-Object Product -EQ "Net4").NextVersion) {
                    $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion)" | Out-String
                }
                Else {
                    $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion) [finding]" | Out-String
                }
            }
            Else {
                $FindingDetails += "Version:`t`t`t$($File.VersionInfo.ProductVersion) [finding]" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
        $FindingDetails += "Ref - https://learn.microsoft.com/en-us/lifecycle/products/microsoft-net-framework" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Ref - https://support.microsoft.com/en-us/topic/clarification-on-the-support-life-cycle-for-the-net-framework-3-5-the-net-framework-3-0-and-the-net-framework-2-0-28621c7b-226c-7682-27f5-2e2a42db39c3" | Out-String
    }
    Else {
        $FindingDetails = "A .Net Framework was not found."
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225230 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225230
        STIG ID    : APPNET0062
        Rule ID    : SV-225230r961908_rule
        CCI ID     : CCI-002450
        Rule Name  : SRG-APP-000635
        Rule Title : The .NET CLR must be configured to use FIPS approved encryption modules.
        DiscussMD5 : DD644CF29F7F45ACFF4538B95D2A89E8
        CheckMD5   : 82C7FB3F2CDA1EC0A6939854DF0BE281
        FixMD5     : 46071EE3AC1BC3C332B537C97332FB8D
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "enforceFIPSPolicy"
        $XmlAttributeName = "enabled"
        $XmlAttributeValue = "false" # Non-compliant setting
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "(machine\.config$|\.exe\.config$)"
        ForEach ($File in $allConfigFiles) {
            If (Test-Path $File) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $Compliant = $false # Change compliance for this STIG item to false.
                        $FindingDetails += $File | Out-String
                        $FindingDetails += "Name:`t$($XmlElement)" | Out-String
                        $FindingDetails += "Enabled:`t$($Node.Enabled)" | Out-String
                        $FindingDetails += "`r`n"
                    }
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No machine.config or *.exe.config files found with 'enforceFIPSPolicy enabled=false'."
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225231 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225231
        STIG ID    : APPNET0063
        Rule ID    : SV-225231r961038_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : .NET must be configured to validate strong names on full-trust assemblies.
        DiscussMD5 : E211196DA56A0B202C24614BFB4DED4C
        CheckMD5   : 174A7179BD3F98C632A17BCC92834B52
        FixMD5     : 2C2EDE38EACB2C869380DBE28E2443D8
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "AllowStrongNameBypass"  # Value name identified in STIG
    $RegistryValue = @("0")  # Value expected in STIG (if REG_DWORD/REG_QWORD use hex and remove leading 0x000...)
    $RegistryType = "REG_DWORD"  # Value type expected in STIG

    $Compliant = $true

    Switch ((Get-CimInstance win32_operatingsystem).OSArchitecture) {
        "32-bit" {
            $RegistryPaths = @("HKLM:\SOFTWARE\Microsoft\.NETFramework")
        }
        "64-bit" {
            $RegistryPaths = @("HKLM:\SOFTWARE\Microsoft\.NETFramework", "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework")
        }
    }

    ForEach ($RegistryPath in $RegistryPaths) {
        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and format to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }

        If ($RegistryResult.Type -eq "(NotFound)") {
            $Compliant = $false
            $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
            $FindingDetails += "Value Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
                $FindingDetails += "Value Name:`t$RegistryValueName" | Out-String
                $FindingDetails += "Value:`t`t$($RegistryResultValue)" | Out-String
                $FindingDetails += "Type:`t`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
                $FindingDetails += "Value Name:`t$RegistryValueName" | Out-String
                If ($RegistryResult.Value -in $RegistryValue) {
                    $FindingDetails += "Value:`t`t$($RegistryResultValue)" | Out-String
                }
                Else {
                    $FindingDetails += "Value:`t`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
                }
                If ($RegistryResult.Type -eq $RegistryType) {
                    $FindingDetails += "Type:`t`t$($RegistryResult.Type)" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
                }
            }
        }
        $FindingDetails += "" | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225232 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225232
        STIG ID    : APPNET0064
        Rule ID    : SV-225232r1050651_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : .Net applications that invoke NetFx40_LegacySecurityPolicy must apply previous versions of .NET STIG guidance.
        DiscussMD5 : 141C4CEC832605868C6670F260133A32
        CheckMD5   : D81973BA43B118D609B5530EBF43F24E
        FixMD5     : 22411F04642446AE070C7D81D2653ECA
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "NetFx40_LegacySecurityPolicy"
        $XmlAttributeName = "enabled"
        $XmlAttributeValue = "true" # Non-compliant setting
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "\.exe\.config$"
        ForEach ($File in $allConfigFiles) {
            If ($File -like "*.exe.config" -and $File -notlike "$env:windir*" -and (Test-Path $File)) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $Compliant = $false # Change compliance for this STIG item to false.
                        $FindingDetails += $File | Out-String
                        $FindingDetails += "Name:`t$($XmlElement)" | Out-String
                        $FindingDetails += "Enabled:`t$($Node.Enabled)" | Out-String
                        $FindingDetails += "`r`n"
                    }
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No *.exe.config files found with 'NetFx40_LegacySecurityPolicy enabled=true'."
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225233 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225233
        STIG ID    : APPNET0065
        Rule ID    : SV-225233r961608_rule
        CCI ID     : CCI-002530
        Rule Name  : SRG-APP-000431
        Rule Title : Trust must be established prior to enabling the loading of remote code in .Net 4.
        DiscussMD5 : 0F0CA008731159C404BA2A0C6AF1DE38
        CheckMD5   : 4CEC356A4FF43E6F70EC89F92497AE4C
        FixMD5     : 0821C76AD87DA35131027E65AE40BB91
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "loadFromRemoteSources"
        $XmlAttributeName = "enabled"
        $XmlAttributeValue = "true" # Non-compliant setting
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "\.exe\.config$"
        ForEach ($File in $allConfigFiles) {
            If ($File -like "*.exe.config" -and (Test-Path $File)) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $Compliant = $false # Change compliance for this STIG item to false.
                        $FindingDetails += $File | Out-String
                        $FindingDetails += "Name:`t$($XmlElement)" | Out-String
                        $FindingDetails += "Enabled:`t$($Node.Enabled)" | Out-String
                        $FindingDetails += "`r`n"
                    }
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No *.exe.config files found with 'loadFromRemoteSources enabled=true'."
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225234 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225234
        STIG ID    : APPNET0066
        Rule ID    : SV-225234r961863_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : .NET default proxy settings must be reviewed and approved.
        DiscussMD5 : 8114D96DAA09C2069E3735E7395E8054
        CheckMD5   : F7BC9911DD6AA2CB1689C1C23BF2840C
        FixMD5     : C2D53696F5251E36210ECD82D87934E1
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "(machine\.config$|\.exe\.config$)"
        ForEach ($File in $allConfigFiles) {
            If (Test-Path $File) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $DefaultProxy = ($XML | Select-Xml -XPath "//defaultProxy" | Select-Object -ExpandProperty "Node" | Select-Object *)
                    $BypassList = ($XML | Select-Xml -XPath "//defaultProxy/bypasslist" | Select-Object -ExpandProperty "Node" | Select-Object *)
                    $Module = ($XML | Select-Xml -XPath "//defaultProxy/module" | Select-Object -ExpandProperty "Node" | Select-Object *)
                    $Proxy = ($XML | Select-Xml -XPath "//defaultProxy/proxy" | Select-Object -ExpandProperty "Node" | Select-Object *)
                    If (-Not((($DefaultProxy.enabled -eq $true) -or ($DefaultProxy.IsEmpty -eq $true -and $DefaultProxy.HasAttributes -eq $true)) -or ((($DefaultProxy.ChildNodes | Where-Object name -NE "#Whitespace") | Measure-Object).Count -eq 0) -or $Proxy.useSystemDefault -eq $true)) {
                        If ($DefaultProxy.enabled -eq $false -or $BypassList -or $Module -or $Proxy) {
                            $FindingDetails += $File | Out-String
                            If ($DefaultProxy.enabled -eq $false) {
                                $Compliant = $false
                                $FindingDetails += "Enabled:`t`t$($DefaultProxy.enabled)" | Out-String
                            }
                            If ($BypassList) {
                                $Compliant = $false
                                $FindingDetails += "BypassList:`tNOT CLEARED" | Out-String
                            }
                            If ($Module) {
                                $Compliant = $false
                                $FindingDetails += "Module:`t`tNOT CLEARED" | Out-String
                            }
                            If ($Proxy -and $Proxy.useSystemDefault -ne $true) {
                                $Compliant = $false
                                $FindingDetails += "Proxy:`t`tNOT CLEARED and 'useSystemDefault' is NOT True" | Out-String
                            }
                            $FindingDetails += "" | Out-String
                        }
                    }
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No machine.config or *.exe.config files found with 'defaultProxy enabled=false' or with 'bypasslist', 'module', or 'proxy' elements."
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225235 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225235
        STIG ID    : APPNET0067
        Rule ID    : SV-225235r960891_rule
        CCI ID     : CCI-000130
        Rule Name  : SRG-APP-000095
        Rule Title : Event tracing for Windows (ETW) for Common Language Runtime events must be enabled.
        DiscussMD5 : 507AF0046E8610FDBBC82E53383302AB
        CheckMD5   : BCE9D46590D017144C07E117515388F3
        FixMD5     : DD9F43992E4C2B0E378DE9552330AB63
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "etwEnable"
        $XmlAttributeName = "enabled"
        $XmlAttributeValue = "false" # Non-compliant setting
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "(machine\.config$|\.exe\.config$)"
        ForEach ($File in $allConfigFiles) {
            If (Test-Path $File) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $Compliant = $false # Change compliance for this STIG item to false.
                        $FindingDetails += $File | Out-String
                        $FindingDetails += "Name:`t$($XmlElement)" | Out-String
                        $FindingDetails += "Enabled:`t$($Node.Enabled)" | Out-String
                        $FindingDetails += "`r`n"
                    }
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No machine.config or *.exe.config files found with 'etwEnable enabled=false'."
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225236 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225236
        STIG ID    : APPNET0070
        Rule ID    : SV-225236r1069477_rule
        CCI ID     : CCI-002530
        Rule Name  : SRG-APP-000431
        Rule Title : Software utilizing .Net 4.0 must be identified and relevant access controls configured.
        DiscussMD5 : D7F9FEE86F2ADACAA15D6D1CA8E21E4B
        CheckMD5   : 658BE0EB7D5CC3FA6199F42DE728523F
        FixMD5     : 0800EAC891D5DB49631D6BB19F6BEA7C
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        ForEach ($File in (Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Where-Object {$_ -notlike "$($env:windir)*"})) {
            $ExePath = $File -replace "\.config$"
            If (Test-Path $ExePath) {
                $Line = (Select-String -Path $ExePath -Pattern "NETFramework,Version=v4\.\d{1,}\.{0,1}\d{0,}" -AllMatches)
                If ($Line.Matches) {
                    $Versions = @()
                    ForEach ($Value in $Line.Matches.Value) {
                        $Versions += $(((($Value -split "=v")[1] -split " ")[0]).Trim())
                    }
                    $FindingDetails += $ExePath | Out-String
                    $FindingDetails += "Net4Runtimes: $(($Versions | Select-Object -Unique) -join ', ')" | Out-String
                    $FindingDetails += "" | Out-String
                }
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225237 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225237
        STIG ID    : APPNET0071
        Rule ID    : SV-225237r1043178_rule
        CCI ID     : CCI-001184
        Rule Name  : SRG-APP-000219
        Rule Title : Remoting Services TCP channels must utilize authentication and encryption.
        DiscussMD5 : B131C0105162474C2CB36DAC9C8B58AA
        CheckMD5   : 580BCAD304DACC43E991D7A790AFC7F1
        FixMD5     : 32C581F83639C31BC9A8B3ECE9B24F39
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    If (-Not(Test-Path -Path $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt)) {
        $FindingDetails += "*** $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt does not exist so unable to complete this check.  Consider increasing the -FileSearchTimeout parameter. ***" | Out-String
    }
    Else {
        $XmlElement = "channel"
        $XmlAttributeName = "ref"
        $XmlAttributeValue = "tcp"
        $DotNetRemotingEnabled = $false
        $Compliant = $true # Set initial compliance for this STIG item to true.

        $allConfigFiles = Get-Content $env:windir\Temp\Evaluate-STIG\Evaluate-STIG_FilesToScan.txt | Select-String -Pattern "(machine\.config$|\.exe\.config$)"
        ForEach ($File in $allConfigFiles) {
            If (Test-Path $File) {
                $XML = (Select-Xml -Path $File / -ErrorAction SilentlyContinue).Node
                If ($XML) {
                    $Node = ($XML | Select-Xml -XPath "//$($XmlElement)" | Select-Object -ExpandProperty "Node" | Where-Object $XmlAttributeName -EQ $XmlAttributeValue | Select-Object *)
                    If ($Node) {
                        $DotNetRemotingEnabled = $true
                        If ($Node.Secure -ne $true) {
                            If (-Not($Node.Secure)) {
                                $Secure = "(NOT CONFIGURED)"
                            }
                            Else {
                                $Secure = $Node.Secure
                            }
                            $Compliant = $false # Change compliance for this STIG item to false.
                            $FindingDetails += $File | Out-String
                            $FindingDetails += "Channel:`t$($XmlAttributeValue)" | Out-String
                            $FindingDetails += "Secure:`t$Secure" | Out-String
                            $FindingDetails += "" | Out-String
                        }
                    }
                }
            }
        }

        If ($DotNetRemotingEnabled -eq $false) {
            $Status = "Not_Applicable"
            $FindingDetails += "No machine.config or *.exe.config files found using .NET remoting with TCP channel so this requirement is NA." | Out-String
        }
        ElseIf ($Compliant -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "No misconfigured *.exe.config files detected." | Out-String
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V225238 {
    <#
    .DESCRIPTION
        Vuln ID    : V-225238
        STIG ID    : APPNET0075
        Rule ID    : SV-225238r1069480_rule
        CCI ID     : CCI-001762
        Rule Name  : SRG-APP-000383
        Rule Title : Update and configure the .NET Framework to support TLS.
        DiscussMD5 : 29BCCFF06B9CC0EB41C5DF69B941F7B3
        CheckMD5   : 43ECED46952E69795E5AC2372E022DA2
        FixMD5     : 56D6C7B73A0F3447DF59B4F051C5A092
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $Release = Get-ItemPropertyValue -LiteralPath 'HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -ErrorAction SilentlyContinue
    If ($Release -ge 393295) {
        $FindingDetails += ".NET Framework 4 version is 4.6 or later." | Out-String
        $FindingDetails += "" | Out-String
        $RegistryValueName = "SystemDefaultTlsVersions"  # Value name identified in STIG
        $RegistryValue = @("1")  # Value expected in STIG (if REG_DWORD/REG_QWORD use hex and remove leading 0x000...)
        $RegistryType = "REG_DWORD"  # Value type expected in STIG
    }
    Else {
        $FindingDetails += ".NET Framework 4 version is less than 4.6." | Out-String
        $FindingDetails += "" | Out-String
        $RegistryValueName = "SchUseStrongCrypto"  # Value name identified in STIG
        $RegistryValue = @("1")  # Value expected in STIG (if REG_DWORD/REG_QWORD use hex and remove leading 0x000...)
        $RegistryType = "REG_DWORD"  # Value type expected in STIG
    }

    $Compliant = $true

    Switch ((Get-CimInstance win32_operatingsystem).OSArchitecture) {
        "32-bit" {
            $RegistryPaths = @("HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319")
        }
        "64-bit" {
            $RegistryPaths = @("HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319", "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319")
        }
    }

    ForEach ($RegistryPath in $RegistryPaths) {
        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and format to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }

        If ($RegistryResult.Type -eq "(NotFound)") {
            $Compliant = $false
            $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
            $FindingDetails += "Value Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
                $FindingDetails += "Value Name:`t$RegistryValueName" | Out-String
                $FindingDetails += "Value:`t`t$($RegistryResultValue)" | Out-String
                $FindingDetails += "Type:`t`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "Registry Path:`t$RegistryPath" | Out-String
                $FindingDetails += "Value Name:`t$RegistryValueName" | Out-String
                If ($RegistryResult.Value -in $RegistryValue) {
                    $FindingDetails += "Value:`t`t$($RegistryResultValue)" | Out-String
                }
                Else {
                    $FindingDetails += "Value:`t`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
                }
                If ($RegistryResult.Type -eq $RegistryType) {
                    $FindingDetails += "Type:`t`t$($RegistryResult.Type)" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
                }
            }
        }
        $FindingDetails += "" | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBF4f46qBEucWDL
# pILhuCp6f1lhSrXPY9XC6XkYmJhvsaCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILfIAjP2
# 6jVQYo1pLt/U1updl0EAdB7yCGO7AVJx7qV1MA0GCSqGSIb3DQEBAQUABIIBAIKh
# 4CtKRTyu1w31i4rUe9xvfsuNKaWgH4a3vJbkUyiKUd6vGvb/LMJ3RskrAnn8L+AZ
# jCQTB9G+jgG4DX8i6raO2zaSbpnBF/+UQdvw4mhWOmlzTOLKnU+HEeCdfyQC0AZs
# r60r2dkQTq+L4rBoVlQdN2xiYxY3os0rP18p7ih7PYSHqOw93nVDvy9lr/hMi/y4
# e336s2EQlzfdRS0/zif+vEBYb0zPJ2dfz0TKNqnc1o2zkvqih9Z5IV37oa8YzFVh
# KsxAOpfsmhNvvFRm3alTJSpwd3XtMrIyV1mSFciNLUWUo+Zu0wFH0jYYhQeK4YDE
# 3DkKbZr16y2wMibKb9WhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNjA5MTI0NDU4WjAv
# BgkqhkiG9w0BCQQxIgQgDc8e+M+TORXhX8Lzz8eNVcS/K7l8PwJqg8i4cx81DVAw
# DQYJKoZIhvcNAQEBBQAEggIARhL8mumyQ2dD6GTbVSi021Kr169pe6N51csjlXgj
# n4HLiaoyocKcCifxwBg9GbER6anTP9FppkcguEkf7MCmY+e/d372/6cGDLDUC3t5
# x8pzNDDK9rKpreMppOTGYgD+dZpK3+7dlojhVQlswXCtvtwOdCIZW0T8Q+CTrLIq
# QWG5ocLytYYQY6dfCfM7Kh7TUSbqD6Tcm3BT+iRcn3mecP3sBIdhAnOmoxxMMS9V
# 0BzKU0NFgXgx3Bm0nxcNaQqA6alRyxaIGS89Asg91l8n7RWYnyeVZs2SnuU1Kf7b
# u7Hra/Hl7QSeAl7L51+GSPxZ490sUeblGBM6lQFYuSI9/m90T1McVGzknL+x81xQ
# 2456rrKfWCy/gYhM0CfljYmywrAlNLYYGDNc7XWDIIuDjfPMusHkZT7FpnAz3kY5
# L8pSl8B8IqZvoLInRm0lF2jZhyQk+9qPszVJBtf5HWWX7Ew5KUBH79JuFSwDF73A
# jKLJKim5OP4B+xw5PC45mrXMMmL7EOmrJ1S249E8Drf99oFJzYRV5+NDwb24QVqp
# vWFIQBwA2+7klAoI9k1ptpDki4+bbwWBqUlDRmErgOUQzPKddw6lia4p+P2zX0bM
# MH7bOv6WT8Hum20mmLHLz964OvHaY2DsGWDfwuRUw1HKsXJT7793uJov3H+fk2KX
# rg8=
# SIG # End signature block
