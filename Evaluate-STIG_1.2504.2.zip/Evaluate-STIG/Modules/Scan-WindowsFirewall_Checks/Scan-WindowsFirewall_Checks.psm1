##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Microsoft Windows Defender Firewall with Advanced Security
# Version:  V2R2
# Class:    UNCLASSIFIED
# Updated:  5/13/2024
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Confirm-FWProfileEnabled {
    Param (
        [Parameter(Mandatory = $true)]
        [ValidateSet("Domain", "Private", "Public")]
        [String]$Profile
    )

    Switch ($Profile) {
        "Domain" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
        }
        "Private" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
        }
        "Public" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
        }
    }

    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = "1"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $Enabled = $false

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    If ($Profile1.Value -eq $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        $Enabled = $true
    }
    ElseIf ($Profile1.Value -eq "(NotFound)" -and $Profile2.Value -eq $ProfileValue -and $Profile2.Type -eq $RegistryType) {
        $Enabled = $true
    }

    Return $Enabled
}

Function Get-V241989 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241989
        STIG ID    : WNFWA-000001
        Rule ID    : SV-241989r922928_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must be enabled when connected to a domain.
        DiscussMD5 : A4ED1ACACBEDBF05FF6B6CB4599C3999
        CheckMD5   : 2CCF64661AE95B8CEE2A4F5421CBAF98
        FixMD5     : 1BA51E338E5281FED75E2B1959ADD0B3
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
        $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

        # Format the DWORD values
        If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Profile1Value = $Profile1.Value
        }

        If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Profile2Value = $Profile2.Value
        }

        # Check if profile is enabled
        If ($Profile1.Type -eq "(NotFound)") {
            If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
                # Profile is enabled
                $ProfileEnabled = "Enabled"
            }
            Else {
                # Profile is disabled
                $ProfileEnabled = "Disabled (Finding)"
                $Compliant = $false
            }
        }
        ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
        $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
        $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
        $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
        $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241990 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241990
        STIG ID    : WNFWA-000002
        Rule ID    : SV-241990r922930_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must be enabled when connected to a private network.
        DiscussMD5 : 571B6F72CCBF43B43679ADB436581A17
        CheckMD5   : 318D75E78162D20FB97427AE8C3BA95C
        FixMD5     : 2FED2B43F468BAA925D8F78AD4F77BFF
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    # Format the DWORD values
    If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Profile1Value = $Profile1.Value
    }

    If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Profile2Value = $Profile2.Value
    }

    # Check if profile is enabled
    If ($Profile1.Type -eq "(NotFound)") {
        If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }
    }
    ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        # Profile is enabled
        $ProfileEnabled = "Enabled"
    }
    Else {
        # Profile is disabled
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241991 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241991
        STIG ID    : WNFWA-000003
        Rule ID    : SV-241991r922932_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must be enabled when connected to a public network.
        DiscussMD5 : 0387A88B744DF16B9780CA1065C7BA7D
        CheckMD5   : 1B98BFD2A5DCE67C33215F89609202D0
        FixMD5     : 5E939E88415CEF5C8DB3EF7B99DA1A3D
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    # Format the DWORD values
    If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Profile1Value = $Profile1.Value
    }

    If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Profile2Value = $Profile2.Value
    }

    # Check if profile is enabled
    If ($Profile1.Type -eq "(NotFound)") {
        If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }
    }
    ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        # Profile is enabled
        $ProfileEnabled = "Enabled"
    }
    Else {
        # Profile is disabled
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241992 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241992
        STIG ID    : WNFWA-000004
        Rule ID    : SV-241992r922934_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must block unsolicited inbound connections when connected to a domain.
        DiscussMD5 : 60EE4DE54D75021E16358FE8568CB850
        CheckMD5   : 4392212EACEE280D82EC2526287972DC
        FixMD5     : 22B1F4A681CFACB24FEAE872FD393798
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241993 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241993
        STIG ID    : WNFWA-000005
        Rule ID    : SV-241993r922936_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a domain.
        DiscussMD5 : 572F0DABD7D2DBC07692ACD94D1F77DD
        CheckMD5   : FB09C2A1876162DF7095D18C9D18447A
        FixMD5     : C87F983DF57C793B8DC7F5CB31FB5FC8
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241994 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241994
        STIG ID    : WNFWA-000009
        Rule ID    : SV-241994r922938_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security log size must be configured for domain connections.
        DiscussMD5 : C47980FA173FB79680784CF0E8DA4B8D
        CheckMD5   : E280D26633D61A392C90F39EA0831C16
        FixMD5     : 0ABCB3B45FF8971BA14090030E10E8EF
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241995 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241995
        STIG ID    : WNFWA-000010
        Rule ID    : SV-241995r922940_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log dropped packets when connected to a domain.
        DiscussMD5 : 7662DF28CBC859EC0E3C65877C6351DA
        CheckMD5   : 47BD982BAD7A845704ECE38D62E6C7C4
        FixMD5     : 732F8C0F1EE1F79BB908F7C3FF6FFC97
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241996 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241996
        STIG ID    : WNFWA-000011
        Rule ID    : SV-241996r922942_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log successful connections when connected to a domain.
        DiscussMD5 : E8550F6B36DF5457CE263582E6306F80
        CheckMD5   : FCF37F873FD4DDDEFD7F1B1CC89C448A
        FixMD5     : 1B49E48AEB84D5E7F32EFCFB767A7072
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241997 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241997
        STIG ID    : WNFWA-000012
        Rule ID    : SV-241997r922944_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must block unsolicited inbound connections when connected to a private network.
        DiscussMD5 : 3EA3C2EFB7A6C91C46C2D05C76363A75
        CheckMD5   : 4FC96F625BC12E6209F38C44A3CA623A
        FixMD5     : 59E3792088D0648ACC62A80E3FDC59F8
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241998 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241998
        STIG ID    : WNFWA-000013
        Rule ID    : SV-241998r922946_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a private network.
        DiscussMD5 : B171C848CEE8EEA7A36B3239EF53F200
        CheckMD5   : ACE85394F5279D16B1FA41C661184A82
        FixMD5     : DF281FD83607CE6C47E8D2A0F7BCA304
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V241999 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241999
        STIG ID    : WNFWA-000017
        Rule ID    : SV-241999r922948_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security log size must be configured for private network connections.
        DiscussMD5 : 5DC729495B7B2F2EC12CBF22459171F6
        CheckMD5   : 22D3D72F3BD55C07BA8766881A536732
        FixMD5     : FA91E351AD877180706D977F74ADC5E0
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242000 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242000
        STIG ID    : WNFWA-000018
        Rule ID    : SV-242000r922950_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log dropped packets when connected to a private network.
        DiscussMD5 : 3FEA37CB0CADBB95A13D707E09B533B4
        CheckMD5   : 4B6E6C4BCEE91C6001DB698F29BA107C
        FixMD5     : 8D7D6978317471E9B3830144CEC855C7
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242001 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242001
        STIG ID    : WNFWA-000019
        Rule ID    : SV-242001r922952_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log successful connections when connected to a private network.
        DiscussMD5 : 7050FE88BB96947D547DD7B11CBA042E
        CheckMD5   : 4A776279E6709C1D598211B67A9A47EF
        FixMD5     : C91ACF5A8DB437CB0155388FBFAC8FBA
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242002 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242002
        STIG ID    : WNFWA-000020
        Rule ID    : SV-242002r922954_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must block unsolicited inbound connections when connected to a public network.
        DiscussMD5 : DA7ABC450121558E89A0D92509F38CF1
        CheckMD5   : 8ACC8A6E764371BD01102E3B9942951F
        FixMD5     : 016D1FD83EC859DEADEC20C1F08F94FA
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242003 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242003
        STIG ID    : WNFWA-000021
        Rule ID    : SV-242003r922956_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Windows Defender Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a public network.
        DiscussMD5 : 7CC73625792370833CB7828E217B460A
        CheckMD5   : 472CCD7428370B21CC6D7B4DC40D2B6B
        FixMD5     : BEB501E73E44B0F625D4A0A5546228E3
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242004 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242004
        STIG ID    : WNFWA-000024
        Rule ID    : SV-242004r922958_rule
        CCI ID     : CCI-001190
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security local firewall rules must not be merged with Group Policy settings when connected to a public network.
        DiscussMD5 : E955C0FC0562CD2B44F23C4894BD421B
        CheckMD5   : 07A496F9464D559FCBDE8E9F76DBD646
        FixMD5     : 5DFE45A303B379D3AFE12746E480DC3A
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "AllowLocalPolicyMerge"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Public) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242005 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242005
        STIG ID    : WNFWA-000025
        Rule ID    : SV-242005r922960_rule
        CCI ID     : CCI-001190
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security local connection rules must not be merged with Group Policy settings when connected to a public network.
        DiscussMD5 : D9A51000B1877ACE4793DF72F441C40F
        CheckMD5   : DE26931B2A1CFF4F78E829A47E7F0F33
        FixMD5     : 2B1864873A6C42B6B86F919DC238B5A2
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "AllowLocalIPsecPolicyMerge"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.DomainMember)) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Public) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242006 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242006
        STIG ID    : WNFWA-000027
        Rule ID    : SV-242006r922962_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security log size must be configured for public network connections.
        DiscussMD5 : EBEB5FE59955705C4F268594EC0075C0
        CheckMD5   : 1A1F045408B0FD5C5FA12EB8DDDC2794
        FixMD5     : 073728ACB3A80A243DA3DB3A482C6512
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242007 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242007
        STIG ID    : WNFWA-000028
        Rule ID    : SV-242007r922964_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log dropped packets when connected to a public network.
        DiscussMD5 : 2496E9CDF47038B892ADDBC0E37599E0
        CheckMD5   : 9FD41687C34A3BC292EE6C6EB20ACCDF
        FixMD5     : B76434F2539A697A351D38121F1B0D26
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242008 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242008
        STIG ID    : WNFWA-000029
        Rule ID    : SV-242008r922966_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : Windows Defender Firewall with Advanced Security must log successful connections when connected to a public network.
        DiscussMD5 : 790CA7E9D853E1F31178773CE4D39A94
        CheckMD5   : 124A093F444858A272CED388AEF86B47
        FixMD5     : E767E0DC9FCEF8D6BCDFAEA9923085F6
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and format to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

Function Get-V242009 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242009
        STIG ID    : WNFWA-000100
        Rule ID    : SV-242009r922967_rule
        CCI ID     : CCI-000067
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Inbound exceptions to the firewall on domain workstations must only allow authorized remote management hosts.
        DiscussMD5 : 3BC4674C024C4F71C1D5F33E175C22E3
        CheckMD5   : 36940C7CC32E94F37900BBFE291F90AB
        FixMD5     : B9D1B968178A95A3F915E7425528A0F2
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $DomainRole = Get-DomainRoleStatus
    If (-Not($DomainRole.RoleFriendlyName -in @("Member Workstation"))) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is a '$($DomainRole.RoleFriendlyName)' so this requirement is NA." | Out-String
    }
    #---=== End Custom Code ===---#

    If ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            AnswerKey    = $PSBoundParameters.AnswerKey
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }
        <#
        Space save for having more Site/DB/Apache specific keys
        if ($PSBoundParameters.SiteName){
            $GetCorpParams.Sitename = $PSBoundParameters.SiteName
        }
        if ($PSBoundParameters.Instance){
            $GetCorpParams.Instance = $PSBoundParameters.Instance
            $GetCorpParams.Database = $PSBoundParameters.Database
        }
        #>
        $AnswerData = (Get-CorporateComment @GetCorpParams)
        If ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -SeverityOverride $([String]$SeverityOverride) -Justification $([String]$Justification)
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBdu9WyA+9GMkMY
# KTQ1lKtVj9viLlu0sXZwGW5Fr7X5C6CCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIAe03V2
# tE9d6BZUQQZiruT7jBwyySdYLJ1U9389NEkOMA0GCSqGSIb3DQEBAQUABIIBAGNi
# ZNjhLfhamKRXOIk8AwUyNmsVxDswXihK0FNiec3aF3off9nSzhxQnP0ww8IrMTIm
# Zyc/KVDRXUw4aJP+OV8gEnbUaTN3iG363J7upzRPj3hPEQpYgwH/U6vD0JhB2FbE
# xc0lYbmCvqivw9OPG4ur+16iV0nC86c16251teO1B8rmoaedf+LXmf0pkG4KhVZO
# MTNyz8cguDLEre+4hKOAkbIdK5PTQrX30/AXHfwmtf01ogOKOBoxgMXKrc+TmSww
# +3BeqOxxRqEj6VDxh8CRkUwfwj22ttPQ5c1xJ8S2dv508MDQCDdEB1aZom6uDvBR
# tujrbV+omzJ3bj91LF2hggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNDE2MTU0NjQ0WjAv
# BgkqhkiG9w0BCQQxIgQgREzD9SUjms4rhMLbZaEL0RsQxjX25N/5/paECpDkPBUw
# DQYJKoZIhvcNAQEBBQAEggIANXsP42PRIWWHqcJL7MmgvN3zDwOHjTbtrWI7MPl8
# 70B6fsqXQOcx5xKdNDt2B/fsDYbgdqaD7FhLRIgifx6/Uj82Jq/XLBQqnZu2S2xW
# 3BDQLshjUIt1DuwppibPgmCyfSXU3IujLKTBWxjcdVuSXz02DmZlnmhX78glFAjf
# 1UYQcFI+jz0jS1kU9WIGvhnH5eF0sDluiC2pCgWavmxAC5xB7OE1qpnkDYQ8GBF+
# 4fzBhdEY6LpzambLYbobrRDyJhYFPqxNkbYrkeD00COeTc+G1C8mVgpa4GQDfZU1
# epW/s/JLNJasi5F+hY7wkcYQHoz9aB90nMSN1lDnaev5esDBlftmww2WsLGbAITr
# n6/xaQ2tcEUkYkWYYn5qEeg35SF14xFwPRmsEa5qxciy86xE/jVefnRH6l9dDq8B
# y9yOA/aMoenqLIaHuol2rsZamAd4KTNFgHfDjjLVe7ItIWqXw/+EkmQuWcCUws4r
# wn1lkTtLDybfMz9QngIjz/eWlYI6+C9yvE7ElnZ+ObKO0qVbdDDw9IIOkPSgMOJU
# oMqm/6bF07nnAMm5sZVL3ocZZqshl2M7s+CYLad8oC2D8zBtJIZa+48C6D5jS3Pu
# /cBmBN7ric5Ybza3mjkx/O6VcQovSk1C0YzA43mgjK64niGQiD+SLWQ6XDjnYZrl
# ZfY=
# SIG # End signature block
