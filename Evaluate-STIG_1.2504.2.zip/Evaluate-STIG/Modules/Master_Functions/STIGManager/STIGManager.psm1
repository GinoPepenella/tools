############################################
# STIG Manager functions for Evaluate-STIG #
############################################

Function ConvertTo-Base64UrlString {
    <#
      .SYNOPSIS
      Base64url encoder.
      .DESCRIPTION
      Encodes a string or byte array to base64url-encoded string.
      .PARAMETER in
      Specifies the input. Must be string, or byte array.
      .INPUTS
      You can pipe the string input to ConvertTo-Base64UrlString.
      .OUTPUTS
      ConvertTo-Base64UrlString returns the encoded string by default.
      .EXAMPLE
      PS Variable:> '{"alg":"RS256","typ":"JWT"}' | ConvertTo-Base64UrlString
      eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9
      .LINK
      https://github.com/SP3269/posh-jwt
      .LINK
      https://jwt.io/
  #>
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]$in
    )
    If ($in -is [string]) {
        Return [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($in)) -replace '\+', '-' -replace '/', '_' -replace '='
    }
    ElseIf ($in -is [byte[]]) {
        Return [Convert]::ToBase64String($in) -replace '\+', '-' -replace '/', '_' -replace '='
    }
    Else {
        Return "ConvertTo-Base64UrlString requires string or byte array input, received $($in.GetType())"
    }
}

Function New-Jwt {
    <#
      .SYNOPSIS
      Creates a JWT (JSON Web Token).
      .DESCRIPTION
      Creates signed JWT given a signing certificate and claims in JSON.
      .PARAMETER Payload
      Specifies a JWT header. Optional. Defaults to '{"alg":"RS256","typ":"JWT"}'.
      .PARAMETER Cert
      Specifies the signing certificate of type System.Security.Cryptography.X509Certificates.X509Certificate2. Must be specified and contain the private key If the algorithm in the header is RS256.

      .LINK
      https://github.com/SP3269/posh-jwt
      .LINK
      https://jwt.io/
  #>
    Param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)][string]$PayloadJson,
        [Parameter(Mandatory = $false)][System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert
    )

    $Header = '{"alg":"RS256","typ":"JWT"}'

    $encodedHeader = ConvertTo-Base64UrlString $Header
    $encodedPayload = ConvertTo-Base64UrlString $PayloadJson

    $jwt = $encodedHeader + '.' + $encodedPayload
    $toSign = [System.Text.Encoding]::UTF8.GetBytes($jwt)

    $rsa = $Cert.PrivateKey
    $sig = ConvertTo-Base64UrlString $rsa.SignData($toSign, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)

    $jwt = $jwt + '.' + $sig
    Return $jwt
}

Function Get-SMAuthToken {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$LogPath,

        [Parameter(Mandatory = $true)]
        [ValidateSet("Windows", "Linux")]
        [String]$OSPlatform,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_AUTHORITY,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_CLIENT_ID,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_CLIENT_CERT,

        [Parameter(Mandatory = $false)]
        [string]$SMImport_CLIENT_CERT_KEY,

        [Parameter(Mandatory = $false)]
        [securestring]$SMImport_CLIENT_CERT_KEY_PASSPHRASE

    )

    $SMImport_CLIENT_CERT = $SMImport_CLIENT_CERT -replace '"', ''  #Deal with quoted paths being passed

    If (-Not(Test-Path $SMImport_CLIENT_CERT)) {
        Write-Log -Path $LogPath -Message "ERROR: $SMImport_CLIENT_CERT not found." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
        Return
    }

    If ($SMImport_CLIENT_CERT_KEY) {
        $SMImport_CLIENT_CERT_KEY = $SMImport_CLIENT_CERT_KEY -replace '"', ''  #Deal with quoted paths being passed

        If (-Not(Test-Path $SMImport_CLIENT_CERT_KEY)) {
            Write-Log -Path $LogPath -Message "ERROR: $SMImport_CLIENT_CERT_KEY not found." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            Return
        }
    }

    $apiauthendpoint = "$SMImport_AUTHORITY/protocol/openid-connect/token"

    $oauthScopes = "stig-manager:stig:read stig-manager:collection stig-manager:user:read"
    $contentType = 'application/x-www-form-urlencoded'

    $json = ConvertTo-Json @{
        iss = $SMImport_CLIENT_ID
        sub = $SMImport_CLIENT_ID
        aud = $apiauthendpoint
        jti = (1..16 | ForEach-Object {[byte](Get-Random -Max 256)} | ForEach-Object ToString X2) -join ''
        exp = ([DateTimeOffset](Get-Date)).ToUnixTimeSeconds() + 60 #Expire token in 1 minute (good for repeated calls)
    }

    If ($SMImport_CLIENT_CERT_KEY) {
        $SMImport_PASSPHRASE = ConvertFrom-SecureString $SMImport_CLIENT_CERT_KEY_PASSPHRASE -AsPlainText
        $cert = [system.security.Cryptography.X509Certificates.X509Certificate2]::CreateFromEncryptedPemFile($SMImport_CLIENT_CERT, $SMImport_PASSPHRASE, $SMImport_CLIENT_CERT_KEY)
    }
    Else {
        $cert = [system.security.Cryptography.X509Certificates.X509Certificate2]::CreateFromPemFile($SMImport_CLIENT_CERT)
    }

    $signed = New-Jwt -Cert $Cert -PayloadJson $json

    $body = @{
        grant_type            = 'client_credentials'
        client_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
        client_assertion      = $signed
        scope                 = $oauthScopes
    }

    Try {
        $accessRequest = Invoke-RestMethod -Method POST -Uri $apiauthendpoint -Body $body -ContentType $contentType -ErrorAction STOP
    }
    Catch {
        Write-Log -Path $LogPath -Message "ERROR: Unable to create Access Request Token." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
        Return
    }

    $AccessToken = $accessRequest.access_token

    $authheader = @{
        Authorization = "Bearer $AccessToken"
    }

    Return $authheader
}

Function Get-SMParameters {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$SMCollection,

        [Parameter(Mandatory = $false)]
        [SecureString]$SMPassphrase,

        [Parameter(Mandatory)]
        [psobject]$ScanObject,

        [Parameter(Mandatory = $true)]
        [String]$ScriptRoot,

        [Parameter(Mandatory = $true)]
        [String]$WorkingDir,

        [Parameter(Mandatory = $true)]
        [String]$LogComponent,

        [Parameter(Mandatory = $true)]
        [String]$OSPlatform,

        [Parameter(Mandatory = $true)]
        [String]$LogPath
    )

    Write-Log -Path $LogPath -Message "Importing to STIG Manager..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

    #Get Preferences
    $Preferences = (Select-Xml -Path $(Join-Path $ScriptRoot -ChildPath Preferences.xml) -XPath /).Node

    ForEach ($Item in ($Preferences.Preferences.STIGManager | Get-Member -MemberType Property | Where-Object Definition -Match string | Where-Object Name -NE '#comment').Name) {
        $Preferences.Preferences.STIGManager.$Item = $Preferences.Preferences.STIGManager.$Item -replace '"', '' -replace "'", ''
    }

    Try {
        If ($Preferences.Preferences.STIGManager | Select-Object -ExpandProperty SMImport_Collection | Where-Object Name -EQ $SMCollection) {
            $STIGManagerObject = $Preferences.Preferences.STIGManager | Select-Object -ExpandProperty SMImport_Collection | Where-Object Name -EQ $SMCollection
            Write-Log -Path $LogPath -Message "STIGManager Collection: $SMCollection" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
            Write-Log -Path $LogPath -Message "Uploading to STIG Manager..." -WriteOutToStream -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

            Switch ($OSPlatform) {
                "Windows" {
                    $TempLogDir = Join-Path -Path (Get-Item $env:TEMP).FullName -ChildPath "Evaluate-STIG"
                }
                "Linux" {
                    $TempLogDir = "/tmp/Evaluate-STIG"
                }
            }

            $STIGLog_STIGManager = Join-Path -Path $TempLogDir -ChildPath "Evaluate-STIG_STIGManager.log"

            $SMImport_Params = @{
                LogPath                = $STIGLog_STIGManager
                OSPlatform             = $OSPlatform
                SMImport_API_BASE      = $Preferences.Preferences.STIGManager.SMImport_API_BASE
                SMImport_AUTHORITY     = $Preferences.Preferences.STIGManager.SMImport_AUTHORITY
                SMImport_CLIENT_ID     = $STIGManagerObject.SMImport_CLIENT_ID
                SMImport_CLIENT_CERT   = $STIGManagerObject.SMImport_CLIENT_CERT
                SMImport_COLLECTION_ID = $STIGManagerObject.SMImport_COLLECTION_ID
                Scan_Objects           = $ScanObject
            }

            If ($STIGManagerObject.SMImport_CLIENT_CERT_KEY) {
                $SMImport_Params.SMImport_CLIENT_CERT_KEY = $STIGManagerObject.SMImport_CLIENT_CERT_KEY
                $SMImport_Params.SMImport_CLIENT_CERT_KEY_PASSPHRASE = $SMPassphrase
            }

            Return $SMImport_Params
        }
    }
    Catch {
        Write-Log -Path $LogPath -Message "ERROR: $($_.Exception.Message)" -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform

        Throw "Failed to import STIGManager Preferences."
    }
}

Function Import-Asset {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$LogPath,

        [Parameter(Mandatory = $true)]
        [ValidateSet("Windows", "Linux")]
        [String]$OSPlatform,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_API_BASE,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_AUTHORITY,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_CLIENT_ID,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_CLIENT_CERT,

        [Parameter(Mandatory = $false)]
        [string]$SMImport_CLIENT_CERT_KEY,

        [Parameter(Mandatory = $false)]
        [securestring]$SMImport_CLIENT_CERT_KEY_PASSPHRASE,

        [Parameter(Mandatory = $true)]
        [string]$SMImport_COLLECTION_ID,

        [Parameter(Mandatory)]
        [psobject]$Scan_Objects,

        [Parameter(Mandatory = $false)]
        [int]$MaximumRetryCount = 3
    )

    Write-Host "  Processing $(($Scan_Objects.VulnResults | Measure-Object).Count) Vulnerabilities..."

    Foreach ($Scan_Object in ($Scan_Objects | Where-Object {$null -ne $_.STIGInfo})) {
        $Body_Array = New-Object System.Collections.Generic.List[System.Object]

        $CKL_HOST_NAME = $Scan_Object.TargetData.HostName
        If ($Scan_Object.TargetData.WebOrDatabase -eq "true") {
            If ($Scan_Object.TargetData.Site) {
                $CKL_HOST_NAME = "$($CKL_HOST_NAME)-$($Scan_Object.TargetData.Site)"
            }
            Else {
                $CKL_HOST_NAME = "$($CKL_HOST_NAME)-NA"
            }
            If ($Scan_Object.TargetData.Instance) {
                $CKL_HOST_NAME = "$($CKL_HOST_NAME)-$($Scan_Object.TargetData.Instance)"
            }
            Else {
                $CKL_HOST_NAME = "$($CKL_HOST_NAME)-NA"
            }
        }

        $benchmarkId = $Scan_Object.STIGInfo.STIGID

        If ($SMImport_CLIENT_CERT_KEY) {
            $authheader = Get-SMAuthToken -LogPath $LogPath -OSPlatform $OSPlatform -SMImport_AUTHORITY $SMImport_AUTHORITY -SMImport_CLIENT_ID $SMImport_CLIENT_ID -SMImport_CLIENT_CERT $SMImport_CLIENT_CERT -SMImport_CLIENT_CERT_KEY $SMImport_CLIENT_CERT_KEY -SMImport_CLIENT_CERT_KEY_PASSPHRASE $SMImport_CLIENT_CERT_KEY_PASSPHRASE
        }
        Else {
            $authheader = Get-SMAuthToken -LogPath $LogPath -OSPlatform $OSPlatform -SMImport_AUTHORITY $SMImport_AUTHORITY -SMImport_CLIENT_ID $SMImport_CLIENT_ID -SMImport_CLIENT_CERT $SMImport_CLIENT_CERT
        }

        Try {
            $STIG = Invoke-RestMethod -Uri "$SMImport_API_BASE/stigs/$benchmarkId" -Headers $authHeader -Method GET
        }
        Catch {
            Write-Log -Path $LogPath -Message "ERROR: Unable to obtain stig, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            Return
        }

        $STIG_Data = @{
            title           = $STIG.title
            rulecount       = $STIG.rulecount
            benchmarkId     = $benchmarkID
            revisionStrs    = $STIG.revisionStrs
            lastRevisionStr = $STIG.lastRevisionDate
        }

        $Review_Data = New-Object System.Collections.Generic.List[System.Object]

        Foreach ($Vuln in $Scan_Object.VulnResults) {
            Switch ($Vuln.Status) {
                "NotAFinding" {
                    $result = "pass"
                }
                "Open" {
                    $result = "fail"
                }
                "Not_Applicable" {
                    $result = "notapplicable"
                }
                "Not_Reviewed" {
                    $result = "notchecked"
                }
            }

            If ($Vuln.STIGMan.AFMod -eq $true) {
                $NewObj = [PSCustomObject]@{
                    ruleId       = $Vuln.RuleID
                    result       = $result
                    detail       = $Vuln.FindingDetails
                    comment      = $Vuln.Comments
                    resultEngine = @{
                        type         = "script"
                        product      = "Evaluate-STIG"
                        version      = ($Scan_Object.ESData.ModuleVersion).ToString()
                        time         = $Scan_Object.ESData.StartTime
                        checkcontent = @{
                            location = $Scan_Object.ESData.ModuleName
                        }
                        overrides    = @{
                            authority = $Vuln.STIGMan.Answerfile
                            oldResult = $Vuln.STIGMan.OldStatus
                            newResult = $Vuln.STIGMan.NewStatus
                            remark    = "Evaluate-STIG Answer File"
                        }
                    }
                    saved        = "saved"
                }
            }
            Else {
                $NewObj = [PSCustomObject]@{
                    ruleId       = $Vuln.RuleID
                    result       = $result
                    detail       = $Vuln.FindingDetails
                    comment      = $Vuln.Comments
                    resultEngine = @{
                        type         = "script"
                        product      = "Evaluate-STIG"
                        version      = ($Scan_Object.ESData.ModuleVersion).ToString()
                        time         = $Scan_Object.ESData.StartTime
                        checkcontent = @{
                            location = $Scan_Object.ESData.ModuleName
                        }
                    }
                    saved        = "saved"
                }
            }

            $null = $Review_Data.Add($NewObj)
        }

        Try {
            $Collections = Invoke-RestMethod -Uri "$SMImport_API_BASE/collections" -Headers $authHeader -Method GET
        }
        Catch {
            Write-Log -Path $LogPath -Message "ERROR: Unable to obtain collections, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            Return
        }

        Try {
            $Collection = Invoke-RestMethod -Uri "$SMImport_API_BASE/assets?collectionId=$SMImport_COLLECTION_ID" -Headers $authHeader -Method GET
        }
        Catch {
            Write-Log -Path $LogPath -Message "ERROR: Unable to access $SMImport_COLLECTION_ID, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            Return
        }

        $assetid = ($collection | Where-Object { $_.name -eq $CKL_HOST_NAME }).assetid

        If (-Not($assetid)) {
            Write-Log -Path $LogPath -Message "$CKL_HOST_NAME not found in $(($Collections | Where-Object {$_.collectionID -eq $SMImport_COLLECTION_ID}).Name). Attempting POST..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform

            $body = @{
                name         = $CKL_HOST_NAME
                fqdn         = $Scan_Object.TargetData.FQDN
                collectionId = $SMImport_COLLECTION_ID
                description  = ""
                ip           = $Scan_Object.TargetData.IPAddress
                mac          = $Scan_Object.TargetData.MacAddress
                noncomputing = $false
                metadata     = @{
                    cklRole = $Scan_Object.TargetData.Role
                }
                stigs        = @($STIG_Data.ToString())
            }

            Try {
                $null = Invoke-RestMethod -Uri "$SMImport_API_BASE/assets" -Headers $authHeader -ContentType 'application/json' -Method POST -Body (ConvertTo-Json -InputObject $body -Depth 20) -SkipHttpErrorCheck -MaximumRetryCount $MaximumRetryCount

                Write-Log -Path $LogPath -Message "Able to access $CKL_HOST_NAME for POST..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
                Write-Log -Path $LogPath -Message "$CKL_HOST_NAME posted for $($STIG_Data.Title)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
            }
            Catch {
                Write-Log -Path $LogPath -Message "ERROR: Unable to access $CKL_HOST_NAME for POST, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                Return
            }
            #Get the collection again after POST
            Try {
                $Collections = Invoke-RestMethod -Uri "$SMImport_API_BASE/collections" -Headers $authHeader -Method GET
            }
            Catch {
                Write-Log -Path $LogPath -Message "ERROR: Unable to obtain collections, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                Return
            }

            Try {
                $Collection = Invoke-RestMethod -Uri "$SMImport_API_BASE/assets?collectionId=$SMImport_COLLECTION_ID" -Headers $authHeader -Method GET
            }
            Catch {
                Write-Log -Path $LogPath -Message "ERROR: Unable to access $SMImport_COLLECTION_ID, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
                Return
            }

            $assetid = ($collection | Where-Object { $_.name -eq $CKL_HOST_NAME }).assetid
        }

        $body = @{
            title           = $STIG.title
            rulecount       = $STIG.rulecount
            benchmarkId     = $benchmarkID
            revisionStrs    = $STIG.revisionStrs
            lastRevisionStr = $STIG.lastRevisionDate
        }

        Try {
            $null = Invoke-RestMethod -Uri "$SMImport_API_BASE/assets/$assetId/stigs/$benchmarkId" -Headers $authHeader -ContentType 'application/json' -Method PUT -Body (ConvertTo-Json -InputObject $body -Depth 20) -SkipHttpErrorCheck -MaximumRetryCount $MaximumRetryCount

            Write-Log -Path $LogPath -Message "Able to access $CKL_HOST_NAME for PUT..." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
            Write-Log -Path $LogPath -Message "$CKL_HOST_NAME posted for $($STIG_Data.Title) ($benchmarkId)" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        }
        Catch {
            Write-Log -Path $LogPath -Message "ERROR: Unable to access $CKL_HOST_NAME for STIG assign, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            Return
        }

        $Review_Data | ForEach-Object {
            If ($_.resultEngine.product -eq "Evaluate-STIG" ) {
                If ($_.resultEngine.overrides) {
                    $body = @{
                        ruleId       = $_.ruleId
                        result       = $_.result
                        detail       = $_.detail
                        comment      = $_.comment
                        resultEngine = @{
                            type         = $_.resultEngine.type
                            product      = $_.resultEngine.product
                            version      = $_.resultEngine.version
                            time         = $_.resultEngine.time
                            checkContent = @{
                                location = $_.resultEngine.checkcontent.location
                            }
                            overrides    = @($_.resultEngine.overrides)
                        }
                        status       = $_.saved
                    }
                }
                Else {
                    $body = @{
                        ruleId       = $_.ruleId
                        result       = $_.result
                        detail       = $_.detail
                        comment      = $_.comment
                        resultEngine = @{
                            type         = $_.resultEngine.type
                            product      = $_.resultEngine.product
                            version      = $_.resultEngine.version
                            time         = $_.resultEngine.time
                            checkContent = @{
                                location = $_.resultEngine.checkcontent.location
                            }
                        }
                        status       = $_.saved
                    }
                }
            }
            Else {
                $body = @{
                    ruleId  = $_.ruleId
                    result  = $_.result
                    detail  = $_.detail
                    comment = $_.comment
                    status  = $_.saved
                }
            }
            $null = $Body_Array.Add($body)
        }

        Try {
            Write-Host "    AssetID: $($assetId) - Uploading $(($Body_Array | Measure-Object).Count) reviews for $benchmarkID..." -ForegroundColor DarkYellow -NoNewline
            Write-Log -Path $LogPath -Message "AssetID: $($assetId) - Uploading $(($Body_Array | Measure-Object).Count) reviews for $benchmarkID" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
            $null = Invoke-RestMethod -Uri "$SMImport_API_BASE/collections/$SMImport_COLLECTION_ID/reviews/$assetId" -Headers $authHeader -ContentType 'application/json' -Method POST -Body (ConvertTo-Json -InputObject $Body_Array -Depth 20) -SkipHttpErrorCheck -MaximumRetryCount $MaximumRetryCount
            Write-Host " Success" -ForegroundColor Green
        }
        Catch {
            Write-Host " Fail" -ForegroundColor Red
            Write-Log -Path $LogPath -Message "ERROR: Unable to access $CKL_HOST_NAME for Reviews, aborting..." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
        }
    }
}

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB2PWKx5eY3jFzX
# 2QyHrOTOL+9IU5OxG8VjBycMa59s8qCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEID+MkEa6
# ps/xSCSXDCLCq2OtmqzoY/dw5qf8HkcvEkvHMA0GCSqGSIb3DQEBAQUABIIBAKLA
# tSz950THJYo3shqfsZfTNGKLv6jSUXVdYV/D2vatCAi7l6laD7/9X8zM2A4AxCai
# W/4zmnq2Lr1QglZmXAnBP9HT0pIDkBvIE3V/9z51aktYiEDStQWiJBfDGZJyxj64
# qsODs0Gz616c/d05cfQRz4CWH4k5qb6wVSmuJIBUojyv3S91td/7ZDRgA+dFJXyj
# 3vnoilNLJ6GaFgxvF+pIwWxbK7rkC8c7mfeFQLoRsX6yZhxrJyLjQ4G+jHiPzIkX
# yY/tgmT2ATUmqLpYtNjPSCZT9NqWDIsY7XNM6kDxAWsZjUJYQYLgGg/XRz2+N3Rv
# PcEwTgl1Q5z6/XN15VyhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNDA3MTI1NDEzWjAv
# BgkqhkiG9w0BCQQxIgQg8heo5juZm4Ejp1X5+jzyADUeaKYC3I4hHQRm7BgqRfsw
# DQYJKoZIhvcNAQEBBQAEggIABQG4wqc9J2WWK06NCUNOhC7sIjA7VSZYHLxLRnPb
# 0ZYK2SxRlI+uHeJVoANTMXVrDj1IqxTv+OXXn+OfWUC/OA5DrAvJ6wks8LaGr453
# 6ixeRSUXqsaC+Nf5BeeIWekopcxV8H8uwa8M5doWrcwnnFR+9ALk505KRuIri5ts
# aADKoCeZTW4DkbboA3Bj5cKTq14x6gnB3GFE24za0ocKtzjRYVEejGRbA91B88qu
# M3OUiQNOldV66GDe87ZSogCBK5iBZayu7cv2t+Fya+1r3zTShTKG5XSw2dRw5F1R
# zVqrtMYdXsXQ5lVgdw7MsiLdvH0BS4aTvzhXWgsI+2hDYo59Yt3HLsUT3xtT9wAv
# 5FH2SZ6+FiiYw4QTHaNh5rdtkL9RZPFQCtrQo7Zm8llYZJbEbM7Zd3stzts3PiW9
# YhDG1TGQhoAWl58mgLGF2IOAy+2sPP7UBoc7j95d/9OP4JoXY6PuQzkWUhPECYvT
# C6Bz5CZrFoleOws0n6f9NlWnTi2BmV7JCGcJQu0dKQuwCNgbbpvUGMK/wzMwKFwK
# Jn0ld8Iyqu1W/Voe7spqRIkLbs2DngjlqNJwcgseSXtsU+tBOl5weNLYMpo02eLp
# InjSLIGprFgwLNGcBfG2Sf3ocrZCJCIW5e7sB6UjJSb0UrOee/uAa7Mgaz8VGikH
# FBM=
# SIG # End signature block
