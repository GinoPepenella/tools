<#
    .Synopsis
    Manage Evaluate-STIG via GUI
    .DESCRIPTION
    Launches an Evaluate-STIG GUI to more easily execute Evaluate-STIG.ps1
    .EXAMPLE
    PS C:\> Manage-Evaluate-STIG.ps1
#>

Function Invoke-PowerShell {
    param (
        [Parameter(Mandatory = $true)]
        [String]$ESPath,

        [Parameter(Mandatory = $false)]
        [String]$ArgumentList,

        [Parameter(Mandatory = $false)]
        [Switch]$NoNewWindow
    )

    $ESDataBox.Text = "Generating data from `"$(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1)`" $ArgumentList.  `n`nPlease wait"
    Start-Sleep 1 #Give the GUI time to update

    if ($ArgumentList -eq "GetHelp") {
        Write-Verbose "Executing: Start-Process powershell `"Get-Help $(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1) -Full`" -NoNewWindow -Wait"
        $output = Start-Process powershell "Get-Help '$(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1)' -Full" -NoNewWindow -Wait
    }
    else {
        If (($PsVersionTable.PSVersion -join ".") -gt [Version]"7.0") {
            Write-Verbose "Executing: Start-Process pwsh `"-NoProfile -Command & '$(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1)' $ArgumentList`" -Wait -NoNewWindow"
            $output = Start-Process pwsh "-NoProfile -Command & '$(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1)' $ArgumentList" -Wait -NoNewWindow
        }
        else {
            Write-Verbose "Executing: Start-Process powershell `"-NoProfile -File $(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1) $ArgumentList`" -Wait -NoNewWindow"
            $output = Start-Process powershell "-NoProfile -Command & '$(Join-Path $ESPath -ChildPath Evaluate-STIG.ps1)' $ArgumentList" -Wait -NoNewWindow
        }
    }
    Return $output
}

function Get-Path {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$Description,

        [Parameter(Mandatory = $False)]
        [String]$RootDir
    )

    $foldername = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
        SelectedPath = "$RootDir\"
      }

    if ($foldername.ShowDialog() -eq "OK") {
        return $foldername.SelectedPath
    }
    else {
        return "no_path"
    }
}

function Get-File {

    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
        InitialDirectory = [Environment]::GetFolderPath("MyComputer")
        Filter           = "TXT Files (*.txt)|*.txt"
    }

    if ($FileBrowser.ShowDialog() -eq "OK") {
        return $FileBrowser.FileNames
    }
    else {
        return "no_path"
    }
}

Function Get-Arguments {
    if ($AllowDeprecated.Checked -eq $true) {
        $ESArgs = "-AllowDeprecated"
    }
    else{
        $ESArgs = ""
    }
    If ($SelectedSTIGS) {
        $ESArgs += " -SelectSTIG $($SelectedSTIGS -join ',')"

        If ($SelectedVulns) {
            $ESArgs += " -SelectVuln $($SelectedVulns -join ',' -replace(' ',''))"
        }
        If ($ExcludedVulns -or $Preferences.Preferences.EvaluateSTIG.ExcludeVuln) {
            if ($Preferences.Preferences.EvaluateSTIG.ExcludeVuln){
                $Preferences.Preferences.EvaluateSTIG.ExcludeVuln | Foreach-Object{$ExcludedVulns += ",$_"}
            }
            $ESArgs += " -ExcludeVuln $(($ExcludedVulns -join ',' -replace(' ','')).TrimStart(','))"
        }
    }
    ElseIf ($ExcludedSTIGS) {
        $ESArgs += " -ExcludeSTIG $($ExcludedSTIGS -join ',')"
    }

    If ($ForcedSTIGS) {
        $ESArgs += " -ForceSTIG $($ForcedSTIGS -join ',')"
    }

    if ($AltCredential.Checked -eq $true) {
        $ESArgs += " -AltCredential"
    }
    if ($ApplyTattoo.Checked -eq $true) {
        $ESArgs += " -ApplyTattoo"
    }
    if ($AllowSeverityOverride.Checked -eq $true) {
        $ESArgs += " -AllowSeverityOverride"
    }
    if ($AllowIntegrityViolations.Checked -eq $true) {
        $ESArgs += " -AllowIntegrityViolations"
    }

    $OutputOptions = @()
    if ($STIGManager.Checked -eq $true) {
        $OutputOptions += "STIGManager"
    }
    if ($Splunk.Checked -eq $true) {
        $OutputOptions += "Splunk"
    }
    if ($CKLOutput.Checked -eq $true) {
        $OutputOptions += "CKL"
    }
    if ($CKLBOutput.Checked -eq $true) {
        $OutputOptions += "CKLB"
    }
    if ($CSVOutput.Checked -eq $true) {
        $OutputOptions += "CSV"
    }
    if ($XCCDFOutput.Checked -eq $true) {
        $OutputOptions += "XCCDF"
    }
    if ($CombinedCKL.Checked -eq $true) {
        $OutputOptions += "CombinedCKL"
    }
    if ($CombinedCKLB.Checked -eq $true) {
        $OutputOptions += "CombinedCKLB"
    }
    if ($CombinedCSV.Checked -eq $true) {
        $OutputOptions += "CombinedCSV"
    }
    if ($Summary.Checked -eq $true) {
        $OutputOptions += "Summary"
    }
    if ($OQE.Checked -eq $true) {
        $OutputOptions += "OQE"
    }
    if ($OutputOptions){
        $ESArgs += " -Output $($OutputOptions -join ",")"
    }

    if ($VulnTimeoutBox.Text) {
        $ESArgs += " -VulnTimeout $($VulnTimeoutBox.Text)"
    }
    if ($FileSearchTimeoutBox.Text) {
        $ESArgs += " -FileSearchTimeout $($FileSearchTimeoutBox.Text)"
    }
    if ($PreviousToKeepBox.Text) {
        $ESArgs += " -PreviousToKeep $($PreviousToKeepBox.Text)"
    }
    if ($ThrottleLimitBox.Text) {
        $ESArgs += " -ThrottleLimit $($ThrottleLimitBox.Text)"
    }
    if ($SMPassphraseBox.Text) {
        $ESArgs += " -SMPassphrase $($SMPassphraseBox.Text)"
    }
    if ($MarkingBox.Text) {
        $ESArgs += " -Marking ""$($MarkingBox.Text)"""
    }
    if ($ScanType.SelectedItem) {
        $ESArgs += " -ScanType $($ScanType.SelectedItem)"
    }
    if ($AFKeys.SelectedItem) {
        $ESArgs += " -AnswerKey $($AFKeys.SelectedItem)"
    }
    if ($SMKeys.SelectedItem) {
        $ESArgs += " -SMCollection $($SMKeys.SelectedItem)"
    }
    if ($SplunkKeys.SelectedItem) {
        $ESArgs += " -SplunkHECName $($SplunkKeys.SelectedItem)"
    }
    if ($TargetCommentsBox.Text) {
        $ESArgs += " -TargetComments ""$($TargetCommentsBox.Text)"""
    }

    $ESArgs += " -AFPath '$ESAFPath'"

    if ($ESOutputPath -ne ""){
        $ESArgs += " -OutputPath '$ESOutputPath'"
    }

    If ($ComputerNames -and $ComputerList) {
        $ESArgs += " -ComputerName $($ComputerNames -join ',' -replace(' ','')),'$ComputerList'"
    }
    elseif ($ComputerNames) {
        $ESArgs += " -ComputerName $($ComputerNames -join ',' -replace(' ',''))"
    }
    elseif ($ComputerList) {
        $ESArgs += " -ComputerName '$ComputerList'"
    }

    if ($CiscoFileList -and $CiscoDirectory) {
        $ESArgs += " -CiscoConfig '$CiscoDirectory','$CiscoDirectory'"
    }
    elseif ($CiscoFileList) {
        $ESArgs += " -CiscoConfig '$CiscoFileList'"
    }
    elseif ($CiscoDirectory) {
        $ESArgs += " -CiscoConfig '$CiscoDirectory'"
    }

    return $ESArgs
}

Function Get-OutputPath {
    if ($CombinedCKL.Checked -or $CombinedCKLB.Checked -or $CombinedCSV.Checked -or $CKLOutput.Checked -or $CKLBOutput.Checked -or $CSVOutput.Checked -or $XCCDFOutput.Checked -or $Summary.Checked -or $OQE.Checked){
        $OutputPathButton.Enabled = $True
        if ($ESOutputPath -eq ""){
            $Script:ESOutputPath = "C:\Users\Public\Documents\STIG_Compliance"
        }
        $OutputPathLabel.Text = "OutputPath:         $ESOutputPath"

        If ($Preferences.Preferences.EvaluateSTIG.PreviousToKeep){
            $PreviousToKeepBox.Text = $Preferences.Preferences.EvaluateSTIG.PreviousToKeep
        }
        $PreviousToKeepBox.Enabled = $true
    }
    else{
        $OutputPathButton.Enabled = $false
        $Script:ESOutputPath = ""
        $OutputPathLabel.Text = "OutputPath:         Not Applicable (Output to Console, STIGManager, or Splunk)"

        $PreviousToKeepBox.Text = ""
    }

    & $handler_PreviewESButton_Click
}

Function Set-Initial {

    $form1.Controls | Where-Object { $_ -is [System.Windows.Forms.ComboBox] } | ForEach-Object { $_.Items.Clear() }

    $Script:Preferences = (Select-Xml -Path $(Join-Path $PSScriptRoot -ChildPath Preferences.xml) -XPath /).Node

    ForEach ($Item in ($Preferences.Preferences.EvaluateSTIG | Get-Member -MemberType Property | Where-Object Definition -MATCH string | Where-Object Name -NE '#comment').Name) {
        $Preferences.Preferences.EvaluateSTIG.$Item = $Preferences.Preferences.EvaluateSTIG.$Item -replace '"','' -replace "'",''
    }

    ForEach ($Item in ($Preferences.Preferences.STIGManager | Get-Member -MemberType Property | Where-Object Definition -MATCH string | Where-Object Name -NE '#comment').Name) {
        $Preferences.Preferences.STIGManager.$Item = $Preferences.Preferences.STIGManager.$Item -replace '"','' -replace "'",''
    }

    ForEach ($Item in ($Preferences.Preferences.Splunk | Get-Member -MemberType Property | Where-Object Definition -MATCH string | Where-Object Name -NE '#comment').Name) {
        $Preferences.Preferences.Splunk.$Item = $Preferences.Preferences.Splunk.$Item -replace '"','' -replace "'",''
    }

    @("Unclassified", "Classified") | ForEach-Object { $null = $ScanType.Items.Add($_) }

    If ($Preferences.Preferences.EvaluateSTIG.ScanType){
        $index = ($ScanType.Items).ToLower().Indexof($Preferences.Preferences.EvaluateSTIG.ScanType.ToLower())
        if ($index -le ($ScanType.Items | Measure-Object).count){
            $ScanType.SelectedIndex = $index
        }
    }

    If ($Preferences.Preferences.EvaluateSTIG.AFPath){
        $Script:ESAFPath = $Preferences.Preferences.EvaluateSTIG.AFPath
        $AFXMLs = Get-ChildItem -Path $ESAFPath -Filter *.xml
    }
    else{
        $Script:ESAFPath = $(Join-Path $ESFolder -ChildPath AnswerFiles)
        $AFXMLs = Get-ChildItem -Path $(Join-Path $ESFolder -ChildPath AnswerFiles) -Filter *.xml
    }
    $AFPathLabel.Text = "AFPath:             $ESAFPath"

    Foreach ($AFXML in $AFXMLS) {
        [xml]$XML = Get-Content $AFXML.FullName
        $AllAFKeys += $XML.STIGComments.Vuln.AnswerKey.Name
    }
    $AFKeys.Items.Add("")
    $AllAFKeys | Sort-Object -Unique | ForEach-Object { $null = $AFKeys.Items.Add($_) }

    If ($Preferences.Preferences.EvaluateSTIG.AnswerKey){
        $index = ($AFKeys.Items).ToLower().Indexof($Preferences.Preferences.EvaluateSTIG.AnswerKey.ToLower())
        if ($index -le ($AFKeys.Items | Measure-Object).count){
            $AFKeys.SelectedIndex = $index
        }
    }

    If (!(IsAdministrator)) {
        $ListApplicableProductsButton.Enabled = $false
    }

    $SelectSTIGButton.Enabled = $true
    $ExcludeSTIGButton.Enabled = $true
    $ForceSTIGButton.Enabled = $true
    $ExcludeVulnButton.Enabled = $false
    $SelectVulnButton.Enabled = $false
    $AltCredential.Enabled = $false
    $PreviousToKeepBox.Enabled = $false
    $ThrottleLimitBox.Enabled = $false
    $SMPassphraseBox.Enabled = $false
    $SMKeys.Enabled = $False
    $SplunkKeys.Enabled = $False
    $OutputPathButton.Enabled = $False

    $UpdateProxy.Checked = $false
    $AltCredential.Checked = $false

    $OutputNeeded

    If ($Preferences.Preferences.EvaluateSTIG.ApplyTattoo -eq "true"){
        $ApplyTattoo.Checked = $true
    }
    else{
        $ApplyTattoo.Checked = $false
    }

    If ($Preferences.Preferences.EvaluateSTIG.AllowDeprecated -eq "true"){
        $AllowDeprecated.Checked = $true
    }
    else{
        $AllowDeprecated.Checked = $false
    }

    If ($Preferences.Preferences.EvaluateSTIG.AllowSeverityOverride -eq "true"){
        $AllowSeverityOverride.Checked = $true
    }
    else{
        $AllowSeverityOverride.Checked = $false
    }

    If ($Preferences.Preferences.EvaluateSTIG.AllowIntegrityViolations -eq "true"){
        $AllowIntegrityViolations.Checked = $true
    }
    else{
        $AllowIntegrityViolations.Checked = $false
    }

    $STIGManager.Checked = $false
    $Splunk.Checked = $false
    $CKLOutput.Checked = $false
    $CKLBOutput.Checked = $false
    $CSVOutput.Checked = $false
    $XCCDFOutput.Checked = $false
    $CombinedCKL.Checked = $false
    $CombinedCKLB.Checked = $false
    $CombinedCSV.Checked = $false
    $Summary.Checked = $false
    $OQE.Checked = $false

    Switch ($($Preferences.Preferences.EvaluateSTIG.Output -split ",")){
        "STIGManager"   {$STIGManager.Checked = $True}
        "Splunk"        {$Splunk.Checked = $True}
        "CKL"           {$CKLOutput.Checked = $True}
        "CKLB"          {$CKLBOutput.Checked = $True}
        "CSV"           {$CSVOutput.Checked = $True}
        "XCCDF"         {$XCCDFOutput.Checked = $True}
        "CombinedCKL"   {$CombinedCKL.Checked = $True}
        "CombinedCKLB"  {$CombinedCKLB.Checked = $True}
        "CombinedCSV"   {$CombinedCSV.Checked = $True}
        "Summary"       {$Summary.Checked = $True}
        "OQE"           {$OQE.Checked = $True}
    }

    If ($Preferences.Preferences.EvaluateSTIG.OutputPath){
        $Script:ESOutputPath = $Preferences.Preferences.EvaluateSTIG.OutputPath
        $OutputPathLabel.Text = "OutputPath:         $ESOutputPath"
    }

    Get-OutputPath

    If ($Preferences.Preferences.EvaluateSTIG.VulnTimeout){
        $VulnTimeoutBox.Text = $Preferences.Preferences.EvaluateSTIG.VulnTimeout
    }
    else{
        $VulnTimeoutBox.Text = ""
    }

    If ($Preferences.Preferences.EvaluateSTIG.FileSearchTimeout){
        $FileSearchTimeoutBox.Text = $Preferences.Preferences.EvaluateSTIG.FileSearchTimeout
    }
    else{
        $FileSearchTimeoutBox.Text = ""
    }

    $ThrottleLimitBox.Text = ""
    $SMPassphraseBox.Text = ""

    If ($Preferences.Preferences.EvaluateSTIG.Marking){
        $MarkingBox.Text = $Preferences.Preferences.EvaluateSTIG.Marking
    }
    else{
        $MarkingBox.Text = ""
    }
    If ($Preferences.Preferences.EvaluateSTIG.TargetComments){
        $TargetCommentsBox.Text = $Preferences.Preferences.EvaluateSTIG.TargetComments
    }
    else{
        $TargetCommentsBox.Text = ""
    }
    $ESDataBox.Text = ""

    $Script:SelectedSTIGS = New-Object System.Collections.ArrayList
    $Script:ExcludedSTIGS = New-Object System.Collections.ArrayList

    if ($Preferences.Preferences.EvaluateSTIG.ExcludeSTIG){
        ($Preferences.Preferences.EvaluateSTIG.ExcludeSTIG).Split(",") | Foreach-Object {$ExcludedSTIGS.Add($_)}
        $SelectSTIGButton.Enabled = $false
    }

    $Script:SelectedVulns = ""
    $Script:ExcludedVulns = ""
    $Script:ComputerNames = ""
    $Script:ComputerList = ""
    $Script:CiscoFileList = ""
    $Script:CiscoDirectory = ""
}

Function Close-Form {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$Message
    )

    [System.Windows.MessageBox]::Show($Message, "Manage Evaluate-STIG Error", "OK", "Error")
    &$handler_formclose
}

function IsAdministrator {
    $Identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $Principal = New-Object System.Security.Principal.WindowsPrincipal($Identity)
    $Principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName PresentationFramework
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public class ProcessDPI {
    [DllImport("user32.dll", SetLastError=true)]
    public static extern bool SetProcessDPIAware();
}
'@

$null = [ProcessDPI]::SetProcessDPIAware()

$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState

$form1 = New-Object System.Windows.Forms.Form
[Windows.Forms.Application]::EnableVisualStyles()

$TitleFont = New-Object System.Drawing.Font("Consolas", 24, [Drawing.FontStyle]::Bold)
$BodyFont = New-Object System.Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$BoxFont = New-Object System.Drawing.Font("Consolas", 12, [Drawing.FontStyle]::Regular)
$BoldBoxFont = New-Object System.Drawing.Font("Consolas", 14, [Drawing.FontStyle]::Bold)
$AIVBoldBoxFont = New-Object System.Drawing.Font("Consolas", 12, [Drawing.FontStyle]::Bold)

$VLineLeft = New-Object System.Windows.Forms.Label
$HLineTop = New-Object System.Windows.Forms.Label
$HLineOptionBottom = New-Object System.Windows.Forms.Label
$HLineBottom = New-Object System.Windows.Forms.Label
$ScanTypeLabel = New-Object System.Windows.Forms.Label
$AFKeysLabel = New-Object System.Windows.Forms.Label
$SMKeysLabel = New-Object System.Windows.Forms.Label
$SplunkKeysLabel = New-Object System.Windows.Forms.Label
$AFPathLabel = New-Object System.Windows.Forms.Label
$ESPathLabel = New-Object System.Windows.Forms.Label
$OutputPathLabel = New-Object System.Windows.Forms.Label
$VulnTimeoutLabel = New-Object System.Windows.Forms.Label
$FileSearchTimeoutLabel = New-Object System.Windows.Forms.Label
$PreviousToKeepLabel = New-Object System.Windows.Forms.Label
$ThrottleLimitLabel = New-Object System.Windows.Forms.Label
$MarkingLabel = New-Object System.Windows.Forms.Label
$TargetCommentsLabel = New-Object System.Windows.Forms.Label
$SMPassphraseLabel = New-Object System.Windows.Forms.Label

$BottomLine = New-Object System.Windows.Forms.Label
$BottomLineVersion = New-Object System.Windows.Forms.Label
$Title = New-Object System.Windows.Forms.Label
$ToolsLabel = New-Object System.Windows.Forms.Label
$OptionsLabel = New-Object System.Windows.Forms.Label
$OutputLabel = New-Object System.Windows.Forms.Label

$UpdateProxy = New-Object System.Windows.Forms.Checkbox
$UpdateLocSource = New-Object System.Windows.Forms.Checkbox
$AltCredential = New-Object System.Windows.Forms.Checkbox
$ApplyTattoo = New-Object System.Windows.Forms.Checkbox
$AllowDeprecated = New-Object System.Windows.Forms.Checkbox
$AllowSeverityOverride = New-Object System.Windows.Forms.Checkbox
$AllowIntegrityViolations = New-Object System.Windows.Forms.Checkbox
$STIGManager = New-Object System.Windows.Forms.Checkbox
$Splunk = New-Object System.Windows.Forms.Checkbox
$CKLOutput = New-Object System.Windows.Forms.Checkbox
$CKLBOutput = New-Object System.Windows.Forms.Checkbox
$CSVOutput = New-Object System.Windows.Forms.Checkbox
$XCCDFOutput = New-Object System.Windows.Forms.Checkbox
$CombinedCKL = New-Object System.Windows.Forms.Checkbox
$CombinedCKLB = New-Object System.Windows.Forms.Checkbox
$CombinedCSV = New-Object System.Windows.Forms.Checkbox
$Summary = New-Object System.Windows.Forms.Checkbox
$OQE = New-Object System.Windows.Forms.Checkbox

$ScanType = New-Object System.Windows.Forms.ComboBox
$AFKeys = New-Object System.Windows.Forms.ComboBox
$SMKeys = New-Object System.Windows.Forms.ComboBox
$SplunkKeys = New-Object System.Windows.Forms.ComboBox

$STIGSelectList = New-Object System.Windows.Forms.CheckedListBox

$VulnTimeoutBox = New-Object System.Windows.Forms.TextBox
$FileSearchTimeoutBox = New-Object System.Windows.Forms.TextBox
$PreviousToKeepBox = New-Object System.Windows.Forms.TextBox
$ThrottleLimitBox = New-Object System.Windows.Forms.TextBox
$MarkingBox = New-Object System.Windows.Forms.TextBox
$TargetCommentsBox = New-Object System.Windows.Forms.TextBox

$SMPassphraseBox = New-Object System.Windows.Forms.MaskedTextBox

$ListSupportedProductsButton = New-Object System.Windows.Forms.Button
$ListApplicableProductsButton = New-Object System.Windows.Forms.Button
$UpdateESButton = New-Object System.Windows.Forms.Button
$GetHelpButton = New-Object System.Windows.Forms.Button
$ContactUsButton = New-Object System.Windows.Forms.Button
$PreviewESButton = New-Object System.Windows.Forms.Button
$ExecuteESButton = New-Object System.Windows.Forms.Button
$ResetESButton = New-Object System.Windows.Forms.Button
$AFPAthButton = New-Object System.Windows.Forms.Button
$SelectSTIGButton = New-Object System.Windows.Forms.Button
$ExcludeSTIGButton = New-Object System.Windows.Forms.Button
$ForceSTIGButton = New-Object System.Windows.Forms.Button
$SelectVulnButton = New-Object System.Windows.Forms.Button
$ExcludeVulnButton = New-Object System.Windows.Forms.Button
$OutputPathButton = New-Object System.Windows.Forms.Button
$ComputerNameButton = New-Object System.Windows.Forms.Button
$ComputerListButton = New-Object System.Windows.Forms.Button
$CiscoFilesButton = New-Object System.Windows.Forms.Button
$CiscoDirectoryButton = New-Object System.Windows.Forms.Button

$ESDataBox = New-Object -TypeName System.Windows.Forms.RichTextBox

#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------

$OnLoadForm_StateCorrection =
{ #Correct the initial state of the form to prevent the .Net maximized form issue
    $form1.WindowState = $InitialFormWindowState

    $script:ESFolder = $PSScriptRoot

    if (Test-Path $ESFolder) {
        If (Test-Path (Join-Path -Path $ESFolder -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
            [XML]$FileListXML = Get-Content -Path (Join-Path -Path $ESFolder -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
            ForEach ($File in $FileListXML.FileList.File) {
                if ($File.ScanReq -eq "Required") {
                    $Path = (Join-Path -Path $ESFolder -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                    If (!(Test-Path $Path)) {
                        $Verified = $false
                    }
                }
            }
            If ($Verified -eq $False) {
                Write-Host "ERROR: One or more Evaluate-STIG files were not found.  Unable to continue." -ForegroundColor Yellow
                Close-Form -Message "ERROR: One or more Evaluate-STIG files were not found.  Unable to continue."
            }
        }
        Else {
            Write-Host "ERROR: 'FileList.xml' not found.  Unable to verify content integrity." -ForegroundColor Red
            Close-Form -Message "ERROR: 'FileList.xml' not found.  Unable to verify content integrity."
        }
        $evalSTIGVersionNumber = ((Get-Content $(Join-Path $ESFolder -ChildPath Evaluate-STIG.ps1) | Select-String -Pattern ('EvaluateStigVersion = ')) -split ("="))[1]
        $BottomLine.Text = "Evaluate-STIG Version = $evalSTIGVersionNumber"

        $ESPathLabel.Text = "Evaluate-STIG Path: $ESFolder"
    }
    else {

        Close-Form -Message "Evaluate-STIG Path not found"
    }

    #Initial Setup
    Set-Initial
}

$handler_ListSupportedProductsButton_Click = {
    $ESDataBox.Text = (Invoke-PowerShell -ESPath $ESFolder -ArgumentList "-ListSupportedProducts" -NoNewWindow) | Format-Table -AutoSize | Out-String
}

$handler_ListApplicableProductsButton_Click = {
    $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList "-ListApplicableProducts" | Format-Table -AutoSize | Out-String
}

$handler_UpdateESButton_Click = {
    If ($UpdateProxy.Checked -eq $true) {
        $title = "Proxy"
        $msg = "Enter a Proxy for -Update:"

        $Proxy = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)
        if ($Proxy){
            $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList "-Update -Proxy $Proxy"
        }
    }
    elseif ($UpdateLocSource.Checked -eq $true){
        $GetPath = Get-Path -Description "Select Local update directory" -RootDir "c:\"

        if ($GetPath -ne "no_path") {
            $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList "-Update -LocalSource $GetPath"
        }
    }
    else {
        $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList "-Update"
    }

    $evalSTIGVersionNumber = ((Get-Content $(Join-Path $ESFolder -ChildPath Evaluate-STIG.ps1) | Select-String -Pattern ('EvaluateStigVersion = ')) -split ("="))[1]
    $BottomLine.Text = "Evaluate-STIG Version = $evalSTIGVersionNumber"
}

$handler_GetHelpButton_Click = {
    $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList "GetHelp" -NoNewWindow | Format-Table -AutoSize | Out-String
}

$handler_ContactUsButton_Click = {
    [System.Windows.MessageBox]::Show("Evaluate-STIG Contact methods:`n`n  email:`t`tEval-STIG_spt@us.navy.mil`n`n  MS Teams:`tNAVSEA_RMF `n`n  Fusion:`t`t#evaluate-stig", "Evaluate-STIG Contact Us", "OK", "Question")
}

$handler_PreviewESButton_Click = {
    $ESDataBox.Text = "Command Line to Execute:`n`n$(Join-Path $ESFolder -ChildPath Evaluate-STIG.ps1) $(Get-Arguments)" | Format-Table -AutoSize | Out-String
}

$handler_AFPathButton_Click = {
    $AFKeys | ForEach-Object {$_.Items.Clear() }

    $GetPath = Get-Path -Description "Select Answer File directory" -RootDir $ESAFPath

    if ($GetPath -ne "no_path") {
        $Script:ESAFPath = $GetPath
    }

    $AFXMLs = Get-ChildItem -Path $ESAFPath -Filter *.xml

    Foreach ($AFXML in $AFXMLS) {
        [xml]$XML = Get-Content $AFXML.FullName
        $AllAFKeys += $XML.STIGComments.Vuln.AnswerKey.Name
    }
    $AFKeys.Items.Add("")
    $AllAFKeys | Sort-Object -Unique | ForEach-Object { $null = $AFKeys.Items.Add($_) }

    $AFPathLabel.Text = "AFPath:             $ESAFPath"
    &$handler_PreviewESButton_Click
}

$handler_OutputPathButton_Click = {
    $GetPath = Get-Path -Description "Select Output Path directory" -RootDir $ESOutputPath

    if ($GetPath -ne "no_path") {
        $Script:ESOutputPath = $GetPath
    }

    $OutputPathLabel.Text = "OutputPath:         $ESOutputPath"
    &$handler_PreviewESButton_Click
}

$handler_SelectVulnButton_Click = {
    $title = "Select Vuln(s)"
    $msg = "Enter Vulnerability IDs (format V-XXXXXX), separate with commas (no spaces):"

    $Script:SelectedVulns = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)
    &$handler_PreviewESButton_Click
}

$handler_ExcludeVulnButton_Click = {
    $title = "Exclude Vuln(s)"
    $msg = "Enter Vulnerability IDs (format V-XXXXXX), separate with commas (no spaces):"

    $Script:ExcludedVulns = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)
    &$handler_PreviewESButton_Click
}

$handler_ComputerNameButton_Click = {
    $title = "Select Computers"
    $msg = "Enter Computer names, separate with commas (no spaces):"

    $Script:ComputerNames = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $title)

    $AltCredential.Enabled = $true
    $ThrottleLimitBox.Enabled = $true
    &$handler_PreviewESButton_Click
}

$handler_ComputerListButton_Click = {
    $GetPath = Get-File

    if ($GetPath -ne "no_path") {
        $Script:ComputerList = $GetPath
    }

    $AltCredential.Enabled = $true
    $ThrottleLimitBox.Enabled = $true
    &$handler_PreviewESButton_Click
}

$handler_CiscoFilesButton_Click = {
    $GetPath = Get-File

    if ($GetPath -ne "no_path") {
        $Script:CiscoFileList = $GetPath
    }
    &$handler_PreviewESButton_Click
}

$handler_CiscoDirectoryButton_Click = {
    $GetPath = Get-Path -Description "Select Cisco config directory" -RootDir "c:\"

    if ($GetPath -ne "no_path") {
        $Script:CiscoDirectory = $GetPath
    }

    $OutputPathLabel.Text = "OutputPath:         $ESOutputPath"
    &$handler_PreviewESButton_Click
}

$handler_ExecuteESButton_Click = {
    $ESDataBox.Text = Invoke-PowerShell -ESPath $ESFolder -ArgumentList $(Get-Arguments) | Format-Table -AutoSize | Out-String
    Write-Host "Manage Evaluate-STIG GUI Execution Complete" -ForegroundColor Green
    Set-Initial
}

$handler_ResetESButton_Click = {
    Set-Initial
}

$handler_SelectSTIGButton_Click = {

    $ExcludeSTIGButton.Enabled = $false
    $ExcludeVulnButton.Enabled = $true
    $SelectVulnButton.Enabled = $true

    $handler_form2close =
    {
        1..3 | ForEach-Object { [GC]::Collect() }
        if ($SelectedSTIGS.count -eq 0) {
            $ExcludeSTIGButton.Enabled = $true
        }

        $form2.Dispose()
        &$handler_PreviewESButton_Click
    }

    $handler_OKButton_Click = {
        $Script:SelectedSTIGS = $STIGSelectList.Items | Where-Object { $STIGSelectList.CheckedItems -contains $_ }
        if ($SelectedSTIGS.count -eq 0) {
            $ExcludeSTIGButton.Enabled = $true
        }
        &$handler_form2close
    }

    $handler_CancelButton_Click = {
        &$handler_form2close
    }

    $form2 = New-Object System.Windows.Forms.Form

    $form2.Text = "Select STIG(s)"
    $form2.Name = "form2"
    $form2.SuspendLayout()

    $form2.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
    $form2.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

    $STIGSelectList = New-Object System.Windows.Forms.CheckedListBox

    $OKButton = New-Object System.Windows.Forms.Button
    $CancelButton = New-Object System.Windows.Forms.Button

    $form2.FormBorderStyle = "Fixed3D"
    $form2.StartPosition = "CenterParent"
    $form2.DataBindings.DefaultDataSourceUpdateMode = 0
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1200
    $System_Drawing_Size.Height = 650
    $form2.ClientSize = $System_Drawing_Size

    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1280
    $System_Drawing_Size.Height = 600
    $STIGSelectList.Size = $System_Drawing_Size
    $STIGSelectList.Font = $BoxFont
    $STIGSelectList.Name = "STIGSelectList"
    $STIGSelectList.MultiColumn = $true
    $STIGSelectList.CheckOnClick = $true
    $STIGSelectList.ColumnWidth = 400
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 10
    $System_Drawing_Point.Y = 10
    $STIGSelectList.Location = $System_Drawing_Point
    $form2.Controls.Add($STIGSelectList)

    $OKButton.Name = "OKButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $OKButton.Size = $System_Drawing_Size
    $OKButton.UseVisualStyleBackColor = $True
    $OKButton.Text = "OK"
    $OKButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 495
    $System_Drawing_Point.Y = 600
    $OKButton.Location = $System_Drawing_Point
    $OKButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $OKButton.add_Click($handler_OKButton_Click)
    $form2.Controls.Add($OKButton)

    $CancelButton.Name = "CancelButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $CancelButton.Size = $System_Drawing_Size
    $CancelButton.UseVisualStyleBackColor = $True
    $CancelButton.Text = "Cancel"
    $CancelButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 605
    $System_Drawing_Point.Y = 600
    $CancelButton.Location = $System_Drawing_Point
    $CancelButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $CancelButton.add_Click($handler_CancelButton_Click)
    $form2.Controls.Add($CancelButton)

    $STIGListXML = Join-Path -Path $ESFolder -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
    $STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object ShortName -Unique
    ForEach ($STIG in $STIGs) {
        $STIGSelectList.Items.Add($STIG.Shortname)
    }

    $SelectedSTIGS | ForEach-Object {
        if ($STIGSelectList.Items -contains $_) {
            $index = ($STIGSelectList.Items).ToLower().Indexof($_.ToLower())
            if ($index -le ($STIGSelectList.Items | Measure-Object).count){
                $STIGSelectList.SetItemChecked($index, $true)
            }
        }
    }

    $form2.Add_FormClosed($handler_form2close)

    $null = $form2.ShowDialog()
}

$handler_ExcludeSTIGButton_Click = {

    $SelectSTIGButton.Enabled = $false

    $handler_form3close =
    {
        1..3 | ForEach-Object { [GC]::Collect() }
        if ($ExcludedSTIGS.count -eq 0) {
            $SelectSTIGButton.Enabled = $true
        }

        $form3.Dispose()
        &$handler_PreviewESButton_Click
    }

    $handler_OKButton_Click = {
        $Script:ExcludedSTIGS = $STIGExcludeList.Items | Where-Object { $STIGExcludeList.CheckedItems -contains $_ }
        if ($ExcludedSTIGS.count -eq 0) {
            $SelectSTIGButton.Enabled = $true
        }
        &$handler_form3close
    }

    $handler_CancelButton_Click = {
        &$handler_form3close
    }

    $form3 = New-Object System.Windows.Forms.Form

    $form3.Text = "Select STIG(s)"
    $form3.Name = "form3"
    $form3.SuspendLayout()

    $form3.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
    $form3.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

    $STIGExcludeList = New-Object System.Windows.Forms.CheckedListBox

    $OKButton = New-Object System.Windows.Forms.Button
    $CancelButton = New-Object System.Windows.Forms.Button

    $form3.FormBorderStyle = "FixedDialog"
    $form3.StartPosition = "CenterParent"
    $form3.DataBindings.DefaultDataSourceUpdateMode = 0
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1200
    $System_Drawing_Size.Height = 650
    $form3.ClientSize = $System_Drawing_Size

    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1280
    $System_Drawing_Size.Height = 600
    $STIGExcludeList.Size = $System_Drawing_Size
    $STIGExcludeList.Font = $BoxFont
    $STIGExcludeList.Name = "STIGExcludeList"
    $STIGExcludeList.MultiColumn = $true
    $STIGExcludeList.CheckOnClick = $true
    $STIGExcludeList.ColumnWidth = 400
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 10
    $System_Drawing_Point.Y = 10
    $STIGExcludeList.Location = $System_Drawing_Point
    $form3.Controls.Add($STIGExcludeList)

    $OKButton.Name = "OKButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $OKButton.Size = $System_Drawing_Size
    $OKButton.UseVisualStyleBackColor = $True
    $OKButton.Text = "OK"
    $OKButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 495
    $System_Drawing_Point.Y = 600
    $OKButton.Location = $System_Drawing_Point
    $OKButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $OKButton.add_Click($handler_OKButton_Click)
    $form3.Controls.Add($OKButton)

    $CancelButton.Name = "CancelButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $CancelButton.Size = $System_Drawing_Size
    $CancelButton.UseVisualStyleBackColor = $True
    $CancelButton.Text = "Cancel"
    $CancelButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 605
    $System_Drawing_Point.Y = 600
    $CancelButton.Location = $System_Drawing_Point
    $CancelButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $CancelButton.add_Click($handler_CancelButton_Click)
    $form3.Controls.Add($CancelButton)

    $STIGListXML = Join-Path -Path $ESFolder -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
    $STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object ShortName -Unique
    ForEach ($STIG in $STIGs) {
        $STIGExcludeList.Items.Add($STIG.Shortname)
    }

    $ExcludedSTIGS | ForEach-Object {
        if ($STIGExcludeList.Items -contains $_) {
            $index = ($STIGExcludeList.Items).ToLower().Indexof($_.ToLower())
            if ($index -le ($STIGExcludeList.Items | Measure-Object).count){
                $STIGExcludeList.SetItemChecked($index, $true)
            }
        }
    }

    $form3.Add_FormClosed($handler_form3close)

    $null = $form3.ShowDialog()
}

$handler_ForceSTIGButton_Click = {

    $handler_form4close =
    {
        1..3 | ForEach-Object { [GC]::Collect() }

        $form4.Dispose()
        &$handler_PreviewESButton_Click
    }

    $handler_OKButton_Click = {
        $Script:ForcedSTIGS = $STIGForceList.Items | Where-Object { $STIGForceList.CheckedItems -contains $_ }
        &$handler_form4close
    }

    $handler_CancelButton_Click = {
        &$handler_form4close
    }

    $form4 = New-Object System.Windows.Forms.Form

    $form4.Text = "Force STIG(s)"
    $form4.Name = "form4"
    $form4.SuspendLayout()

    $form4.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
    $form4.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

    $STIGForceList = New-Object System.Windows.Forms.CheckedListBox

    $OKButton = New-Object System.Windows.Forms.Button
    $CancelButton = New-Object System.Windows.Forms.Button

    $form4.FormBorderStyle = "FixedDialog"
    $form4.StartPosition = "CenterParent"
    $form4.DataBindings.DefaultDataSourceUpdateMode = 0
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1200
    $System_Drawing_Size.Height = 650
    $form4.ClientSize = $System_Drawing_Size

    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 1280
    $System_Drawing_Size.Height = 600
    $STIGForceList.Size = $System_Drawing_Size
    $STIGForceList.Font = $BoxFont
    $STIGForceList.Name = "STIGForceList"
    $STIGForceList.MultiColumn = $true
    $STIGForceList.CheckOnClick = $true
    $STIGForceList.ColumnWidth = 400
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 10
    $System_Drawing_Point.Y = 10
    $STIGForceList.Location = $System_Drawing_Point
    $form4.Controls.Add($STIGForceList)

    $OKButton.Name = "OKButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $OKButton.Size = $System_Drawing_Size
    $OKButton.UseVisualStyleBackColor = $True
    $OKButton.Text = "OK"
    $OKButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 495
    $System_Drawing_Point.Y = 600
    $OKButton.Location = $System_Drawing_Point
    $OKButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $OKButton.add_Click($handler_OKButton_Click)
    $form4.Controls.Add($OKButton)

    $CancelButton.Name = "CancelButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 50
    $CancelButton.Size = $System_Drawing_Size
    $CancelButton.UseVisualStyleBackColor = $True
    $CancelButton.Text = "Cancel"
    $CancelButton.Font = $BoxFont
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 605
    $System_Drawing_Point.Y = 600
    $CancelButton.Location = $System_Drawing_Point
    $CancelButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $CancelButton.add_Click($handler_CancelButton_Click)
    $form4.Controls.Add($CancelButton)

    $STIGListXML = Join-Path -Path $ESFolder -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
    $STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object ShortName -Unique
    ForEach ($STIG in $STIGs) {
        $STIGForceList.Items.Add($STIG.Shortname)
    }

    $ForcedSTIGS | ForEach-Object {
        if ($STIGForceList.Items -contains $_) {
            $index = ($STIGForceList.Items).ToLower().Indexof($_.ToLower())
            if ($index -le ($STIGForceList.Items | Measure-Object).count){
                $STIGForceList.SetItemChecked($index, $true)
            }
        }
    }

    $form4.Add_FormClosed($handler_form4close)

    $null = $form4.ShowDialog()
}

$handler_formclose =
{
    1..3 | ForEach-Object { [GC]::Collect() }

    $form1.Dispose()
}

#----------------------------------------------
#region Generated Form Code
#----------------------------------------------

$form1.Text = "Manage Evaluate-STIG"
$form1.Name = "form1"
$ManageESVerson = "1.0"
$form1.SuspendLayout()

$form1.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
$form1.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

$form1.FormBorderStyle = "FixedDialog"
$form1.StartPosition = "CenterScreen"
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1750
$System_Drawing_Size.Height = 800
$form1.ClientSize = $System_Drawing_Size

$Title.Text = "Manage Evaluate-STIG"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1750
$System_Drawing_Size.Height = 55
$Title.Size = $System_Drawing_Size
$Title.Font = $TitleFont
$Title.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 5
$Title.Location = $System_Drawing_Point
$form1.Controls.Add($Title)

$ToolsLabel.Text = "Evaluate-STIG Tools"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 400
$System_Drawing_Size.Height = 40
$ToolsLabel.Size = $System_Drawing_Size
$ToolsLabel.Font = $BodyFont
$ToolsLabel.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 30
$System_Drawing_Point.Y = 70
$ToolsLabel.Location = $System_Drawing_Point
$form1.Controls.Add($ToolsLabel)

$OptionsLabel.Text = "Evaluate-STIG Options"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1140
$System_Drawing_Size.Height = 40
$OptionsLabel.Size = $System_Drawing_Size
$OptionsLabel.Font = $BodyFont
$OptionsLabel.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 70
$OptionsLabel.Location = $System_Drawing_Point
$form1.Controls.Add($OptionsLabel)

$OutputLabel.Text = "Output Options"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 250
$System_Drawing_Size.Height = 40
$OutputLabel.Size = $System_Drawing_Size
$OutputLabel.Font = $BodyFont
$OutputLabel.TextAlign = "TopCenter"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 295
$OutputLabel.Location = $System_Drawing_Point
$form1.Controls.Add($OutputLabel)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1730
$System_Drawing_Size.Height = 150
$ESDataBox.Size = $System_Drawing_Size
$ESDataBox.Name = "ESDataBox"
$ESDataBox.Font = $BoxFont
$ESDataBox.ReadOnly = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 10
$System_Drawing_Point.Y = 625
$ESDataBox.Location = $System_Drawing_Point
$form1.Controls.Add($ESDataBox)

$ListSupportedProductsButton.Name = "ListSupportedProductsButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 350
$System_Drawing_Size.Height = 30
$ListSupportedProductsButton.Size = $System_Drawing_Size
$ListSupportedProductsButton.UseVisualStyleBackColor = $True
$ListSupportedProductsButton.Text = "List Supported Products"
$ListSupportedProductsButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 55
$System_Drawing_Point.Y = 125
$ListSupportedProductsButton.Location = $System_Drawing_Point
$ListSupportedProductsButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ListSupportedProductsButton.add_Click($handler_ListSupportedProductsButton_Click)
$form1.Controls.Add($ListSupportedProductsButton)

$ListApplicableProductsButton.Name = "ListApplicableProductsButton"
$ListApplicableProductsButton.Size = $System_Drawing_Size
$ListApplicableProductsButton.UseVisualStyleBackColor = $True
$ListApplicableProductsButton.Text = "List Applicable Products"
$ListApplicableProductsButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 55
$System_Drawing_Point.Y = 165
$ListApplicableProductsButton.Location = $System_Drawing_Point
$ListApplicableProductsButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ListApplicableProductsButton.add_Click($handler_ListApplicableProductsButton_Click)
$form1.Controls.Add($ListApplicableProductsButton)

$UpdateESButton.Name = "UpdateESButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 350
$System_Drawing_Size.Height = 30
$UpdateESButton.Size = $System_Drawing_Size
$UpdateESButton.UseVisualStyleBackColor = $True
$UpdateESButton.Text = "Update Evaluate-STIG"
$UpdateESButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 55
$System_Drawing_Point.Y = 205
$UpdateESButton.Location = $System_Drawing_Point
$UpdateESButton.DataBindings.DefaultDataSourceUpdateMode = 0
$UpdateESButton.add_Click($handler_UpdateESButton_Click)
$form1.Controls.Add($UpdateESButton)

$GetHelpButton.Name = "GetHelp"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 350
$System_Drawing_Size.Height = 30
$GetHelpButton.Size = $System_Drawing_Size
$GetHelpButton.UseVisualStyleBackColor = $True
$GetHelpButton.Text = "Get Evaluate-STIG Help"
$GetHelpButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 55
$System_Drawing_Point.Y = 285
$GetHelpButton.Location = $System_Drawing_Point
$GetHelpButton.DataBindings.DefaultDataSourceUpdateMode = 0
$GetHelpButton.add_Click($handler_GetHelpButton_Click)
$form1.Controls.Add($GetHelpButton)

$ContactUsButton.Name = "ContactUs"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 350
$System_Drawing_Size.Height = 30
$ContactUsButton.Size = $System_Drawing_Size
$ContactUsButton.UseVisualStyleBackColor = $True
$ContactUsButton.Text = "Contact Us"
$ContactUsButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 55
$System_Drawing_Point.Y = 325
$ContactUsButton.Location = $System_Drawing_Point
$ContactUsButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ContactUsButton.add_Click($handler_ContactUsButton_Click)
$form1.Controls.Add($ContactUsButton)

$PreviewESButton.Name = "PreviewESButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 150
$System_Drawing_Size.Height = 50
$PreviewESButton.Size = $System_Drawing_Size
$PreviewESButton.UseVisualStyleBackColor = $True
$PreviewESButton.Text = "Preview"
$PreviewESButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 10
$System_Drawing_Point.Y = 385
$PreviewESButton.Location = $System_Drawing_Point
$PreviewESButton.DataBindings.DefaultDataSourceUpdateMode = 0
$PreviewESButton.add_Click($handler_PreviewESButton_Click)
$form1.Controls.Add($PreviewESButton)

$ExecuteESButton.Name = "ExecuteESButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 150
$System_Drawing_Size.Height = 50
$ExecuteESButton.Size = $System_Drawing_Size
$ExecuteESButton.UseVisualStyleBackColor = $True
$ExecuteESButton.Text = "Execute"
$ExecuteESButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 160
$System_Drawing_Point.Y = 385
$ExecuteESButton.Location = $System_Drawing_Point
$ExecuteESButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ExecuteESButton.add_Click($handler_ExecuteESButton_Click)
$form1.Controls.Add($ExecuteESButton)

$ResetESButton.Name = "ResetESButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 150
$System_Drawing_Size.Height = 50
$ResetESButton.Size = $System_Drawing_Size
$ResetESButton.UseVisualStyleBackColor = $True
$ResetESButton.Text = "Reset"
$ResetESButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 310
$System_Drawing_Point.Y = 385
$ResetESButton.Location = $System_Drawing_Point
$ResetESButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ResetESButton.add_Click($handler_ResetESButton_Click)
$form1.Controls.Add($ResetESButton)

$SelectSTIGButton.Name = "SelectSTIGButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$SelectSTIGButton.Size = $System_Drawing_Size
$SelectSTIGButton.UseVisualStyleBackColor = $True
$SelectSTIGButton.Text = "Select STIG(s)"
$SelectSTIGButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 130
$SelectSTIGButton.Location = $System_Drawing_Point
$SelectSTIGButton.DataBindings.DefaultDataSourceUpdateMode = 0
$SelectSTIGButton.add_Click($handler_SelectSTIGButton_Click)
$form1.Controls.Add($SelectSTIGButton)

$SelectVulnButton.Name = "SelectVulnButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 270
$System_Drawing_Size.Height = 50
$SelectVulnButton.Size = $System_Drawing_Size
$SelectVulnButton.UseVisualStyleBackColor = $True
$SelectVulnButton.Text = "Select Vuln(s)"
$SelectVulnButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 190
$SelectVulnButton.Location = $System_Drawing_Point
$SelectVulnButton.DataBindings.DefaultDataSourceUpdateMode = 0
$SelectVulnButton.add_Click($handler_SelectVulnButton_Click)
$form1.Controls.Add($SelectVulnButton)

$ExcludeSTIGButton.Name = "ExcludeSTIGButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$ExcludeSTIGButton.Size = $System_Drawing_Size
$ExcludeSTIGButton.UseVisualStyleBackColor = $True
$ExcludeSTIGButton.Text = "Exclude STIG(s)"
$ExcludeSTIGButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1380
$System_Drawing_Point.Y = 130
$ExcludeSTIGButton.Location = $System_Drawing_Point
$ExcludeSTIGButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ExcludeSTIGButton.add_Click($handler_ExcludeSTIGButton_Click)
$form1.Controls.Add($ExcludeSTIGButton)

$ExcludeVulnButton.Name = "ExcludeVulnButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 270
$System_Drawing_Size.Height = 50
$ExcludeVulnButton.Size = $System_Drawing_Size
$ExcludeVulnButton.UseVisualStyleBackColor = $True
$ExcludeVulnButton.Text = "Exclude Vuln(s)"
$ExcludeVulnButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1470
$System_Drawing_Point.Y = 190
$ExcludeVulnButton.Location = $System_Drawing_Point
$ExcludeVulnButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ExcludeVulnButton.add_Click($handler_ExcludeVulnButton_Click)
$form1.Controls.Add($ExcludeVulnButton)

$ForceSTIGButton.Name = "ForceSTIGButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$ForceSTIGButton.Size = $System_Drawing_Size
$ForceSTIGButton.UseVisualStyleBackColor = $True
$ForceSTIGButton.Text = "Force STIG(s)"
$ForceSTIGButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1560
$System_Drawing_Point.Y = 130
$ForceSTIGButton.Location = $System_Drawing_Point
$ForceSTIGButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ForceSTIGButton.add_Click($handler_ForceSTIGButton_Click)
$form1.Controls.Add($ForceSTIGButton)

$OutputPathButton.Name = "OutputPathButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$OutputPathButton.Size = $System_Drawing_Size
$OutputPathButton.UseVisualStyleBackColor = $True
$OutputPathButton.Text = "Select OutputPath"
$OutputPathButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 250
$OutputPathButton.Location = $System_Drawing_Point
$OutputPathButton.DataBindings.DefaultDataSourceUpdateMode = 0
$OutputPathButton.add_Click($handler_OutputPathButton_Click)
$form1.Controls.Add($OutputPathButton)

$AFPathButton.Name = "AFPathButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$AFPathButton.Size = $System_Drawing_Size
$AFPathButton.UseVisualStyleBackColor = $True
$AFPathButton.Text = "Select AFPath"
$AFPathButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1380
$System_Drawing_Point.Y = 250
$AFPathButton.Location = $System_Drawing_Point
$AFPathButton.DataBindings.DefaultDataSourceUpdateMode = 0
$AFPathButton.add_Click($handler_AFPathButton_Click)
$form1.Controls.Add($AFPathButton)

$ComputerNameButton.Name = "ComputerNameButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 50
$ComputerNameButton.Size = $System_Drawing_Size
$ComputerNameButton.UseVisualStyleBackColor = $True
$ComputerNameButton.Text = "Input Computer(s)"
$ComputerNameButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1560
$System_Drawing_Point.Y = 250
$ComputerNameButton.Location = $System_Drawing_Point
$ComputerNameButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ComputerNameButton.add_Click($handler_ComputerNameButton_Click)
$form1.Controls.Add($ComputerNameButton)

$ComputerListButton.Name = "ComputerListButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 540
$System_Drawing_Size.Height = 50
$ComputerListButton.Size = $System_Drawing_Size
$ComputerListButton.UseVisualStyleBackColor = $True
$ComputerListButton.Text = "Select Computer List File(s)"
$ComputerListButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 320
$ComputerListButton.Location = $System_Drawing_Point
$ComputerListButton.DataBindings.DefaultDataSourceUpdateMode = 0
$ComputerListButton.add_Click($handler_ComputerListButton_Click)
$form1.Controls.Add($ComputerListButton)

$CiscoFilesButton.Name = "CiscoFilesButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 540
$System_Drawing_Size.Height = 50
$CiscoFilesButton.Size = $System_Drawing_Size
$CiscoFilesButton.UseVisualStyleBackColor = $True
$CiscoFilesButton.Text = "Select Cisco File(s)"
$CiscoFilesButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 380
$CiscoFilesButton.Location = $System_Drawing_Point
$CiscoFilesButton.DataBindings.DefaultDataSourceUpdateMode = 0
$CiscoFilesButton.add_Click($handler_CiscoFilesButton_Click)
$form1.Controls.Add($CiscoFilesButton)

$CiscoDirectoryButton.Name = "CiscoDirectoryButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 540
$System_Drawing_Size.Height = 50
$CiscoDirectoryButton.Size = $System_Drawing_Size
$CiscoDirectoryButton.UseVisualStyleBackColor = $True
$CiscoDirectoryButton.Text = "Select Cisco Directory"
$CiscoDirectoryButton.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1200
$System_Drawing_Point.Y = 440
$CiscoDirectoryButton.Location = $System_Drawing_Point
$CiscoDirectoryButton.DataBindings.DefaultDataSourceUpdateMode = 0
$CiscoDirectoryButton.add_Click($handler_CiscoDirectoryButton_Click)
$form1.Controls.Add($CiscoDirectoryButton)

$UpdateProxy.Name = "UpdateProxy"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 200
$System_Drawing_Size.Height = 50
$UpdateProxy.Size = $System_Drawing_Size
$UpdateProxy.Text = "Use Proxy"
$UpdateProxy.Font = $BoxFont
$UpdateProxy.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 260
$System_Drawing_Point.Y = 235
$UpdateProxy.Location = $System_Drawing_Point
$UpdateProxy.UseVisualStyleBackColor = $True
$form1.Controls.Add($UpdateProxy)
$UpdateProxy.Add_CheckStateChanged({if ($UpdateProxy.Checked -eq $true){$UpdateLocSource.Checked = $false}})

$UpdateLocSource.Name = "UpdateLocSource"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 200
$System_Drawing_Size.Height = 50
$UpdateLocSource.Size = $System_Drawing_Size
$UpdateLocSource.Text = "Use LocalSource"
$UpdateLocSource.Font = $BoxFont
$UpdateLocSource.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 80
$System_Drawing_Point.Y = 235
$UpdateLocSource.Location = $System_Drawing_Point
$UpdateLocSource.UseVisualStyleBackColor = $True
$form1.Controls.Add($UpdateLocSource)
$UpdateLocSource.Add_CheckStateChanged({if ($UpdateLocSource.Checked -eq $true){$UpdateProxy.Checked = $false}})

$AltCredential.Name = "AltCredential"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 260
$System_Drawing_Size.Height = 30
$AltCredential.Size = $System_Drawing_Size
$AltCredential.Text = " AltCredential"
$AltCredential.Font = $BoldBoxFont
$AltCredential.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 130
$AltCredential.Location = $System_Drawing_Point
$AltCredential.UseVisualStyleBackColor = $True
$form1.Controls.Add($AltCredential)
$AltCredential.Add_CheckStateChanged({& $handler_PreviewESButton_Click})

$ApplyTattoo.Name = "ApplyTattoo"
$ApplyTattoo.Size = $System_Drawing_Size
$ApplyTattoo.Text = " ApplyTattoo"
$ApplyTattoo.Font = $BoldBoxFont
$ApplyTattoo.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 160
$ApplyTattoo.Location = $System_Drawing_Point
$ApplyTattoo.UseVisualStyleBackColor = $True
$form1.Controls.Add($ApplyTattoo)
$ApplyTattoo.Add_CheckStateChanged({& $handler_PreviewESButton_Click})

$AllowDeprecated.Name = "AllowDeprecated"
$AllowDeprecated.Size = $System_Drawing_Size
$AllowDeprecated.Text = " AllowDeprecated"
$AllowDeprecated.Font = $BoldBoxFont
$AllowDeprecated.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 190
$AllowDeprecated.Location = $System_Drawing_Point
$AllowDeprecated.UseVisualStyleBackColor = $True
$form1.Controls.Add($AllowDeprecated)
$AllowDeprecated.Add_CheckStateChanged({& $handler_PreviewESButton_Click})

$AllowSeverityOverride.Name = "AllowSeverityOverride"
$AllowSeverityOverride.Size = $System_Drawing_Size
$AllowSeverityOverride.Text = " AllowSeverityOverride"
$AllowSeverityOverride.Font = $BoldBoxFont
$AllowSeverityOverride.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 220
$AllowSeverityOverride.Location = $System_Drawing_Point
$AllowSeverityOverride.UseVisualStyleBackColor = $True
$form1.Controls.Add($AllowSeverityOverride)
$AllowSeverityOverride.Add_CheckStateChanged({& $handler_PreviewESButton_Click})

$AllowIntegrityViolations.Name = "AllowIntegrityViolations"
$AllowIntegrityViolations.Size = $System_Drawing_Size
$AllowIntegrityViolations.Text = " AllowIntegrityViolations"
$AllowIntegrityViolations.Font = $AIVBoldBoxFont
$AllowIntegrityViolations.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 250
$AllowIntegrityViolations.Location = $System_Drawing_Point
$AllowIntegrityViolations.UseVisualStyleBackColor = $True
$form1.Controls.Add($AllowIntegrityViolations)
$AllowIntegrityViolations.Add_CheckStateChanged({& $handler_PreviewESButton_Click})

$VulnTimeoutLabel.Text = "VulnTimeout"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 190
$System_Drawing_Size.Height = 30
$VulnTimeoutLabel.Size = $System_Drawing_Size
$VulnTimeoutLabel.Font = $BoldBoxFont
$VulnTimeoutLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 130
$VulnTimeoutLabel.Location = $System_Drawing_Point
$form1.Controls.Add($VulnTimeoutLabel)

$FileSearchTimeoutLabel.Text = "FileSearchTimeout"
$FileSearchTimeoutLabel.Size = $System_Drawing_Size
$FileSearchTimeoutLabel.Font = $BoldBoxFont
$FileSearchTimeoutLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 160
$FileSearchTimeoutLabel.Location = $System_Drawing_Point
$form1.Controls.Add($FileSearchTimeoutLabel)

$PreviousToKeepLabel.Text = "PreviousToKeep"
$PreviousToKeepLabel.Size = $System_Drawing_Size
$PreviousToKeepLabel.Font = $BoldBoxFont
$PreviousToKeepLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 190
$PreviousToKeepLabel.Location = $System_Drawing_Point
$form1.Controls.Add($PreviousToKeepLabel)

$ThrottleLimitLabel.Text = "ThrottleLimit"
$ThrottleLimitLabel.Size = $System_Drawing_Size
$ThrottleLimitLabel.Font = $BoldBoxFont
$ThrottleLimitLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 220
$ThrottleLimitLabel.Location = $System_Drawing_Point
$form1.Controls.Add($ThrottleLimitLabel)

$MarkingLabel.Text = "Marking"
$MarkingLabel.Size = $System_Drawing_Size
$MarkingLabel.Font = $BoldBoxFont
$MarkingLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 250
$MarkingLabel.Location = $System_Drawing_Point
$form1.Controls.Add($MarkingLabel)

$TargetCommentsLabel.Text = "TargetComments"
$TargetCommentsLabel.Size = $System_Drawing_Size
$TargetCommentsLabel.Font = $BoldBoxFont
$TargetCommentsLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 280
$TargetCommentsLabel.Location = $System_Drawing_Point
$form1.Controls.Add($TargetCommentsLabel)

$VulnTimeoutBox.Name = "VulnTimeoutBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 150
$System_Drawing_Size.Height = 30
$VulnTimeoutBox.Size = $System_Drawing_Size
$VulnTimeoutBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1020
$System_Drawing_Point.Y = 130
$VulnTimeoutBox.Location = $System_Drawing_Point
$form1.Controls.Add($VulnTimeoutBox)
$VulnTimeoutBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$FileSearchTimeoutBox.Name = "FileSearchTimeoutBox"
$FileSearchTimeoutBox.Size = $System_Drawing_Size
$FileSearchTimeoutBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1020
$System_Drawing_Point.Y = 160
$FileSearchTimeoutBox.Location = $System_Drawing_Point
$form1.Controls.Add($FileSearchTimeoutBox)
$FileSearchTimeoutBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$PreviousToKeepBox.Name = "PreviousToKeepBox"
$PreviousToKeepBox.Size = $System_Drawing_Size
$PreviousToKeepBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1020
$System_Drawing_Point.Y = 190
$PreviousToKeepBox.Location = $System_Drawing_Point
$form1.Controls.Add($PreviousToKeepBox)
$PreviousToKeepBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$ThrottleLimitBox.Name = "ThrottleLimitBox"
$ThrottleLimitBox.Size = $System_Drawing_Size
$ThrottleLimitBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1020
$System_Drawing_Point.Y = 220
$ThrottleLimitBox.Location = $System_Drawing_Point
$form1.Controls.Add($ThrottleLimitBox)
$ThrottleLimitBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$MarkingBox.Name = "MarkingBox"
$MarkingBox.Size = $System_Drawing_Size
$MarkingBox.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1020
$System_Drawing_Point.Y = 250
$MarkingBox.Location = $System_Drawing_Point
$form1.Controls.Add($MarkingBox)
$MarkingBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$TargetCommentsBox.Name = "TargetCommentsBox"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 200
$System_Drawing_Size.Height = 60
$TargetCommentsBox.Size = $System_Drawing_Size
$TargetCommentsBox.Font = $BoxFont
$TargetCommentsBox.Multiline = $true
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 280
$TargetCommentsBox.Location = $System_Drawing_Point
$form1.Controls.Add($TargetCommentsBox)
$TargetCommentsBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$ScanTypeLabel.Text = "ScanType"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 175
$System_Drawing_Size.Height = 30
$ScanTypeLabel.Size = $System_Drawing_Size
$ScanTypeLabel.Font = $BoldBoxFont
$ScanTypeLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 340
$ScanTypeLabel.Location = $System_Drawing_Point
$form1.Controls.Add($ScanTypeLabel)

$AFKeysLabel.Text = "AF Keys"
$AFKeysLabel.Size = $System_Drawing_Size
$AFKeysLabel.Font = $BoldBoxFont
$AFKeysLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 370
$AFKeysLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFKeysLabel)

$SMKeysLabel.Text = "SM Collection"
$SMKeysLabel.Size = $System_Drawing_Size
$SMKeysLabel.Font = $BoldBoxFont
$SMKeysLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 400
$SMKeysLabel.Location = $System_Drawing_Point
$form1.Controls.Add($SMKeysLabel)

$SMPassphraseLabel.Text = "SM Passphrase"
$SMPassphraseLabel.Size = $System_Drawing_Size
$SMPassphraseLabel.Font = $BoldBoxFont
$SMPassphraseLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 430
$SMPassphraseLabel.Location = $System_Drawing_Point
$form1.Controls.Add($SMPassphraseLabel)

$SplunkKeysLabel.Text = "Splunk HECName"
$SplunkKeysLabel.Size = $System_Drawing_Size
$SplunkKeysLabel.Font = $BoldBoxFont
$SplunkKeysLabel.TextAlign = "TopLeft"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 780
$System_Drawing_Point.Y = 460
$SplunkKeysLabel.Location = $System_Drawing_Point
$form1.Controls.Add($SplunkKeysLabel)

$STIGManager.Name = "STIGManager"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 160
$System_Drawing_Size.Height = 20
$STIGManager.Size = $System_Drawing_Size
$STIGManager.Text = " STIGManager"
$STIGManager.Font = $BoldBoxFont
$STIGManager.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 460
$STIGManager.Location = $System_Drawing_Point
$STIGManager.UseVisualStyleBackColor = $True
$form1.Controls.Add($STIGManager)
$STIGManager.Add_CheckStateChanged({if($STIGManager.Checked){
                                        $AllSMKeys = $Preferences.Preferences.STIGManager.SMImport_COLLECTION.Name
                                        $AllSMKeys | ForEach-Object { $null = $SMKeys.Items.Add($_) }
                                        $SMKeys.SelectedItem = $Preferences.Preferences.EvaluateSTIG.SMCOLLECTION
                                        $SMKeys.Enabled = $True
                                    }
                                    else{
                                        $SMKeys.Enabled = $False; $SMKeys | ForEach-Object {$_.Items.Clear()}
                                        $SMPassphraseBox.Enabled = $false
                                    }
                                & $handler_PreviewESButton_Click})

$Splunk.Name = "Splunk"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 20
$Splunk.Size = $System_Drawing_Size
$Splunk.Text = " Splunk"
$Splunk.Font = $BoldBoxFont
$Splunk.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 485
$Splunk.Location = $System_Drawing_Point
$Splunk.UseVisualStyleBackColor = $True
$form1.Controls.Add($Splunk)
$Splunk.Add_CheckStateChanged({if($Splunk.Checked){
                                        $AllSplunkKeys = $Preferences.Preferences.Splunk.Splunk_HECName.Name
                                        $AllSplunkKeys | ForEach-Object { $null = $SplunkKeys.Items.Add($_) }
                                        $SplunkKeys.SelectedItem = $Preferences.Preferences.EvaluateSTIG.Splunk_HECName
                                        $SplunkKeys.Enabled = $True
                                    }
                                    else{
                                        $SplunkKeys.Enabled = $False; $SplunkKeys | ForEach-Object {$_.Items.Clear()}
                                    }
                                    & $handler_PreviewESButton_Click})

$CombinedCKL.Name = "CombinedCKL"
$CombinedCKL.Size = $System_Drawing_Size
$CombinedCKL.Text = " CombinedCKL"
$CombinedCKL.Font = $BoldBoxFont
$CombinedCKL.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 590
$System_Drawing_Point.Y = 335
$CombinedCKL.Location = $System_Drawing_Point
$CombinedCKL.UseVisualStyleBackColor = $True
$form1.Controls.Add($CombinedCKL)
$CombinedCKL.Add_CheckStateChanged({Get-OutputPath})

$CombinedCKLB.Name = "CombinedCKLB"
$CombinedCKLB.Size = $System_Drawing_Size
$CombinedCKLB.Text = " CombinedCKLB"
$CombinedCKLB.Font = $BoldBoxFont
$CombinedCKLB.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 590
$System_Drawing_Point.Y = 360
$CombinedCKLB.Location = $System_Drawing_Point
$CombinedCKLB.UseVisualStyleBackColor = $True
$form1.Controls.Add($CombinedCKLB)
$CombinedCKLB.Add_CheckStateChanged({Get-OutputPath})

$CombinedCSV.Name = "CombinedCSV"
$CombinedCSV.Size = $System_Drawing_Size
$CombinedCSV.Text = " CombinedCSV"
$CombinedCSV.Font = $BoldBoxFont
$CombinedCSV.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 590
$System_Drawing_Point.Y = 385
$CombinedCSV.Location = $System_Drawing_Point
$CombinedCSV.UseVisualStyleBackColor = $True
$form1.Controls.Add($CombinedCSV)
$CombinedCSV.Add_CheckStateChanged({Get-OutputPath})

$CKLOutput.Name = "CKLOutput"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 80
$System_Drawing_Size.Height = 20
$CKLOutput.Size = $System_Drawing_Size
$CKLOutput.Text = " CKL"
$CKLOutput.Font = $BoldBoxFont
$CKLOutput.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 335
$CKLOutput.Location = $System_Drawing_Point
$CKLOutput.UseVisualStyleBackColor = $True
$form1.Controls.Add($CKLOutput)
$CKLOutput.Add_CheckStateChanged({Get-OutputPath})

$CKLBOutput.Name = "CKLBOutput"
$CKLBOutput.Size = $System_Drawing_Size
$CKLBOutput.Text = " CKLB"
$CKLBOutput.Font = $BoldBoxFont
$CKLBOutput.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 360
$CKLBOutput.Location = $System_Drawing_Point
$CKLBOutput.UseVisualStyleBackColor = $True
$form1.Controls.Add($CKLBOutput)
$CKLBOutput.Add_CheckStateChanged({Get-OutputPath})

$CSVOutput.Name = "CSVOutput"
$CSVOutput.Size = $System_Drawing_Size
$CSVOutput.Text = " CSV"
$CSVOutput.Font = $BoldBoxFont
$CSVOutput.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 385
$CSVOutput.Location = $System_Drawing_Point
$CSVOutput.UseVisualStyleBackColor = $True
$form1.Controls.Add($CSVOutput)
$CSVOutput.Add_CheckStateChanged({Get-OutputPath})

$XCCDFOutput.Name = "XCCDFOutput"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 120
$System_Drawing_Size.Height = 20
$XCCDFOutput.Size = $System_Drawing_Size
$XCCDFOutput.Text = " XCCDF"
$XCCDFOutput.Font = $BoldBoxFont
$XCCDFOutput.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 410
$XCCDFOutput.Location = $System_Drawing_Point
$XCCDFOutput.UseVisualStyleBackColor = $True
$form1.Controls.Add($XCCDFOutput)
$XCCDFOutput.Add_CheckStateChanged({Get-OutputPath})

$Summary.Name = "Summary"
$Summary.Size = $System_Drawing_Size
$Summary.Text = " Summary"
$Summary.Font = $BoldBoxFont
$Summary.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 590
$System_Drawing_Point.Y = 435
$Summary.Location = $System_Drawing_Point
$Summary.UseVisualStyleBackColor = $True
$form1.Controls.Add($Summary)
$Summary.Add_CheckStateChanged({Get-OutputPath})

$OQE.Name = "OQE"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 80
$System_Drawing_Size.Height = 20
$OQE.Size = $System_Drawing_Size
$OQE.Text = " OQE"
$OQE.Font = $BoldBoxFont
$OQE.Checked = $false
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 500
$System_Drawing_Point.Y = 435
$OQE.Location = $System_Drawing_Point
$OQE.UseVisualStyleBackColor = $True
$form1.Controls.Add($OQE)
$OQE.Add_CheckStateChanged({Get-OutputPath})

$ScanType.Name = "ScanType"
$ScanType.Font = $BoxFont
$ScanType.Width = 200
$ScanType.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 340
$ScanType.Location = $System_Drawing_Point
$form1.Controls.Add($ScanType)
$ScanType.add_SelectedIndexChanged({& $handler_PreviewESButton_Click})

$AFKeys.Name = "AF Keys"
$AFKeys.Font = $BoxFont
$AFKeys.Width = 200
$AFKeys.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 370
$AFKeys.Location = $System_Drawing_Point
$form1.Controls.Add($AFKeys)
$AFKeys.add_SelectedIndexChanged({& $handler_PreviewESButton_Click})

$SMKeys.Name = "SM Collection"
$SMKeys.Font = $BoxFont
$SMKeys.Width = 200
$SMKeys.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 400
$SMKeys.Location = $System_Drawing_Point
$form1.Controls.Add($SMKeys)
$SMKeys.add_SelectedIndexChanged({$SMPassphraseBox.Enabled = $True;& $handler_PreviewESButton_Click})

$SMPassphraseBox.Name = "SM Passphrase"
$SMPassphraseBox.Size = $System_Drawing_Size
$SMPassphraseBox.Font = $BoxFont
$SMPassphraseBox.Width = 200
$SMPassphraseBox.PasswordChar = '*'
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 430
$SMPassphraseBox.Location = $System_Drawing_Point
$form1.Controls.Add($SMPassphraseBox)
$SMPassphraseBox.Add_KeyDown({if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {& $handler_PreviewESButton_Click}})

$SplunkKeys.Name = "Splunk HECName"
$SplunkKeys.Font = $BoxFont
$SplunkKeys.Width = 200
$SplunkKeys.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 970
$System_Drawing_Point.Y = 460
$SplunkKeys.Location = $System_Drawing_Point
$form1.Controls.Add($SplunkKeys)
$SplunkKeys.add_SelectedIndexChanged({& $handler_PreviewESButton_Click})

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1270
$System_Drawing_Size.Height = 30
$ESPathLabel.Size = $System_Drawing_Size
$ESPathLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 520
$ESPathLabel.Location = $System_Drawing_Point
$form1.Controls.Add($ESPathLabel)

$AFPathLabel.Size = $System_Drawing_Size
$AFPathLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 550
$AFPathLabel.Location = $System_Drawing_Point
$form1.Controls.Add($AFPathLabel)

$OutputPathLabel.Size = $System_Drawing_Size
$OutputPathLabel.Font = $BoxFont
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 580
$OutputPathLabel.Location = $System_Drawing_Point
$form1.Controls.Add($OutputPathLabel)

$VLineLeft.Text = ""
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 2
$System_Drawing_Size.Height = 450
$VLineLeft.Size = $System_Drawing_Size
$VLineLeft.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 475
$System_Drawing_Point.Y = 60
$VLineLeft.Location = $System_Drawing_Point
$form1.Controls.Add($VLineLeft)

$HLineTop.Text = ""
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1920
$System_Drawing_Size.Height = 2
$HLineTop.Size = $System_Drawing_Size
$HLineTop.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 60
$HLineTop.Location = $System_Drawing_Point
$form1.Controls.Add($HLineTop)

$HLineOptionBottom.Text = ""
$HLineOptionBottom.Size = $System_Drawing_Size
$HLineOptionBottom.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 510
$HLineOptionBottom.Location = $System_Drawing_Point
$form1.Controls.Add($HLineOptionBottom)

$HLineBottom.Text = ""
$HLineBottom.Size = $System_Drawing_Size
$HLineBottom.BorderStyle = "Fixed3D"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 775
$HLineBottom.Location = $System_Drawing_Point
$form1.Controls.Add($HLineBottom)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 860
$System_Drawing_Size.Height = 20
$BottomLine.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 5
$System_Drawing_Point.Y = 780
$BottomLine.Location = $System_Drawing_Point
$form1.Controls.Add($BottomLine)

$BottomLineVersion.Text = "v $ManageESVerson"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 50
$System_Drawing_Size.Height = 20
$BottomLineVersion.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 1700
$System_Drawing_Point.Y = 780
$BottomLineVersion.Location = $System_Drawing_Point
$form1.Controls.Add($BottomLineVersion)

$form1.ResumeLayout()

#Init the OnLoad event to correct the initial state of the form
$InitialFormWindowState = $form1.WindowState

#Save the initial state of the form
$form1.add_Load($OnLoadForm_StateCorrection)

$form1.Add_FormClosed($handler_formclose)
#Show the Form
$null = [Windows.Forms.Application]::Run($form1)

# SIG # Begin signature block
# MIIjzgYJKoZIhvcNAQcCoIIjvzCCI7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQrwJ5Gj7qMqnI
# D8VQgl5MOHVGPs3lK7QJEWPVxFeenKCCHe0wggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQg
# VGltZXN0YW1wIDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+
# anOf9pUhq5Ywultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5
# bUlYYSuuM4vQngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKv
# NminKQPTv/1+kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZ
# j75MU/HNmtsgtFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQ
# rxGFSKx+rDdNMsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJ
# pVIfdNsEvxHofBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk
# 3RIySho1XyHLIAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8Zh
# qcaDHOoj5KGg4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXae
# BQjIK13SlnzODdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLts
# VAxFvGqsxUA2Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0n
# VepsFk8nlcuWfyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+S
# H3agWzBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShP
# z9Pce4FLJl6reNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyj
# UkKhk3aYx7D8vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6la
# ICtKjPICYYf/qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv
# /M93748YTeoXU/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw
# 23vT6QSgwX5Pq2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4
# zvSWzVXpAb9k4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTk
# TXpFIEB06nXZrDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2L
# lTbMcqFSzm4cd0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3
# mgrlgbAW+BzikRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gx
# ftt/8wY3grcc/nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7
# aRZOwqw6pDGCBTcwggUzAgEBMGEwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNV
# BAMTDERPRCBJRCBDQS03MgIDE2HVMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQB
# gjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII9OCmUt
# IsaKg3dpYxR/Dz6PkzAGiOtZz7A9qX+Izln/MA0GCSqGSIb3DQEBAQUABIIBACxR
# myhYQ+2pWOiT1+Es8DHQ8kxrq6MaWEF6pv2jolQg3VpUFiJGqCGh8Ni35D1wR/0C
# Msko7j68yMiDHTQxIUi1kJJYA9mPNzM5Ii2U968nkRin5mO44DY2o72HwXxjjsip
# XQb/VkvG3dOk10f0z+Z7iT/dARlmGi2yummeqvmmKgif9505ZOk8l03hxMMAlDYh
# z6x50APZHKjPD99KPsbpSMyXpPyGBsiRRmcAlCLiJTmBEEa2K4EOHKbRwBDrEZ6q
# oth2ve92N2t3ajlmJs/vccTcAJ21JSzYDP/NWhLFcHIGEUkGEQA4PT+Ydkhfk/3l
# 18gonMO6WhoTwTCQwRqhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjUwNjA5MTI0NjMzWjAv
# BgkqhkiG9w0BCQQxIgQg/KtYnBUJNWu1S5H5h+fGMcva31kqJ/ST0yxnOqKQn8cw
# DQYJKoZIhvcNAQEBBQAEggIAG0BcJGJ7i79PPOH4NsI+d5jM0aSdLaT4SuG0uP1M
# heHYuWC7/4cv/PHrTAI5xHkrzVh6KIWt5KJ3klo/zMj2wr30VwZ/JxB89LPTYHg1
# 4W2Cfrqm5gOEAClyd5Y1856NSlx+dJT0/s+IUTX2jGnGnrcl1ES2qc0FNvmW/jIx
# RHosbTQCHQ5wqpz/dyON+8aZwd+5qlY3rL2fbYnU9QnhC9JME4QKtt9dUi9MI+67
# Z4UwJeFRwj1ONdj12/b54dxqpW1usXJ5eya7+1xOTMtUKDejCDwQi77dz0gNR5Zj
# ulT2YOffJM2B7jRoLPkhbEhIzk7DvEn2rhk6v/EDBg7rfosxoYSwoyrdEWQDpgMy
# YiryGH52oOqB168U1pKm6V2KBghRkHlLqigaMO6PQkWgbdiK4bFjIJqmCypAY4G9
# uFONzOFqMfRXQ+9BmA2L1+gXxrOupSyMZzf/AU4sm4dz86C+r3hffD348iyOe+bk
# fyjbO/mmzjNlZ9JjyvwCrDuYAUogpcy3zXrDUSaB81F9SHWRbqCe8oyVw16rKoua
# 4hhOosgqModJF2cjgePhv2m8+9b9UxIipsyflN1CEqNRybUhLCTWZKNqK5zMUL+x
# g+5i1xKFQY67fLgd/QduNwGMHrL732YJ+pkedjxjVCe3kDPgDHw8GPrN77EonOHA
# 2sw=
# SIG # End signature block
