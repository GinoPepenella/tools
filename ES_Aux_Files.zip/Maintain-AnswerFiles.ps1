<#
    .Synopsis
    Performs maintenance on Evaluate-STIG answer files.
    .DESCRIPTION
    Performs simple maintenance on Evaluate-STIG Answer Files.  Updates Vuln IDs to new STIGs that have been converted to DISA's new conten management system.  It also identifies and optionally removes answers for Vuln IDs that have been removed from the STIG.  Finally, it will convert answer files from previous format to new format compatible with 1.2104.3 and greater.

    Unless -NoBackup is specified, a backup of an answer file that is determined to need updating is automatically created with a .bak extension and stored in the same path as the answer file.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG'

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be noted but not changed.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -RemoveMissingVulnIDs

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -RemoveMissingVulnIDs -NoBackup

    This will analyze all answer files found in ESPath\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.  Disables backup of answer files that are updated.
    .EXAMPLE
    PS C:\> .\Maintain-AnswerFiles.ps1 -ESPath 'C:\Evaluate-STIG' -AFPath '\\Server1\AnswerFiles' -RemoveMissingVulnIDs -NoBackup

    This will analyze all answer files found in \\Server1\AnswerFiles and update Vuln IDs to new STIG Vuln IDs if required.  Answers for Vuln IDs no longer in the STIG will be omitted from the updated answer file.  Disables backup of answer files that are updated.
    .INPUTS
    -ESPath
    Path to the Evaluate-STIG directory.  This is a required parameter.

    -AFPath
    Path that contains XML answer files.  If not specified, defaults to <ESPath>\AnswerFiles.

    -NoBackup
    Disables the creation of a backup file (.bak) for answer files that are updated.

    -RemoveMissingVulnIDs
    When specified, will automatically omit any vuln IDs in the current Answer File that is not in the STIG from the new Answer File.  Useful for cleaning up answers for STIG items that have been removed.  This parameter is optional.
    .LINK
    Evaluate-STIG
    https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig
#>
[CmdletBinding(DefaultParameterSetName='None')]
Param (
    [Parameter(Mandatory=$true)]
    [String]$ESPath,

    [Parameter(Mandatory = $false)]
    [String]$AFPath,

    [Parameter(Mandatory=$false)]
    [Switch]$NoBackup,

    [Parameter(Mandatory=$false)]
    [Switch]$RemoveMissingVulnIDs
    )

Function Test-XmlValidation {
    # Based on code samples from https://stackoverflow.com/questions/822907/how-do-i-use-powershell-to-validate-xml-files-against-an-xsd

    Param (
        [Parameter(Mandatory = $true)]
        [String] $XmlFile,

        [Parameter(Mandatory = $true)]
        [String] $SchemaFile
    )

    Try {
        Get-ChildItem $XmlFile -ErrorAction Stop | Out-Null
        Get-ChildItem $SchemaFile -ErrorAction Stop | Out-Null

        $XmlErrors = New-Object System.Collections.Generic.List[System.Object]
        [Scriptblock] $ValidationEventHandler = {
            If ($_.Exception.LineNumber) {
                $Message = "$($_.Exception.Message) Line $($_.Exception.LineNumber), position $($_.Exception.LinePosition)."
            }
            Else {
                $Message = ($_.Exception.Message)
            }

            $NewObj = [PSCustomObject]@{
                Message = $Message
            }
            $XmlErrors.Add($NewObj)
        }

        $ReaderSettings = New-Object -TypeName System.Xml.XmlReaderSettings
        $ReaderSettings.ValidationType = [System.Xml.ValidationType]::Schema
        $ReaderSettings.ValidationFlags = [System.Xml.Schema.XmlSchemaValidationFlags]::ProcessIdentityConstraints -bor [System.Xml.Schema.XmlSchemaValidationFlags]::ProcessSchemaLocation -bor [System.Xml.Schema.XmlSchemaValidationFlags]::ReportValidationWarnings
        $ReaderSettings.Schemas.Add($null, $SchemaFile) | Out-Null
        $readerSettings.add_ValidationEventHandler($ValidationEventHandler)

        Try {
            $Reader = [System.Xml.XmlReader]::Create($XmlFile, $ReaderSettings)
            While ($Reader.Read()) {
            }
        }
        Catch {
            $NewObj = [PSCustomObject]@{
                Message = ($_.Exception.Message)
            }
            $XmlErrors.Add($NewObj)
        }
        Finally {
            $Reader.Close()
        }

        If ($XmlErrors) {
            Return $XmlErrors
        }
        Else {
            Return $true
        }
    }
    Catch {
        Return $_.Exception.Message
    }
}

Try {
    $ErrorActionPreference = "Stop"

    If (-Not($AFPath)) {
        $AFPath = Join-Path -Path $ESPath -ChildPath "AnswerFiles"
    }

    # Verify version of Evaluate-STIG is supported version.
    $SupportedVer = [Version]"1.2401.0"
    Get-Content (Join-Path -Path $ESPath -ChildPath "Evaluate-STIG.ps1") | ForEach-Object {
        If ($_ -like '*$EvaluateStigVersion = *') {
            $Version = [Version]((($_ -split "=")[1]).Trim() -replace '"','')
            Return
        }
    }
    If (-Not($Version -ge $SupportedVer)) {
        Throw "Error: Evaluate-STIG $SupportedVer or greater required.  Found $Version.  Please update Evaluate-STIG to a supported version before using this script."
    }

    # Validate STIGList.xml and answer file for proper schema usage.
    $STIGList_xsd = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
    $AnswerFile_xsd = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "Schema_AnswerFile.xsd"

    # STIGList.xml validation
    $XmlFile = Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
    If (-Not(Test-Path $XmlFile)) {
        Throw "Error: '$XmlFile' - file not found.  Cannot continue."
    }
    ElseIf (-Not(Test-Path $STIGList_xsd)) {
        Throw "Error: '$STIGList_xsd' - file not found.  Cannot continue."
    }
    ElseIf (-Not(Test-Path $AnswerFile_xsd)) {
        Throw "Error: '$AnswerFile_xsd' - file not found.  Cannot continue."
    }

    $Result = Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd
    If ($Result -ne $true) {
        ForEach ($Item in $Result.Message) {
            $Message += $Item | Out-String
        }
        Throw $Message
    }

    # Get list of supported STIGs
    [XML]$STIGList = Get-Content (Join-Path -Path $ESPath -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml")
    $STIGsToProcess = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($Node in $STIGList.List.ChildNodes) {
        $NewObj = [PSCustomObject]@{
            Name        = $Node.Name
            ShortName   = $Node.ShortName
            StigContent = $Node.StigContent
        }
        $STIGsToProcess.Add($NewObj)
    }

    # Get STIG AnswerFiles
    $AnswerFileList = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($Item in (Get-ChildItem -Path $AFPath | Sort-Object LastWriteTime | Where-Object Extension -eq ".xml")) {
        Try {
            $CurrentSchema = $true
            If ((Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $AnswerFile_xsd) -ne $true) {
                $CurrentSchema = $false
            }

            [XML]$Content = Get-Content $Item.FullName
            If ($Content.STIGComments.Name) {
                If (-Not(($Content.STIGComments.Name -in $STIGsToProcess.Name) -or ($Content.STIGComments.Name -in $STIGsToProcess.ShortName))) {
                    Write-Host "'$($Item.Name)' is for '$($Content.STIGComments.Name)' which is not listed in -ListSupportedProducts.  Will ignore this Answer file." -ForegroundColor Yellow
                }
                Else {
                    $StigContent = ($STIGsToProcess | Where-Object {($_.Name -eq $Content.STIGComments.Name) -or ($_.ShortName -eq $Content.STIGComments.Name)}).StigContent
                    $Template = Join-Path -Path $ESPath -ChildPath "StigContent" | Join-Path -ChildPath $StigContent
                    $NewObj = [PSCustomObject]@{
                        STIG           = $Content.STIGComments.Name
                        AnswerFile     = $Item.Name
                        AnswerFilePath = $Item.FullName
                        Template       = $Template
                        CurrentSchema  = $CurrentSchema
                    }
                    $AnswerFileList.Add($NewObj)
                }
            }
            Else {
                Write-Host "'$($Item.FullName)' is a duplicate Answer File for '$($Content.STIGComments.Name)'.  Will ignore this Answer File." -ForegroundColor Yellow
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        }
    }

    ForEach ($File in $AnswerFileList) {
        Write-Host ""
        Write-Host "Processing $($File.AnswerFilePath) ..." -ForegroundColor Gray
        $AnswerFileText = [XML](Get-Content $File.AnswerFilePath)
        $ChecklistXML = [XML](Get-Content $File.Template)
        $STIGItems = New-Object System.Collections.Generic.List[System.Object]
        $LegacyIDs = New-Object System.Collections.ArrayList
        ForEach ($Object in $ChecklistXML.Benchmark.Group) {
            If ($Object.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"}) {
                Foreach ($legacy in ($Object.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"} | Sort-Object '#text')) {
                    $null = $LegacyIDs.Add($($legacy.'#text'))
                }
            }
            $NewObj = [PSCustomObject]@{
                RuleTitle = $Object.rule.title
                LegacyVulnID = (Select-String -InputObject $LegacyIDS -Pattern "V-\d{4,}" | ForEach-Object {$_.Matches}).Value
                VulnID = $($Object.id)
                }
            $STIGItems.Add($NewObj)
            }

        $UpdateAnswerFile = $false
        ForEach ($Element in $AnswerFileText.STIGComments.Vuln) {
            If ($Element.ID -in $STIGItems.LegacyVulnID) {
                $UpdateAnswerFile = $true
                Write-Host "  Converting '$($Element.ID)' in Answer File to '$(($STIGItems | Where-Object LegacyVulnID -eq $Element.ID).VulnID)'" -ForegroundColor Gray
                $Element.ID = "$(($STIGItems | Where-Object LegacyVulnID -eq $Element.ID).VulnID)"
                If ($Element.'#comment' -ne ($STIGItems | Where-Object VulnID -eq $Element.ID).RuleTitle) {
                    $UpdateAnswerFile = $true
                    Write-Host "  Adding Rule Title as comment to '$($Element.ID)'" -ForegroundColor Gray
                }
            }
            ElseIf ($Element.ID -notin $STIGItems.VulnID) {
                If ($RemoveMissingVulnIDs) {
                    $UpdateAnswerFile = $true
                    Write-Host "  '$($Element.ID)' is not found in the STIG and has been removed from '$($File.AnswerFile)'" -ForegroundColor Yellow
                    $null = $Element.ParentNode.RemoveChild($Element)
                }
                Else {
                    Write-Host "  '$($Element.ID)' is not found in the STIG and may be removed from '$($File.AnswerFile)'" -ForegroundColor Yellow
                }
            }
            ElseIf ($Element.'#comment' -ne ($STIGItems | Where-Object VulnID -eq $Element.ID).RuleTitle) {
                $UpdateAnswerFile = $true
                If ($Element.ID -in $STIGItems.VulnID) {
                    Write-Host "  Adding Rule Title as comment to '$($Element.ID)'" -ForegroundColor Gray
                }
            }
        }
        If ($UpdateAnswerFile -eq $true -or $File.CurrentSchema -ne $true) {
            If (-Not($NoBackup)) {
                $BackupPath = Join-Path -Path $AFPath -ChildPath "Backup"
                If (-Not(Test-Path $BackupPath)) {
                    Write-Host "  Creating backup folder" -ForegroundColor Gray
                    New-Item -Path $BackupPath -ItemType Directory | Out-Null
                }
                Write-Host "  Creating copy of $($File.AnswerFile) under $($BackupPath)" -ForegroundColor Gray
                $BackupPath = Join-Path -Path $AFPath -ChildPath "Backup"
                Copy-Item $File.AnswerFilePath -Destination "$($BackupPath)\$($File.AnswerFile).bak" | Out-Null
            }

            If ($File.CurrentSchema -ne $true) {
                Write-Host "  Converting Answer File to new schema" -ForegroundColor Gray
            }

            # Write new Answer File
            $NewAnswerFile = $File.AnswerFilePath

            $Encoding = [System.Text.Encoding]::UTF8
            $XmlWriter = New-Object System.Xml.XmlTextWriter($NewAnswerFile, $Encoding)
            $XmlWriter.Formatting = "Indented"
            $XmlWriter.Indentation = 2

            $XmlWriter.WriteStartDocument()

            # Add Comment section
            $XmlWriter.WriteComment('**************************************************************************************
            This file contains answers for known opens and findings that cannot be evaluated through technical means.
            <STIGComments Name> must match the STIG ShortName or Name in -ListSupportedProducts.  When a match is found, this answer file will automatically for the STIG.
            <Vuln ID> is the STIG VulnID.  Multiple Vuln ID sections may be specified in a single Answer File.
            <AnswerKey Name> is the name of the key assigned to the answer.  "DEFAULT" can be used to apply the comment to any asset.  Multiple AnswerKey Name sections may be configured within a single Vuln ID section.
              *Note: If the Answer Key matches the hostname *exactly*, it will supersede any other key for the Vulnerability ID.  
               Multiple hostnames can be used, separated by either a space or a comma.
            <ExpectedStatus> is the initial status after the checklist is created.  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".
            <ValidationCode> must be Powershell code that returns a True/False value or a PSCustomObject.  If blank, "true" is assumed.
              *Note: If Validation Code returns a PSCustomObject, the Object MUST contain both "Results" and "Valid" keys.  "Results" will be written to the Comments field of the STIG check.
            <ValidTrueStatus> is the status the check should be set to if ValidationCode returns "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
            <ValidTrueComment> is the verbiage to add to the Comments section if ValidationCode returns "true".
            <ValidFalseStatus> is the status the check should be set to if ValidationCode DOES NOT return "true".  Valid entries are "Not_Reviewed", "Open", "NotAFinding", and "Not_Applicable".  If blank, <ExpectedStatus> is assumed.
            <ValidFalseComment> is the verbiage to add to the Comments section if ValidationCode DOES NOT return "true".
            **************************************************************************************')

            # Create STIGComments node
            $att_Name = $AnswerFileText.STIGComments.Name
            $XmlWriter.WriteStartElement("STIGComments")
            $XmlWriter.WriteAttributeString("Name", $att_Name)

            # Create Vuln nodes
            ForEach ($Vuln in $AnswerFileText.STIGComments.Vuln) {
                $att_ID = $Vuln.ID
                $XmlWriter.WriteStartElement("Vuln")
                $XmlWriter.WriteAttributeString("ID", $att_ID)
                If ($STIGItems | Where-Object VulnID -eq $Vuln.ID) {
                    $XmlWriter.WriteComment(($STIGItems | Where-Object VulnID -eq $Vuln.ID).RuleTitle)
                }
                Else {
                    $XmlWriter.WriteComment("WARNING: $($Vuln.ID) is not part of the STIG and may be removed from this answer file.")
                }

                # Create AnswerKey nodes
                ForEach ($Key in $Vuln.AnswerKey) {
                    $att_Name = $Key.Name
                    $XmlWriter.WriteStartElement("AnswerKey")
                    $XmlWriter.WriteAttributeString("Name", $att_Name)

                    #Create sub nodes
                    $XmlWriter.WriteStartElement("ExpectedStatus")
                    $XmlWriter.WriteString($Key.ExpectedStatus)
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidationCode")
                    If ($Key.ValidationCode) {
                        $XmlWriter.WriteString($Key.ValidationCode)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidTrueStatus")
                    If ($File.CurrentSchema -eq $true) {
                        If ($Key.ValidTrueStatus) {
                            $XmlWriter.WriteString($Key.ValidTrueStatus)
                        }
                        Else {
                            $XmlWriter.WriteWhitespace("")
                        }
                    }
                    Else {
                        $XmlWriter.WriteString($Key.FinalStatus)
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidTrueComment")
                    If ($File.CurrentSchema -eq $true) {
                        If ($Key.ValidTrueComment) {
                            $XmlWriter.WriteString($Key.ValidTrueComment)
                        }
                        Else {
                            $XmlWriter.WriteWhitespace("")
                        }
                    }
                    Else {
                        $XmlWriter.WriteString($Key.ApprovedComment)
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidFalseStatus")
                    If ($Key.ValidFalseStatus) {
                        $XmlWriter.WriteString($Key.ValidFalseStatus)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    $XmlWriter.WriteStartElement("ValidFalseComment")
                    If ($Key.ValidFalseComment) {
                        $XmlWriter.WriteString($Key.ValidFalseComment)
                    }
                    Else {
                        $XmlWriter.WriteWhitespace("")
                    }
                    $XmlWriter.WriteFullEndElement()

                    # Close AnswerKey node
                    $XmlWriter.WriteEndElement()
                }
                # Close Vuln node
                $XmlWriter.WriteEndElement()
            }
            $XmlWriter.WriteEndElement()

            $XmlWriter.WriteEnddocument()
            $XmlWriter.Flush()
            $XmlWriter.Close()

            Write-Host "  $($File.AnswerFile) successfully updated." -ForegroundColor DarkGreen
        }
        Else {
            Write-Host "  $($File.AnswerFile) does not require updating." -ForegroundColor Cyan
        }
    }
    Write-Host
    Write-Host "Processing complete!" -ForegroundColor Green
}
Catch {
    Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDSYpXso5FSS3p5
# zIx4zQB4cTkVaxdnafDmzczuWCtxoKCCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCDdwJ3+3w6pLERuiHPU9eBMIdp2an/3
# swbVvgk+7SUVTjANBgkqhkiG9w0BAQEFAASCAQCeZC7B0Ut0Vu5Tt+qmGuxScB2E
# tsVfp1ZFPZAHK0jyj9pWSIcxHKXBOgp/SS0kkdY3QY7zkHtanU/cmm277tmbLh4e
# uwDx+zwgmlOqRqDNqg+BSGmBIk/0mWUxiPCxYk2c1RRrE5IAKrVX/ogiBXEjxeTP
# cKyO23Pa+LKICDccvToMfZkTUm38ElyKPsD8YR1njsoJF1P7KxxThpomBthQh9nA
# 80mqQihR7EFbJjINl4nn7sV0s2XBCCvq3IMpCY6oiAOjEHKcdzKUFsH4GhxTOUb8
# 8lSNjoEHSMF+B8OU8rucWfuD4T4qippVuTlZjtoOvYYWrr2Z37SoSxDs1J71
# SIG # End signature block
