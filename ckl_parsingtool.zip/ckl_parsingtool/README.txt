Simple README for find_open_ckls.sh

What it does:
- Searches all .ckl files for a specified V-number with STATUS='Open'.
- Groups results by directory and lists matching .ckL filenames.
- After typing 'done', creates summary .txt files and copies matching .ckl files into <directory>_used folders.

How to run:
1. Install xmlstarlet (if needed):
   sudo yum install -y xmlstarlet
2. Place script (ckl_opens.sh) in the parent directory containing your subdirectories of .ckl files.
3. Make it executable:

4. Run the script:
   ./find_open_ckls.sh
5. Follow prompts:
   - Enter V-number when asked.
   - Type 'done' to generate outputs and exit.
   - Type 'exit' to quit without copying.

6. Results
   - Output of results will be in the text files it creates
   - .CKLs that were used and had an "OPEN" finding are indexed and placed in a separate directory. 

