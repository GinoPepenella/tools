#!/bin/bash

# Ensure xmlstarlet is installed
if ! command -v xmlstarlet &>/dev/null; then
    if [ -f /etc/redhat-release ]; then
        sudo yum install -y xmlstarlet &>/dev/null
    else
        echo "Please install xmlstarlet and retry."
        exit 1
    fi
fi

DIRECTORY="."
declare -A files_by_dir=()

# Truncate per‐dir summary files
for sub in "$DIRECTORY"/*/; do
    [ -d "$sub" ] || continue
    > "$(basename "$sub").txt"
done

# XPath template for matching Vuln + Open
xp="//*/VULN[STIG_DATA[VULN_ATTRIBUTE='Vuln_Num']/ATTRIBUTE_DATA='\$v' and STATUS='Open']"

while true; do
    read -p $'\nEnter V‑number (e.g. 230224 or V-230224), type done to finish, or exit to quit: ' input
    case "${input,,}" in
        exit|quit) echo "Goodbye."; exit 0;;
        done)
            echo "Summary files created:"
            for sub in "$DIRECTORY"/*/; do
                [ -d "$sub" ] || continue
                f="$(basename "$sub").txt"
                [ -s "$f" ] && echo "  $f"
            done

            echo
            echo "Copied .ckl files into:"
            for dir in "${!files_by_dir[@]}"; do
                tgt="${dir}_used"
                mkdir -p "$tgt"
                echo "  $tgt:"
                for f in ${files_by_dir[$dir]}; do
                    cp "$f" "$tgt"/
                    echo "    $(basename "$f")"
                done
            done
            exit 0
    esac

    # Normalize V‑number
    if [[ "$input" =~ ^[0-9]{6}$ ]]; then
        v="V-$input"
    elif [[ "$input" =~ ^V-[0-9]{6}$ ]]; then
        v="$input"
    else
        echo "⛔ Invalid format; expecting 6 digits, with or without 'V-'."
        echo "---------------------------------"
        continue
    fi

    declare -A files_this_lookup=()

    # Scan for open findings
    while IFS= read -r -d '' file; do
        if (( $(xmlstarlet sel -t -v "${xp//\$v/$v}" "$file" 2>/dev/null | wc -l) > 0 )); then
            dir=$(basename "$(dirname "$file")")
            # record unique files
            [[ -z "${files_this_lookup[$dir]}" ]] && files_this_lookup[$dir]=""
            if [[ ! " ${files_this_lookup[$dir]} " =~ " $file " ]]; then
                files_this_lookup[$dir]="${files_this_lookup[$dir]} $file"
            fi
            [[ -z "${files_by_dir[$dir]}" ]] && files_by_dir[$dir]=""
            if [[ ! " ${files_by_dir[$dir]} " =~ " $file " ]]; then
                files_by_dir[$dir]="${files_by_dir[$dir]} $file"
            fi
        fi
    done < <(find "$DIRECTORY" -type f -name '*.ckl' -print0)

    if [ ${#files_this_lookup[@]} -gt 0 ]; then
        for dir in "${!files_this_lookup[@]}"; do
            # determine category from first matching file
            first_file=$(echo "${files_this_lookup[$dir]}" | awk '{print $1}')
            severity=$(xmlstarlet sel -t -v "(${xp//\$v/$v})/STIG_DATA[VULN_ATTRIBUTE='Severity']/ATTRIBUTE_DATA" -n "$first_file" 2>/dev/null)
            case "${severity,,}" in
                high) catnum=1;;
                medium) catnum=2;;
                low) catnum=3;;
                *) catnum="?" ;;
            esac

            echo "$dir"
            echo "$v (CAT $catnum) :"
            for f in ${files_this_lookup[$dir]}; do
                echo "  - $(basename "$f")"
            done
            echo "---------------------------------"

            # append to summary
            {
                echo "$dir"
                echo "$v (CAT $catnum) :"
                for f in ${files_this_lookup[$dir]}; do
                    echo "  - $(basename "$f")"
                done
                echo "---------------------------------"
            } >> "${dir}.txt"
        done
    else
        echo "❌ $v not found OPEN in any .ckl under $DIRECTORY."
        echo "---------------------------------"
    fi
done

