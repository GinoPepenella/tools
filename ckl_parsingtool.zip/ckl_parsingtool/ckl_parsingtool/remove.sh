#!/bin/bash

rm -rf ./*.txt

rm -rf ./ent1_* titan_*
