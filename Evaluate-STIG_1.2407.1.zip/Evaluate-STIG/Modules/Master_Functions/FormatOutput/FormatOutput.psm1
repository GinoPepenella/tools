############################################
# File Output functions for Evaluate-STIG #
############################################

Function Format-Object {
    Param (
        [Parameter(Mandatory = $true)]
        [array]$OutputPayload,

        [Parameter(Mandatory = $true)]
        [psobject]$ScanObject,

        [Parameter(Mandatory = $false)]
        [string]$ParamList
    )

    $FileObjects = New-Object System.Collections.Generic.List[System.Object]
    if ($ParamList) {
        $ParamList = $ParamList -join ","
    }
    else {
        $ParamList = 'Title', 'Version', 'ReleaseDate', 'Classification', 'HostName', 'Site', 'Instance', 'IP', 'MAC', 'FQDN', 'Role', 'GroupID', 'RuleID', 'STIGID', 'Severity', 'SeverityOverride' , 'Justification', 'LegacyIDs', 'RuleTitle', 'Discussion', 'CheckText', 'FixText', 'CCI', 'Status', 'FindingDetails', 'Comments', 'ESVersion', 'StartTime'
    }
    $SortedOutputPayload = $OutputPayload | Sort-Object {
        $rank = $ParamList.IndexOf($_)
        if ($rank -ne -1) {
            $rank
        }
        else {
            [System.Double]::PositiveInfinity
        }
    }, Name

    Foreach ($Scan_Object in $ScanObject) {
        Foreach ($Vuln in $Scan_Object.VulnResults) {
            $FindingDetails = $Vuln.FindingDetails

            $Object = [PSCustomObject]@{}
            Switch ($SortedOutputPayload){
                "Title"            {$Object | Add-Member -MemberType NoteProperty -Name "Title" -Value $Scan_Object.STIGInfo.Title}
                "Version"          {$Object | Add-Member -MemberType NoteProperty -Name "Version" -Value "V$($Scan_Object.STIGInfo.Version)R$($Scan_Object.STIGInfo.Release)"}
                "ReleaseDate"      {$Object | Add-Member -MemberType NoteProperty -Name "ReleaseDate" -Value $Scan_Object.STIGInfo.ReleaseDate}
                "Classification"   {$Object | Add-Member -MemberType NoteProperty -Name "Classification" -Value $Scan_Object.STIGInfo.Classification}
                "HostName"         {$Object | Add-Member -MemberType NoteProperty -Name "HostName" -Value $Scan_Object.TargetData.HostName}
                "Site"             {$Object | Add-Member -MemberType NoteProperty -Name "Site" -Value $Scan_Object.TargetData.Site}
                "Instance"         {$Object | Add-Member -MemberType NoteProperty -Name "Instance" -Value $Scan_Object.TargetData.Instance}
                "IP"               {$Object | Add-Member -MemberType NoteProperty -Name "IP" -Value $Scan_Object.TargetData.IPAddress}
                "MAC"              {$Object | Add-Member -MemberType NoteProperty -Name "MAC" -Value $Scan_Object.TargetData.MacAddress}
                "FQDN"             {$Object | Add-Member -MemberType NoteProperty -Name "FQDN" -Value $Scan_Object.TargetData.FQDN}
                "Role"             {$Object | Add-Member -MemberType NoteProperty -Name "Role" -Value $Scan_Object.TargetData.Role}
                "GroupID"          {$Object | Add-Member -MemberType NoteProperty -Name "GroupID" -Value $Vuln.GroupID}
                "RuleID"           {$Object | Add-Member -MemberType NoteProperty -Name "RuleID" -Value $Vuln.RuleID}
                "STIGID"           {$Object | Add-Member -MemberType NoteProperty -Name "STIGID" -Value $Vuln.STIGID}
                "Severity"         {$Object | Add-Member -MemberType NoteProperty -Name "Severity" -Value $Vuln.Severity}
                "SeverityOverride" {$Object | Add-Member -MemberType NoteProperty -Name "SeverityOverride" -Value $Vuln.SeverityOverride}
                "Justification"    {$Object | Add-Member -MemberType NoteProperty -Name "Justification" -Value $Vuln.Justification}
                "LegacyIDs"        {$Object | Add-Member -MemberType NoteProperty -Name "LegacyIDs" -Value $($Vuln.LegacyIDs -join '; ')}
                "RuleTitle"        {$Object | Add-Member -MemberType NoteProperty -Name "RuleTitle" -Value $Vuln.RuleTitle}
                "Discussion"       {$Object | Add-Member -MemberType NoteProperty -Name "Discussion" -Value $Vuln.Discussion}
                "CheckText"        {$Object | Add-Member -MemberType NoteProperty -Name "CheckText" -Value $Vuln.CheckText}
                "FixText"          {$Object | Add-Member -MemberType NoteProperty -Name "FixText" -Value $Vuln.FixText}
                "CCI"              {$Object | Add-Member -MemberType NoteProperty -Name "CCI" -Value $($Vuln.CCI -join '; ')}
                "Status"           {$Object | Add-Member -MemberType NoteProperty -Name "Status" -Value $Vuln.Status}
                "FindingDetails"   {$Object | Add-Member -MemberType NoteProperty -Name "FindingDetails" -Value $FindingDetails}
                "Comments"         {$Object | Add-Member -MemberType NoteProperty -Name "Comments" -Value $Vuln.Comments}
                "ESVersion"        {$Object | Add-Member -MemberType NoteProperty -Name "ESVersion" -Value $Scan_Object.ESData.ESVersion}
                "StartTime"        {$Object | Add-Member -MemberType NoteProperty -Name "StartTime" -Value $Scan_Object.ESData.StartTime}
            }
            $FileObjects.Add($Object)
        }
    }

    Return $FileObjects
}

Function Format-BaseFileName {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$Hostname,

        [Parameter(Mandatory = $true)]
        [String]$STIGShortName,

        [Parameter(Mandatory = $false)]
        [String]$SiteOrInstance,

        [Parameter(Mandatory = $false)]
        [String]$Database,

        [Parameter(Mandatory = $true)]
        [String]$STIGVersion
    )

    # Create list of invalid characters
    $InvalidChars = [System.IO.Path]::GetInvalidFileNameChars() # Get system identified invalid characters - varies by OS
    $InvalidChars += @('<', '>', ':', '"', '/', '\', '|', '?', '*')     # Add known invalid characters for Windows OS
    $InvalidChars = $InvalidChars | Select-Object -Unique       # Remove any duplicates

    # Build BaseFileName variable from inputs
    $BaseFileName = "$($Hostname)_$($STIGShortName)"
    If ($SiteOrInstance) {
        $BaseFileName += "_$($SiteOrInstance)"
    }
    If ($Database) {
        $BaseFileName += "_$($Database)"
    }
    $BaseFileName += "_$($StigVersion)"

    # Replace whitespace with "_"
    $BaseFileName = $BaseFileName -replace "\s+", "_"

    # Replace "\" and "/" with "-"
    $BaseFileName = ($BaseFileName -replace "(\\+|\/+)", "-") -replace ("-{2,}", "-")

    # Replace any invalid characters
    $ValidChar = '+'
    ForEach ($InvalidChar in $InvalidChars) {
        $BaseFileName = $BaseFileName.Replace($InvalidChar, $ValidChar)
    }
    $BaseFileName = $BaseFileName -replace "\+{2,}", "+"

    # Return formatted file name
    Return $BaseFileName
}

Function Format-CKL {
    param
    (
        [Parameter(Mandatory)]
        [string]$SchemaPath,

        [Parameter(Mandatory)]
        [psobject]$ScanObject,

        [Parameter(Mandatory)]
        [string]$OutputPath,

        [Parameter()]
        [string]$Marking = "",

        [Parameter(Mandatory = $true)]
        [String]$WorkingDir,

        [Parameter(Mandatory = $true)]
        [String]$ESPath,

        [Parameter(Mandatory = $true)]
        [String]$LogComponent,

        [Parameter(Mandatory = $true)]
        [String]$OSPlatform
    )

    # Read the schema
    [xml]$Schema = Get-Content $SchemaPath

    # Get Target Data
    If (($ScanObject | Measure-Object).Count -gt 1) {
        If ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)}) {
            $TargetData = ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)})[0].TargetData
            $TargetKey = ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)})[0].TargetData.TargetKey
            $ScanObject = ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)})
        }
        Else {
            Throw "None of the scanned STIGs can be combined."
        }
    }
    Else {
        $TargetData = $ScanObject.TargetData
        $TargetKey = $ScanObject.TargetData.TargetKey
    }

    # Build the XML data
    $Encoding = [System.Text.UTF8Encoding]::new($false)
    $xmlSettings = New-Object System.Xml.XmlWriterSettings
    $xmlSettings.Encoding = $Encoding
    $xmlSettings.Indent = $true
    $xmlSettings.IndentChars = "`t"
    $xmlSettings.NewLineHandling = "None"

    $xmlWriter = [System.Xml.XmlWriter]::Create($($OutputPath), $xmlSettings)

    $rootnode = $Schema.SelectSingleNode("//*")

    $xpath = "*[local-name()='element' or local-name()='complexType' or local-name()='sequence' or local-name()='attribute']"
    $nodes = $rootnode.SelectNodes($xpath)

    # Create Evaluate-STIG comment
    $xmlWriter.WriteComment("<Evaluate-STIG><version>$($ScanObject[0].ESData.ESVersion)</version></Evaluate-STIG>")

    #We know Checklist is the root node and has "ASSET" and "STIGS" as sub nodes
    $xmlWriter.WriteStartElement("CHECKLIST")

    $xmlWriter.WriteStartElement("ASSET")
    # Specify elements and order from STIG Viewer saved CKL.  May differ from STIG Viewer schema.
    $SortOrder = @("ROLE", "ASSET_TYPE", "MARKING", "HOST_NAME", "HOST_IP", "HOST_MAC", "HOST_FQDN", "TARGET_COMMENT", "TECH_AREA", "TARGET_KEY", "WEB_OR_DATABASE", "WEB_DB_SITE", "WEB_DB_INSTANCE")
    Foreach ($node in $(($nodes | Where-Object {$_.Name -eq "ASSET"}).complexType.sequence.element) | Sort-Object {$SortOrder.IndexOf($_.ref)}) {
        If ($node.ref -in $SortOrder) {
            Switch ($Node.ref) {
                "ROLE" {
                    $ValidValues = @("None", "Workstation", "Member Server", "Domain Controller")
                    If ($TargetData.Role -and $TargetData.Role -notin $ValidValues) {
                        Throw "Invalid value for property [$($_)]: '$($TargetData.Role)'"
                    }
                    Else {
                        $xmlWriter.WriteElementString($Node.ref, $($TargetData.Role))
                    }
                }
                "ASSET_TYPE" {
                    $xmlWriter.WriteElementString($Node.ref, "Computing")
                }
                "MARKING" {
                    $xmlWriter.WriteElementString($Node.ref, $($Marking))
                }
                "HOST_NAME" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.Hostname))
                }
                "HOST_IP" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.IpAddress))
                }
                "HOST_MAC" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.MacAddress))
                }
                "HOST_FQDN" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.FQDN))
                }
                "TARGET_KEY" {
                    $xmlWriter.WriteElementString($Node.ref, $TargetKey)
                }
                "WEB_OR_DATABASE" {
                    If ($TargetData.WebOrDatabase -notin @("true", "false")) {
                        Throw "Invalid value for property [$($_)]: '$($TargetData.WebOrDatabase )'"
                    }
                    Else {
                        $xmlWriter.WriteElementString($Node.ref, $(([String]($Targetdata.WebOrDatabase)).ToLower()))
                    }
                }
                "WEB_DB_SITE" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.Site))
                }
                "WEB_DB_INSTANCE" {
                    $xmlWriter.WriteElementString($Node.ref, $($TargetData.Instance))
                }
                default {
                    $xmlWriter.WriteStartElement($Node.ref)
                    $xmlWriter.WriteFullEndElement()
                }
            }
        }
    }
    $xmlWriter.WriteEndElement() #ASSET

    $xmlWriter.WriteStartElement("STIGS")

    ForEach ($Scan in $ScanObject) {
        # Read the STIG content
        $STIGXMLPath = $(Join-Path -Path $ESPath -ChildPath StigContent | Join-Path -ChildPath $Scan.ESData.STIGXMLName)
        # https://stackoverflow.com/questions/71847945/strange-characters-found-in-xml-file-and-powershell-output-after-exporting-from
        ($Content = [xml]::new()).Load($STIGXMLPath)

        # Set STIG Classification
        Switch -Regex ($Content.'xml-stylesheet') {
            'STIG_unclass.xsl' {
                $Classification = "UNCLASSIFIED"
            }
            'STIG_cui.xsl' {
                $Classification = "CUI"
            }
            DEFAULT {
                Throw "Unable to determine STIG classification."
            }
        }

        $xmlWriter.WriteStartElement("iSTIG")

        # Create Evaluate-STIG comment
        $xmlWriter.WriteComment("<Evaluate-STIG><time>$($Scan.ESData.StartTime)</time><module><name>$($Scan.ESData.ModuleName)</name><version>$([String]$Scan.ESData.ModuleVersion)</version></module></Evaluate-STIG>")

        $xmlWriter.WriteStartElement("STIG_INFO")
        # Specify elements and order from STIG Viewer saved CKL.  May differ from STIG Viewer schema.
        $SortOrder = @("version", "classification", "customname", "stigid", "description", "filename", "releaseinfo", "title", "uuid", "notice", "source")
        Foreach ($node in $(($nodes | Where-Object { $_.Name -eq "SID_NAME"}).simpleType.restriction.enumeration) | Sort-Object {$SortOrder.IndexOf($_.value)}) {
            If ($node.value -in $SortOrder) {
                $xmlWriter.WriteStartElement("SI_DATA")
                $xmlWriter.WriteElementString("SID_NAME", $Node.value)
                Switch ($Node.value) {
                    "version" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.version)
                    }
                    "classification" {
                        $xmlWriter.WriteElementString("SID_DATA", $Classification)
                    }
                    "customname" {
                        # Do Nothing
                    }
                    "stigid" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.id)
                    }
                    "description" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.description)
                    }
                    "filename" {
                        $xmlWriter.WriteElementString("SID_DATA", $(Split-Path $STIGXMLPath -Leaf))
                    }
                    "releaseinfo" {
                        $xmlWriter.WriteElementString("SID_DATA", ($Content.Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text')
                    }
                    "title" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.title)
                    }
                    "uuid" {
                        $xmlWriter.WriteElementString("SID_DATA", $([guid]::NewGuid()))
                    }
                    "notice" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.notice.id)
                    }
                    "source" {
                        $xmlWriter.WriteElementString("SID_DATA", $Content.Benchmark.reference.source)
                    }
                }
                $xmlWriter.WriteEndElement() #SI_DATA
            }
        }
        $xmlWriter.WriteEndElement() #STIG_INFO
        # Specify elements and order from STIG Viewer saved CKL.  May differ from STIG Viewer schema.
        $SortOrder = @("STIG_DATA", "STATUS", "FINDING_DETAILS", "COMMENTS", "SEVERITY_OVERRIDE", "SEVERITY_JUSTIFICATION")
        $AttribSortOrder = @("Vuln_Num", "Severity", "Group_Title", "Rule_ID", "Rule_Ver", "Rule_Title", "Vuln_Discuss", "IA_Controls", "Check_Content", "Fix_Text", "False_Positives", "False_Negatives", "Documentable", "Mitigations", "Potential_Impact", "Third_Party_Tools", "Mitigation_Control", "Responsibility", "Security_Override_Guidance", "Check_Content_Ref", "Weight", "Class", "STIGRef", "TargetKey", "STIG_UUID", "LEGACY_ID", "CCI_REF")
        Foreach ($Vuln in $Content.Benchmark.Group) {
            # Get results from scan object
            $ScanResult = $Scan.VulnResults | Where-Object GroupID -EQ $Vuln.id
            $xmlWriter.WriteStartElement("VULN")

            If ($ScanResult.STIGMan.AFMod -eq $true) {
                # Create Evaluate-STIG comment
                $xmlWriter.WriteComment("<Evaluate-STIG><AnswerFile>$($ScanResult.STIGMan.AnswerFile)</AnswerFile><AFMod>$(([String]$ScanResult.STIGMan.AFMod).ToLower())</AFMod><OldStatus>$($ScanResult.STIGMan.OldStatus)</OldStatus><NewStatus>$($ScanResult.STIGMan.NewStatus)</NewStatus></Evaluate-STIG>")
            }

            Foreach ($node in $(($nodes | Where-Object { $_.Name -eq "VULN"}).complexType.sequence.element) | Sort-Object {$SortOrder.IndexOf($_.ref)}) {
                If ($node.ref -in $SortOrder) {
                    Switch ($Node.ref) {
                        "STIG_DATA" {
                            Foreach ($subnode in $(($nodes | Where-Object {$_.Name -eq "VULN_ATTRIBUTE"}).simpleType.restriction.enumeration) | Sort-Object {$AttribSortOrder.IndexOf($_.value)}) {
                                If ($subnode.value -in $AttribSortOrder) {
                                    Switch ($subnode.value) {
                                        "Vuln_Num" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.id)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Severity" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.severity)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Group_Title" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.title)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Rule_ID" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.id)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Rule_Ver" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.version)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Rule_Title" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.title)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Vuln_Discuss" {
                                            $Tag = "VulnDiscussion"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "IA_Controls" {
                                            $Tag = "IAControls"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Check_Content" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.check.'check-content')
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Fix_Text" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.fixtext.'#text')
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "False_Positives" {
                                            $Tag = "FalsePositives"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "False_Negatives" {
                                            $Tag = "FalseNegatives"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Documentable" {
                                            $Tag = "Documentable"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Mitigations" {
                                            $Tag = "Mitigations"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Potential_Impact" {
                                            $Tag = "PotentialImpacts"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Third_Party_Tools" {
                                            $Tag = "ThirdPartyTools"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Mitigation_Control" {
                                            $Tag = "MitigationControl"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Responsibility" {
                                            $Tag = "Responsibility"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Security_Override_Guidance" {
                                            $Tag = "SeverityOverrideGuidance"
                                            $Value = [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag)
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            If ($Value) {
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Value)
                                            }
                                            Else {
                                                $xmlWriter.WriteStartElement("ATTRIBUTE_DATA")
                                                $xmlWriter.WriteFullEndElement() #ATTRIBUTE_DATA
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Check_Content_Ref" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.Rule.check.'check-content-ref'.name)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Weight" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.rule.weight)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "Class" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            Switch ($Classification) {
                                                "CUI" {
                                                    $xmlWriter.WriteElementString("ATTRIBUTE_DATA", "CUI")
                                                }
                                                default {
                                                    $xmlWriter.WriteElementString("ATTRIBUTE_DATA", "Unclass")
                                                }
                                            }
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "STIGRef" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", "$($Content.Benchmark.title) :: Version $($Content.Benchmark.version), $(($Content.Benchmark.'plain-text' | Where-Object { $_.id -eq 'release-info' }).'#text')")
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "TargetKey" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $Vuln.rule.reference.identifier)
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "STIG_UUID" {
                                            $xmlWriter.WriteStartElement("STIG_DATA")
                                            $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                            $xmlWriter.WriteElementString("ATTRIBUTE_DATA", $([guid]::NewGuid()))
                                            $xmlWriter.WriteEndElement() #STIG_DATA
                                        }
                                        "LEGACY_ID" {
                                            If ($Vuln.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"}) {
                                                Foreach ($legacy in ($Vuln.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"} | Sort-Object '#text' -Descending)) {
                                                    $xmlWriter.WriteStartElement("STIG_DATA")
                                                    $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                                    $xmlWriter.WriteElementString("ATTRIBUTE_DATA", "$($legacy.'#text')")
                                                    $xmlWriter.WriteEndElement() #STIG_DATA
                                                }
                                            }
                                        }
                                        "CCI_REF" {
                                            Foreach ($CCI in ($Vuln.Rule.ident | Where-Object {$_.system -like "http://*.mil/cci"} | Sort-Object '#text')) {
                                                $xmlWriter.WriteStartElement("STIG_DATA")
                                                $xmlWriter.WriteElementString("VULN_ATTRIBUTE", $subnode.value)
                                                $xmlWriter.WriteElementString("ATTRIBUTE_DATA", "$($CCI.'#text')")
                                                $xmlWriter.WriteEndElement() #STIG_DATA
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "STATUS" {
                            $ValidValues = @("NR", "NF", "NA", "O", "Not_Reviewed", "NotAFinding", "Not_Applicable", "Open", "not_a_finding", "notchecked", "pass", "notapplicable", "fail")
                            If (-Not($ScanResult.Status)) {
                                $Status = "Not_Reviewed"
                            }
                            ElseIf ($ScanResult.Status -and $ScanResult.Status -notin $ValidValues) {
                                Throw "Invalid value for property [$($_)]: '$($ScanResult.Status)'"
                            }
                            Else {
                                $Status = $(Convert-Status -InputObject $ScanResult.Status -Output CKL)
                            }
                            $xmlWriter.WriteElementString("STATUS", $Status)
                        }
                        "FINDING_DETAILS" {
                            If ($ScanResult.FindingDetails) {
                                $xmlWriter.WriteElementString("FINDING_DETAILS", $($ScanResult.FindingDetails))
                            }
                            Else {
                                $xmlWriter.WriteElementString("FINDING_DETAILS", "")
                            }
                        }
                        "COMMENTS" {
                            If ($ScanResult.Comments) {
                                $xmlWriter.WriteElementString("COMMENTS", $($ScanResult.Comments))
                            }
                            Else {
                                $xmlWriter.WriteElementString("COMMENTS", "")
                            }
                        }
                        "SEVERITY_OVERRIDE" {
                            If ($ScanResult.SeverityOverride) {
                                $ValidValues = @("low", "medium", "high")
                                If ($ScanResult.SeverityOverride -notin $ValidValues) {
                                    Throw "Invalid value for property [$($_)]: '$($ScanResult.SeverityOverride)'"
                                }
                                Else {
                                    $xmlWriter.WriteElementString("SEVERITY_OVERRIDE", $($ScanResult.SeverityOverride))
                                }
                            }
                            Else {
                                $xmlWriter.WriteElementString("SEVERITY_OVERRIDE", "")
                            }
                        }
                        "SEVERITY_JUSTIFICATION" {
                            If ($ScanResult.Justification) {
                                $xmlWriter.WriteElementString("SEVERITY_JUSTIFICATION", $($ScanResult.Justification))
                            }
                            Else {
                                $xmlWriter.WriteElementString("SEVERITY_JUSTIFICATION", "")
                            }
                        }
                        default {
                            $xmlWriter.WriteStartElement($Node.ref)
                            $xmlWriter.WriteFullEndElement()
                        }
                    }
                }
            }
            $xmlWriter.WriteEndElement() #VULN
        }

        $xmlWriter.WriteEndElement() #iSTIG
    }

    $xmlWriter.WriteEndElement() #STIGS

    $xmlWriter.WriteEndElement() #CHECKLIST
    $xmlWriter.WriteEndDocument()
    $xmlWriter.Flush()
    $xmlWriter.Close()

    Write-Log -Path $STIGLog -Message "Validating CKL File" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
    $ChecklistValid = Test-XmlValidation -XmlFile $OutputPath -SchemaFile $SchemaPath

    # Action for validation result
    If ($ChecklistValid) {
        Write-Log -Path $STIGLog -Message "'$(Split-Path $OutputPath -Leaf)' : Passed." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
    }
    Else {
        $BadFileDestination = Join-Path -Path $WorkingDir -ChildPath "Bad_CKL"
        Write-Log -Path $STIGLog -Message "ERROR: '$(Split-Path $OutputPath -Leaf)' : failed schema validation. Moving to $BadFileDestination." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
        ForEach ($Item in $ChecklistValid.Message) {
            Write-Log -Path $STIGLog -Message $Item -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
        }
        If (-Not(Test-Path $BadFileDestination)) {
            $null = New-Item -Path $BadFileDestination -ItemType Directory
        }
        Copy-Item -Path $OutputPath -Destination $BadFileDestination -Force
        Remove-Item $OutputPath -Force
    }

    Return $ChecklistValid
}

Function Format-CKLB {
    # https://mattou07.net/posts/creating-complex-json-with-powershell/
    param
    (
        [Parameter(Mandatory)]
        [string]$SchemaPath,

        [Parameter(Mandatory)]
        [psobject]$ScanObject,

        [Parameter(Mandatory)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [String]$WorkingDir,

        [Parameter(Mandatory = $true)]
        [String]$ESPath,

        [Parameter(Mandatory = $true)]
        [String]$LogComponent,

        [Parameter(Mandatory = $true)]
        [String]$OSPlatform
    )

    $Schema = Get-Content $SchemaPath -Raw | ConvertFrom-Json

    # Get Target Data
    If (($ScanObject | Measure-Object).Count -gt 1) {
        If ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)}) {
            $TargetData = ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)})[0].TargetData
            $ScanObject = ($ScanObject | Where-Object {($_.ESData.CanCombine -eq $true)})
        }
        Else {
            Throw "None of the scanned STIGs can be combined."
        }
    }
    Else {
        $TargetData = $ScanObject.TargetData
    }

    $objCKLB = [ordered]@{}
    $RootProps = ($Schema.properties.PsObject.Members | Where-Object MemberType -EQ "NoteProperty").Name
    ForEach ($P1 in $RootProps) {
        Switch ($P1) {
            "evaluate-stig" {
                $objES = [ordered]@{}
                $ESProps = ($Schema.properties.$P1.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                ForEach ($P2 in $ESProps) {
                    Switch ($P2) {
                        "version" {
                            $objES.Add($_, $($ScanObject[0].ESData.ESVersion))
                        }
                        Default {
                            $Message = "Unexpected CKLB schema property: '$_'"
                            Throw $Message
                        }
                    }
                }
                $objCKLB.Add("evaluate-stig", $objES)
            }
            "title" {
                If (($ScanObject | Measure-Object).Count -gt 1) {
                    $objCKLB.Add($_, "Evaluate-STIG_COMBINED")
                }
                Else {
                    $objCKLB.Add($_, "Evaluate-STIG_$($ScanObject.ESData.STIGShortName)")
                }
            }
            "id" {
                $objCKLB.Add($_, $([guid]::NewGuid()))
            }
            "stigs" {
                $arrSTIGs = New-Object System.Collections.ArrayList
                ForEach ($Scan in $ScanObject) {
                    # Read the STIG content
                    $STIGXMLPath = $(Join-Path -Path $ESPath -ChildPath StigContent | Join-Path -ChildPath $Scan.ESData.STIGXMLName)
                    # https://stackoverflow.com/questions/71847945/strange-characters-found-in-xml-file-and-powershell-output-after-exporting-from
                    ($Content = [xml]::new()).Load($STIGXMLPath)

                    # Set STIG Classification
                    Switch -Regex ($Content.'xml-stylesheet') {
                        'STIG_unclass.xsl' {
                            $Classification = "UNCLASSIFIED"
                        }
                        'STIG_cui.xsl' {
                            $Classification = "CUI"
                        }
                        DEFAULT {
                            Throw "Unable to determine STIG classification."
                        }
                    }

                    $objSTIG = [ordered]@{}
                    $STIGUUID = [guid]::NewGuid()
                    $StigProps = ($Schema.properties.$P1.items.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                    ForEach ($P2 in $StigProps) {
                        Switch ($P2) {
                            "evaluate-stig" {
                                $objES = [ordered]@{}
                                $ESProps = ($Schema.properties.$P1.items.properties.$P2.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                ForEach ($P3 in $ESProps) {
                                    Switch ($P3) {
                                        "time" {
                                            $objES.Add($_, $($Scan.ESData.StartTime))
                                        }
                                        "module" {
                                            $objModule = [ordered]@{}
                                            $ModuleProps = ($Schema.properties.$P1.items.properties.$P2.properties.$P3.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                            ForEach ($P4 in $ModuleProps) {
                                                Switch ($P4) {
                                                    "name" {
                                                        $objModule.Add($_, $($Scan.ESData.ModuleName))
                                                    }
                                                    "version" {
                                                        $objModule.Add($_, $([String]$Scan.ESData.ModuleVersion))
                                                    }
                                                    Default {
                                                        $Message = "Unexpected CKLB schema property: '$_'"
                                                        Throw $Message
                                                    }
                                                }
                                            }
                                            $objES.Add($_, $($objModule))
                                        }
                                        Default {
                                            $Message = "Unexpected CKLB schema property: '$_'"
                                            Throw $Message
                                        }
                                    }
                                }
                                $objSTIG.Add("evaluate-stig", $objES)
                            }
                            "stig_name" {
                                $objSTIG.Add($_, $Content.Benchmark.title)
                            }
                            "display_name" {
                                $objSTIG.Add($_, $(($Content.Benchmark.title).Replace(" Security Technical Implementation Guide", "")))
                            }
                            "stig_id" {
                                $objSTIG.Add($_, $Content.Benchmark.id)
                            }
                            "release_info" {
                                $objSTIG.Add($_, $($Content.Benchmark.'plain-text' | Where-Object { $_.id -eq "release-info" }).'#text')
                            }
                            "version" {
                                $objSTIG.Add($_, $Content.Benchmark.version)
                            }
                            "uuid" {
                                $objSTIG.Add($_, $STIGUUID)
                            }
                            "reference_identifier" {
                                $objSTIG.Add($_, $($Content.Benchmark.Group)[0].Rule.reference.identifier)
                            }
                            "size" {
                                $objSTIG.Add($_, 12) # What does this property do and what is the source?
                            }
                            "rules" {
                                $arrRules = New-Object System.Collections.ArrayList
                                $RuleProps = ($Schema.properties.$P1.items.properties.$P2.items.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                ForEach ($Vuln in $Content.Benchmark.Group) {
                                    $ScanResult = $Scan.VulnResults | Where-Object GroupID -EQ $Vuln.id
                                    $objRule = [ordered]@{}
                                    ForEach ($P3 in $RuleProps) {
                                        Switch ($P3) {
                                            "evaluate-stig" {
                                                If ($ScanResult.STIGMan.AFMod -eq $true) {
                                                    $objES = [ordered]@{}
                                                    $ESProps = ($Schema.properties.$P1.items.properties.$P2.items.properties.$P3.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                                    ForEach ($P4 in $ESProps) {
                                                        Switch ($P4) {
                                                            "answer_file" {
                                                                $objES.Add($_, $($ScanResult.STIGMan.AnswerFile))
                                                            }
                                                            "afmod" {
                                                                $objES.Add($_, $ScanResult.STIGMan.AFMod)
                                                            }
                                                            "old_status" {
                                                                $objES.Add($_, $($ScanResult.STIGMan.OldStatus))
                                                            }
                                                            "new_status" {
                                                                $objES.Add($_, $($ScanResult.STIGMan.NewStatus))
                                                            }
                                                            Default {
                                                                $Message = "Unexpected CKLB schema property: '$_'"
                                                                Throw $Message
                                                            }
                                                        }
                                                    }
                                                    $objRule.Add("evaluate-stig", $objES)
                                                }
                                            }
                                            "group_id_src" {
                                                $objRule.Add($_, $($Vuln.id))
                                            }
                                            "group_tree" {
                                                $objGroupTree = [ordered]@{}
                                                $arrGroupTree = New-Object System.Collections.ArrayList
                                                $GroupTreeProps = ($Schema.properties.$P1.items.properties.$P2.items.properties.$P3.items.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                                ForEach ($P4 in $GroupTreeProps) {
                                                    Switch ($P4) {
                                                        "id" {
                                                            $objGroupTree.Add($_, $($Vuln.id))
                                                        }
                                                        "title" {
                                                            $objGroupTree.Add($_, $($Vuln.title))
                                                        }
                                                        "description" {
                                                            $objGroupTree.add($_, $($Vuln.description))
                                                        }
                                                        Default {
                                                            $Message = "Unexpected CKLB schema property: '$_'"
                                                            Throw $Message
                                                        }
                                                    }
                                                }
                                                $null = $arrGroupTree.Add($objGroupTree)
                                                $objRule.Add("group_tree", $arrGroupTree)
                                            }
                                            "group_id" {
                                                $objRule.Add($_, $($Vuln.id))
                                            }
                                            "severity" {
                                                $objRule.Add($_, $($Vuln.rule.severity))
                                            }
                                            "group_title" {
                                                $objRule.Add($_, $($Vuln.rule.title))
                                            }
                                            "rule_id_src" {
                                                $objRule.Add($_, $($Vuln.rule.id))
                                            }
                                            "rule_id" {
                                                $objRule.Add($_, $($Vuln.rule.id -replace "_rule", ""))
                                            }
                                            "rule_version" {
                                                $objRule.Add($_, $($Vuln.rule.version))
                                            }
                                            "rule_title" {
                                                $objRule.Add($_, $($Vuln.rule.title))
                                            }
                                            "fix_text" {
                                                $objRule.Add($_, $($Vuln.rule.fixtext.'#text'))
                                            }
                                            "weight" {
                                                $objRule.Add($_, $($Vuln.rule.weight))
                                            }
                                            "check_content" {
                                                $objRule.Add($_, $($Vuln.Rule.check.'check-content'))
                                            }
                                            "check_content_ref" {
                                                $objCCRef = [ordered]@{}
                                                $CCRefProps = ($Schema.properties.$P1.items.properties.$P2.items.properties.$P3.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                                                ForEach ($P4 in $CCRefProps) {
                                                    Switch ($P4) {
                                                        "href" {
                                                            $objCCRef.Add($_, $($Vuln.rule.check.'check-content-ref'.href))
                                                        }
                                                        "name" {
                                                            $objCCRef.Add($_, $($Vuln.rule.check.'check-content-ref'.name))
                                                        }
                                                        Default {
                                                            $Message = "Unexpected CKLB schema property: '$_'"
                                                            Throw $Message
                                                        }
                                                    }
                                                }
                                                $objRule.Add($_, $objCCRef)
                                            }
                                            "classification" {
                                                $objRule.Add($_, $Classification)
                                            }
                                            "discussion" {
                                                $Tag = "VulnDiscussion"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "false_positives" {
                                                $Tag = "FalsePositives"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "false_negatives" {
                                                $Tag = "FalseNegatives"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "documentable" {
                                                $Tag = "Documentable"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "security_override_guidance" {
                                                $Tag = "SeverityOverrideGuidance"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "potential_impacts" {
                                                $Tag = "PotentialImpacts"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "third_party_tools" {
                                                $Tag = "ThirdPartyTools"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "ia_controls" {
                                                $Tag = "IAControls"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "responsibility" {
                                                $Tag = "Responsibility"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "mitigations" {
                                                $Tag = "Mitigations"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "mitigation_control" {
                                                $Tag = "MitigationControl"
                                                $objRule.Add($_, [String](Get-InnerXml -InnerXml $Vuln.rule.description -Tag $Tag))
                                            }
                                            "legacy_ids" {
                                                If ($Vuln.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"}) {
                                                    $arrLegacy = New-Object System.Collections.ArrayList
                                                    Foreach ($legacy in ($Vuln.Rule.ident | Where-Object {$_.system -eq "http://cyber.mil/legacy"} | Sort-Object '#text')) {
                                                        $null = $arrLegacy.Add($($legacy.'#text'))
                                                    }
                                                    $objRule.Add($_, $arrLegacy)
                                                }
                                            }
                                            "ccis" {
                                                $arrCCIs = New-Object System.Collections.ArrayList
                                                Foreach ($CCI in ($Vuln.Rule.ident | Where-Object {$_.system -like "http://*.mil/cci"} | Sort-Object '#text')) {
                                                    $null = $arrCCIs.Add($($CCI.'#text'))
                                                }
                                                $objRule.Add($_, $arrCCIs)
                                            }
                                            "reference_identifier" {
                                                $objRule.Add($_, $($Vuln.Rule.reference.identifier))
                                            }
                                            "uuid" {
                                                $objRule.Add($_, $([guid]::NewGuid()))
                                            }
                                            "stig_uuid" {
                                                $objRule.Add($_, $STIGUUID)
                                            }
                                            "status" {
                                                $ValidValues = @("NR", "NF", "NA", "O", "Not_Reviewed", "NotAFinding", "Not_Applicable", "Open", "not_a_finding", "notchecked", "pass", "notapplicable", "fail")
                                                If (-Not($ScanResult.Status)) {
                                                    $Status = "not_reviewed"
                                                }
                                                ElseIf ($ScanResult.Status -and $ScanResult.Status -notin $ValidValues) {
                                                    Throw "Invalid value for property [$($_)]: '$($ScanResult.Status)'"
                                                }
                                                Else {
                                                    $Status = $(Convert-Status -InputObject $ScanResult.Status -Output CKLB)
                                                }
                                                $objRule.Add($_, $Status.ToLower())
                                            }
                                            "overrides" {
                                                $objOverrides = @{}
                                                If ($ScanResult.SeverityOverride) {
                                                    $ValidValues = @("low", "medium", "high")
                                                    $dataObject = [ordered]@{}
                                                    If ($ScanResult.SeverityOverride -notin $ValidValues) {
                                                        Throw "Invalid value for property [$($_)]: '$($ScanResult.SeverityOverride)'"
                                                    }
                                                    Else {
                                                        $dataObject.Add("severity", $($ScanResult.SeverityOverride).ToLower())
                                                    }
                                                    If ($ScanResult.Justification) {
                                                        $dataObject.Add("reason", $($ScanResult.Justification))
                                                    }
                                                    Else {
                                                        $dataObject.Add("reason", "No reason provided")
                                                    }
                                                    $objOverrides.Add("severity", $dataObject)
                                                }
                                                $objRule.Add($_, $objOverrides)
                                            }
                                            "comments" {
                                                If ($ScanResult.Comments) {
                                                    $objRule.Add($_, $($ScanResult.Comments))
                                                }
                                                Else {
                                                    $objRule.Add($_, "")
                                                }
                                            }
                                            "finding_details" {
                                                If ($ScanResult.FindingDetails) {
                                                    $objRule.Add($_, $($ScanResult.FindingDetails))
                                                }
                                                Else {
                                                    $objRule.Add($_, "")
                                                }
                                            }
                                            Default {
                                                $Message = "Unexpected CKLB schema property: '$_'"
                                                Throw $Message
                                            }
                                        }
                                    }
                                    $null = $arrRules.Add($objRule)
                                }
                                $objSTIG.Add("rules", $arrRules)
                            }
                        }
                    }
                    $null = $arrSTIGs.Add($objSTIG)
                }
                $objCKLB.Add("stigs", $arrSTIGs)
            }
            "active" {
                $objCKLB.Add($_, $false)
            }
            "mode" {
                $objCKLB.Add($_, 1)
            }
            "has_path" {
                $objCKLB.Add($_, $true)
            }
            "target_data" {
                $objTargetData = [ordered]@{}
                $TargetDataProps = ($Schema.properties.$P1.properties.psobject.members | Where-Object MemberType -EQ "NoteProperty").Name
                ForEach ($P2 in $TargetDataProps) {
                    Switch ($P2) {
                        "target_type" {
                            $objTargetData.Add($_, "Computing")
                        }
                        "host_name" {
                            $objTargetData.Add($_, $($TargetData.Hostname))
                        }
                        "ip_address" {
                            $objTargetData.Add($_, $($TargetData.IpAddress))
                        }
                        "mac_address" {
                            $objTargetData.Add($_, $($TargetData.MacAddress))
                        }
                        "fqdn" {
                            $objTargetData.Add($_, $($TargetData.FQDN))
                        }
                        "comments" {
                            $objTargetData.Add($_, "")
                        }
                        "role" {
                            $ValidValues = @("None", "Workstation", "Member Server", "Domain Controller")
                            If ($TargetData.Role -and $TargetData.Role -notin $ValidValues) {
                                Throw "Invalid value for property [$($_)]: '$($TargetData.Role)'"
                            }
                            Else {
                                $objTargetData.Add($_, $($TargetData.Role))
                            }
                        }
                        "is_web_database" {
                            If ($TargetData.WebOrDatabase.GetType().Name -ne "Boolean") {
                                Throw "Invalid value type for property [$($_)]: '$($TargetData.WebOrDatabase.GetType().Name)'"
                            }
                            Else {
                                $objTargetData.Add($_, $($TargetData.WebOrDatabase))
                            }
                        }
                        "technology_area" {
                            $objTargetData.Add($_, "None")
                        }
                        "web_db_site" {
                            $objTargetData.Add($_, $($TargetData.Site))
                        }
                        "web_db_instance" {
                            $objTargetData.Add($_, $($TargetData.Instance))
                        }
                        Default {
                            $Message = "Unexpected CKLB schema property: '$_'"
                            Throw $Message
                        }
                    }
                }
                $objCKLB.Add($_, $objTargetData)
            }
            "cklb_version" {
                $objCKLB.Add($_, "1.0")
            }
            Default {
                $Message = "Unexpected CKLB schema property: '$_'"
                Throw $Message
            }
        }
    }

    # Convert to JSON and preserve some characters - https://stackoverflow.com/a/53644601/45375
    $CKLB = [regex]::replace($($objCKLB | ConvertTo-Json -Depth 10 -Compress), '\\u[0-9a-fA-F]{4}', {param($match) [char] [int] ('0x' + $match.Value.Substring(2))})

    # CKLB file must be 'UTF-8' and no BOM
    [System.IO.File]::WriteAllLines($OutputPath, $CKLB)

    Write-Log -Path $STIGLog -Message "Validating CKLB File" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
    $ChecklistValid = $true
    If ([Version]$PSVersionTable.PSVersion -lt [Version]"7.0") {
        Write-Log -Path $STIGLog -Message "PowerShell $($PSVersionTable.PSVersion -join ".") not supported for Json validation" -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
    }
    Else {
        $ChecklistValid = Test-JsonValidation -JsonFile $OutputPath -SchemaFile $SchemaPath

        # Action for validation result
        If ($ChecklistValid) {
            Write-Log -Path $STIGLog -Message "'$(Split-Path $OutputPath -Leaf)' : Passed." -Component $LogComponent -Type "Info" -OSPlatform $OSPlatform
        }
        Else {
            $BadFileDestination = Join-Path -Path $WorkingDir -ChildPath "Bad_CKL"
            Write-Log -Path $STIGLog -Message "ERROR: '$(Split-Path $OutputPath -Leaf)' : failed schema validation. Moving to $BadFileDestination." -WriteOutToStream -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            ForEach ($Item in $ChecklistValid.Message) {
                Write-Log -Path $STIGLog -Message $Item -Component $LogComponent -Type "Error" -OSPlatform $OSPlatform
            }
            If (-Not(Test-Path $BadFileDestination)) {
                New-Item -Path $BadFileDestination -ItemType Directory | Out-Null
            }
            Copy-Item -Path $OutputPath -Destination $BadFileDestination -Force
            Remove-Item $OutputPath -Force
        }
    }

    Return $ChecklistValid
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBfJRkpnLHrjMNB
# 4ZRRrkncA+oTw+wmy3DLXFZ3KVBqDqCCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCejCHc9zrABLG7p35CRN46IbIsZ83F
# OuLO2YLBrkeY+jANBgkqhkiG9w0BAQEFAASCAQCkHDYsNNXrYFWl3pdiij8e003x
# JnkLyaMl1suE0EURj22SmH20T1E1WXH5OLK5UF6bHWPUV93QwjQ45k7A2uEXAqe1
# pT27P5Sbus85y1uUwDa4oH9RhhrGUB+3/BB3loM6aj4QpNDb8Pnnb5DduDrygjfI
# QFZ7UGVbsZ9/t56XKxlbsKom97b3cL4GMY0fkj8QE3QEVvNX7n1dnnk+D1FaEQgP
# vtpS9ZTLSq8SSeyph2TwVreUkI8BujxlioupiwEpTCO98gVobEAkAY6nRcaftXKn
# jlIXV0TL4Fv3OtjbDpkRIgBoBKMiToOxkLIyqgLWJRNGtIg4FTGbT72EhQV8
# SIG # End signature block
