##############################################
# STIG detection functions for Evaluate-STIG #
##############################################

Function Test-IsActiveDirectoryInstalled {
    # Active Directory detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Domain", "Forest")]
        [string]$Level
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Level) {
                "Domain" {
                    If ((Get-DomainRoleStatus -ExpectedRole "Primary Domain Controller").BoolMatchExpected) {
                        $STIGRequired = $true
                    }
                }
                "Forest" {
                    If ((Get-DomainRoleStatus -ExpectedRole "Primary Domain Controller").BoolMatchExpected -and ((Get-ADDomain).DNSRoot -eq (Get-ADDomain).Forest)) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsAdobeProReaderInstalled {
    # Adobe Acrobat Pro and Reader detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Pro", "Reader")]
        [string]$Edition,

        [Parameter(Mandatory)]
        [ValidateSet("XI", "Classic", "Continuous")]
        [string]$Track
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Edition) {
                "Pro" {
                    Switch ($Track) {
                        "XI" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Version -eq "XI"}) {
                                $STIGRequired = $true
                            }
                        }
                        "Classic" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Track -eq "Classic" -and $_.Version -in @("2015", "2017", "2020")}) {
                                $STIGRequired = $true
                            }
                        }
                        "Continuous" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Acrobat*" -and $_.Track -eq "Continuous" -and $_.Version -eq "DC"}) {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
                "Reader" {
                    Switch ($Track) {
                        "Classic" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Reader*" -and $_.Track -eq "Classic" -and $_.Version -in @("2015", "2017", "2020")}) {
                                $STIGRequired = $true
                            }
                        }
                        "Continuous" {
                            If (Get-AdobeReaderProInstalls | Where-Object {$_.Name -like "Adobe Reader*" -and $_.Track -eq "Continuous" -and $_.Version -eq "DC"}) {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsApacheInstalled {
    # Apache 2.4 detection
    Param (
        [Parameter(Mandatory)]
        [string] $OnOS
    )

    $STIGRequired = $false
    Try {
        If ($OnOS -eq "Unix") {
            If (-not ($IsLinux)) {
                Return $STIGRequired
            }

            $ExecutablePaths = Get-ApacheUnixExecutablePaths
            If (($ExecutablePaths | Measure-Object).Count -gt 0) {
                $STIGRequired = $True
            }

            Return $STIGRequired
        }
        ElseIf ($OnOS -eq "Windows") {
            If ($IsLinux) {
                Return $STIGRequired
            }

            $Services = Get-CimInstance -ClassName win32_service
            If ($null -eq $Services) {
                Return $STIGRequired
            }

            Foreach ($service in $Services) {
                $PathName = $service.PathName
                $Path = ($PathName -split '"')[1]
                If ($null -eq $Path -or $Path -eq "") {
                    # If a path can't be parsed (because we know what it looks like) ignore.
                    Continue
                }

                If (-not (Test-Path -Path $Path -PathType Leaf)) {
                    # If a path is parsed and it doesn't lead to a file, ignore.
                    Continue
                }

                $Extension = (Get-ItemProperty -Path $Path -Name Extension).Extension
                If ($Extension -ne '.exe') {
                    # If the file is not an .exe, ignore.
                    Continue
                }

                $VersionInfo = (Get-Item -Path $Path).VersionInfo;
                $FileDescription = $VersionInfo.FileDescription;
                If ($FileDescription -notlike "*Apache*HTTP*Server") {
                    # If the file descriptor is not anything related to apache server, ignore.
                    Continue
                }

                $Param = '-v'
                $VersionOutput = (& "$($Path)" $Param)
                If ($VersionOutput | Select-String -Pattern '2.4' -Quiet) {
                    # If we get no version as output or if the version is incorrect, ignore.
                    $STIGRequired = $true
                }
            }
        }
        Return $STIGRequired
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsTomcatInstalled {
    # Apache Tomcat Application Server detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsTomcatRunning = 0

            If ((Get-Process).ProcessName -match "tomcat") {
                $IsTomcatRunning += 1
            }

            Get-Process | ForEach-Object {
                If (($_.Name -match "^java\d{0,}\b") -and ($_.CommandLine -match "catalina.base|catalina.home")) {
                    $IsTomcatRunning += 1
                }
            }

            If ($IsTomcatRunning -gt 0) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsArcGISInstalled {
    # ArcGIS Server 10.3 detection
    $STIGRequired = $false
    Try {
        If (($PsVersionTable.PSVersion).ToString() -match "5.*") {
            $IsArcGISInstalled = (Get-WmiObject Win32_Process -Filter "Name= 'ArcGISServer.exe'" | ForEach-Object {Write-Output "$($_.Name)"})
        }
        Else {
            $IsArcGISInstalled = ((Get-Process).ProcessName -Match "ArcGIS\s?Server" )
        }

        If ($IsArcGISInstalled) {
            $STIGRequired = $true
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsCisco {
    # Cisco detection
    Param (
        [Parameter(Mandatory)]
        [psobject]$DeviceInfo,

        [Parameter(Mandatory)]
        [ValidateSet("Router", "Switch")]
        [string]$DeviceType,

        [Parameter(Mandatory)]
        [ValidateSet("XE")]
        [string]$CiscoOS
    )

    $STIGRequired = $false
    Try {
        If ($DeviceInfo | Where-Object {($_.DeviceType -eq $DeviceType -and $_.CiscoOS -match $CiscoOS)}) {
            $STIGRequired = $true
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsChromeInstalled {
    # Google Chrome detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-InstalledSoftware | Where-Object DisplayName -EQ "Google Chrome") -or (Get-ChildItem -Path $env:ProgramFiles\Google\Chrome -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "chrome.exe") -or (Get-ChildItem -Path ${env:ProgramFiles(x86)}\Google\Chrome -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "chrome.exe")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsIISInstalled {
    # Microsoft IIS detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("10.0", "8.5")]
        [string]$Version
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Version) {
                "10.0" {
                    If (((Get-CimInstance Win32_OperatingSystem | Where-Object Caption -Like "*Windows*Server*") -and ((Get-WindowsFeature -Name "Web-WebServer").Installed -eq $true)) -or ((Get-CimInstance Win32_OperatingSystem | Where-Object Caption -Like "*Windows*1*") -and ((Get-CimInstance -ClassName Win32_OptionalFeature | Where-Object Name -EQ "IIS-WebServer").InstallState -eq 1))) {
                        If (Test-Path "HKLM:\SOFTWARE\Microsoft\InetStp") {
                            $InetStp = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp"
                            [Version]$IISVersion = "$(($InetStp).MajorVersion).$(($InetStp).MinorVersion)"
                            If ($IISVersion -ge [Version]"10.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
                "8.5" {
                    If ((Get-CimInstance Win32_OperatingSystem | Where-Object Caption -Like "*Windows*Server*") -and ((Get-WindowsFeature -Name "Web-WebServer").Installed -eq $true)) {
                        If (Test-Path "HKLM:\SOFTWARE\Microsoft\InetStp") {
                            $InetStp = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp"
                            [Version]$IISVersion = "$(($InetStp).MajorVersion).$(($InetStp).MinorVersion)"
                            If ($IISVersion -ge [Version]"8.5" -and $IISVersion -lt [Version]"10.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsIE11Installed {
    # Internet Explorer 11 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $Paths = @("$env:ProgramFiles", "${env:ProgramFiles(x86)}")
            ForEach ($Path in $Paths) {
                If ([Version](Get-ChildItem "$Path\Internet Explorer\iexplore.exe" -ErrorAction SilentlyContinue).VersionInfo.ProductVersion -ge "11.0") {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsJBossInstalled {
    # JBoss EAP 6.3 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsJBossInstalled = (ps -ef | grep -i jboss.home.dir | grep -v grep)
            If ($IsJBossInstalled) {
                $STIGRequired = $true
            }
        }
        Else {
            If (($PsVersionTable.PSVersion).ToString() -match "5.*") {
                $IsJBossInstalled = (Get-WmiObject Win32_Process -Filter "Name= 'java.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
                        If ($_.CommandLine | Select-String -Pattern "jboss.home.dir") {
                            Write-Output "$($_.CommandLine)}"
                        }})
            }
            Else {
                $IsJBossInstalled = (Get-Process -Name "java" -ErrorAction SilentlyContinue | ForEach-Object {
                        If ($_.CommandLine | Select-String -Pattern "jboss.home.dir") {
                            Write-Output "$($_.Id) $($_.CommandLine)}"
                        }})
            }

            If ($IsJBossInstalled) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMcAfeeVS88Installed {
    # McAfee VirusScan 8.8 Local Client detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ((Get-CimInstance Win32_OperatingSystem).OSArchitecture) {
                "64-bit" {
                    If ((Get-InstalledSoftware | Where-Object {($_.DisplayName -eq "McAfee VirusScan Enterprise") -and ([Version]$_.DisplayVersion -ge "8.8")}) -and ((Get-RegistryResult -Path "HKLM:\SOFTWARE\WOW6432Node\Network Associates\ePolicy Orchestrator\Agent" -ValueName "ePOServerList").Value -in @("(blank)", "(NotFound)"))) {
                        $STIGRequired = $true
                    }
                }
                "32-bit" {
                    If ((Get-InstalledSoftware | Where-Object {($_.DisplayName -eq "McAfee VirusScan Enterprise") -and ([Version]$_.DisplayVersion -ge "8.8")}) -and ((Get-RegistryResult -Path "HKLM:\SOFTWARE\Network Associates\ePolicy Orchestrator\Agent" -ValueName "ePOServerList").Value -in @("(blank)", "(NotFound)"))) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsDotNET4Installed {
    # Microsoft .NET Framework 4 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -ErrorAction SilentlyContinue).Install -eq 1) -or ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue).Install -eq 1)) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSOfficeInstalled {
    # Microsoft Office detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2013", "2016", "O365")]
        [string]$Version,

        [ValidateSet("Common", "Access", "Excel", "Groove", "InfoPath", "Lync", "OneNote", "Outlook", "PowerPoint", "Project", "Publisher", "Skype", "Visio", "Word")]
        [array]$Component
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Version) {
                "2013" {
                    $MinVer = [Version]"15.0.4420.1017"
                    $NextVer = [Version]"16.0.4229.1003"
                    $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\15.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0")
                }
                "2016" {
                    $MinVer = [Version]"16.0.4229.1003"
                    $NextVer = [Version]"16.0.10336.20039"
                    $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                }
                "O365" {
                    $MinVer = [Version]"16.0.10336.20039"
                    If ($Component) {
                        $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                    }
                    Else {
                        $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\ClickToRun\Configuration")
                        ForEach ($Path in $RegPaths) {
                            [Version]$VersionToReport = (Get-ItemProperty -Path "$Path" -Name "VersionToReport" -ErrorAction SilentlyContinue).VersionToReport
                            If ($VersionToReport -ge $MinVer) {
                                $STIGRequired = $true
                            }
                        }
                        If ($STIGRequired -eq $true) {
                            Return $STIGRequired
                        }
                        Else {
                            $Component = @("Access", "Excel", "Lync", "Outlook", "PowerPoint", "Publisher", "Word", "Visio", "Project")
                            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
                        }
                    }
                }
            }
            ForEach ($Item in $Component) {
                Switch ($Item) {
                    "Common" {
                        $Executable = "CLVIEW.EXE"
                    }
                    "Access" {
                        $Executable = "MSACCESS.EXE"
                    }
                    "Excel" {
                        $Executable = "EXCEL.EXE"
                    }
                    "Groove" {
                        $Executable = "GROOVE.EXE"
                    }
                    "InfoPath" {
                        $Executable = "INFOPATH.EXE"
                    }
                    {$_ -in @("Lync", "Skype")} {
                        $Executable = "LYNC.EXE"
                        If ($Version -ne "O365") {
                            ForEach ($Path in $RegPaths) {
                                If (Get-ChildItem -Path $Path -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "Lync" -and $_.Property -eq "InstallationDirectory")}) {
                                    $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath "Lync")).InstallationDirectory -ChildPath $Executable)
                                    [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                                    If ($NextVer) {
                                        If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                                            $STIGRequired = $true
                                        }
                                    }
                                }
                            }
                            Return $STIGRequired
                        }
                    }
                    "OneNote" {
                        $Executable = "ONENOTE.EXE"
                    }
                    "Outlook" {
                        $Executable = "OUTLOOK.EXE"
                    }
                    "PowerPoint" {
                        $Executable = "POWERPNT.EXE"
                    }
                    "Project" {
                        $Executable = "WINPROJ.EXE"
                    }
                    "Publisher" {
                        $Executable = "MSPUB.EXE"
                    }
                    "Visio" {
                        $Executable = "VISIO.EXE"
                    }
                    "Word" {
                        $Executable = "WINWORD.EXE"
                    }
                }

                ForEach ($Path in $RegPaths) {
                    If (Get-ChildItem -Path "$Path\$Item" -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "InstallRoot" -and $_.Property -eq "Path")}) {
                        $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath $Item | Join-Path -ChildPath "InstallRoot")).Path -ChildPath $Executable)
                        If (Test-Path -Path $ExecutablePath) {
                            [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                            If ($NextVer) {
                                If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                                    $STIGRequired = $true
                                }
                            }
                            Else {
                                If ($ProductVersion -ge $MinVer) {
                                    $STIGRequired = $true
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }
    Return $STIGRequired
}

Function Test-IsMSOneDriveInstalled {
    # Microsoft OneDrive detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $ProductKey = "Groove"
            $Executable = "GROOVE.EXE"
            $MinVer = [Version]"16.0.4229.1003"
            $NextVer = [Version]"16.0.10336.20039"
            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Office\16.0", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0")
            ForEach ($Path in $RegPaths) {
                If (Get-ChildItem -Path "$Path\$ProductKey" -Recurse -ErrorAction SilentlyContinue | Where-Object {($_.PsChildName -eq "InstallRoot" -and $_.Property -eq "Path")}) {
                    $ExecutablePath = $(Join-Path -Path (Get-ItemProperty -Path $(Join-Path -Path $Path -ChildPath $ProductKey | Join-Path -ChildPath "InstallRoot")).Path -ChildPath $Executable)
                    If (Test-Path -Path $ExecutablePath) {
                        [Version]$ProductVersion = (Get-Item $ExecutablePath).VersionInfo.ProductVersion
                        If ($ProductVersion -ge $MinVer -and $ProductVersion -lt $NextVer) {
                            $STIGRequired = $true
                        }
                    }
                }
            }

            If ($STIGRequired -eq $false) {
                If ((Test-Path "$env:ProgramFiles\Microsoft OneDrive\OneDrive.exe") -or (Test-Path "$(${env:ProgramFiles(x86)})\Microsoft OneDrive\OneDrive.exe") -or (Test-Path "$((Get-UsersToEval -ProvideSingleUser).LocalPath)\AppData\Local\Microsoft\OneDrive\OneDrive.exe")) {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsSharePointDesignerInstalled {
    # Microsoft SharePoint Designer 2013 detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-InstalledSoftware | Where-Object DisplayName -Like "Microsoft SharePoint Designer 2013*") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSDefenderInstalled {
    # Microsoft Defender Antivirus detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If (Get-Service WinDefend -ErrorAction Stop) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSEdgeInstalled {
    # Microsoft Edge detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-InstalledSoftware | Where-Object DisplayName -EQ "Microsoft Edge") -or (Get-ChildItem -Path $env:ProgramFiles\Microsoft\Edge -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "msedge.exe") -or (Get-ChildItem -Path ${env:ProgramFiles(x86)}\Microsoft\Edge -Recurse -ErrorAction SilentlyContinue | Where-Object Name -EQ "msedge.exe")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSExchangeRoleInstalled {
    # Microsoft Exchange detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2016", "2019")]
        [string]$Version,

        [Parameter(Mandatory)]
        [ValidateSet("Edge", "Mailbox")]
        [string]$Role
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Version) {
                "2016" {
                    $MinVer = [Version]"15.1"
                    $NextVer = [Version]"15.2"
                }
                "2019" {
                    $MinVer = [Version]"15.2"
                }
            }

            Switch ($Role) {
                "Edge" {
                    $RegPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\V15\EdgeTransportRole"
                }
                "Mailbox" {
                    $RegPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\V15\MailboxRole"
                }
            }

            [Version]$Version = (Get-ItemProperty $RegPath -ErrorAction SilentlyContinue).ConfiguredVersion
            If ($NextVer) {
                If ($Version -ge $MinVer -and $Version -lt $NextVer) {
                    $STIGRequired = $true
                }
            }
            Else {
                If ($Version -ge $MinVer) {
                    $STIGRequired = $true
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMSSQLInstalled {
    # Microsoft SQL Server detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("2014", "2016")]
        [string]$Version
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            $RegPaths = @("HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server", "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Microsoft SQL Server")
            ForEach ($Path in $RegPaths) {
                $Instances = (Get-ItemProperty $Path -ErrorAction SilentlyContinue).InstalledInstances
                ForEach ($Instance in $Instances) {
                    $InstanceName = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -ErrorAction SilentlyContinue).$Instance
                    $InstanceInfo = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstanceName\Setup" -ErrorAction SilentlyContinue
                    Switch ($Version) {
                        "2014" {
                            If (($InstanceInfo).Edition -notlike "*Express*" -and [Version]($InstanceInfo).Version -like "12.*") {
                                $STIGRequired = $true
                            }
                        }
                        "2016" {
                            If ([Version]($InstanceInfo).Version -ge "13.0") {
                                $STIGRequired = $true
                            }
                        }
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsMongoDB3Installed {
    # MongoDB 3.x detection
    $STIGRequired = $false
    Try {
        $MongoProcess = Get-Process -Name 'mongo?'
        If ($null -ne $MongoProcess.Path) {
            $MongoDBVersionInfo = (& $MongoProcess.Path --version)
            $IsDB3 = $MongoDBVersionInfo | Select-String -Pattern "db\s*version\s*v3.*"
            $IsEnterprise = $MongoDBVersionInfo | Select-String -Pattern "modules:\s*enterprise"
            If ($null -ne $IsDB3 -and $null -ne $IsEnterprise) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsFirefoxInstalled {
    # Mozilla Firefox detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            If ((Test-Path /usr/lib64/firefox/) -or (Test-Path /usr/lib/firefox/) -or (Test-Path /etc/firefox/) -or (Test-Path /usr/bin/firefox/)) {
                $STIGRequired = $true
            }
        }
        Else {
            If (Get-InstalledSoftware | Where-Object DisplayName -Like "Mozilla Firefox*") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsJavaJRE8Installed {
    # Oracle Java JRE 8 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $Command = "java -version 2$([Char]62)$([Char]38)1 | Out-String"
            $JavaVer = Invoke-Expression $Command -ErrorAction SilentlyContinue
            If ($JavaVer -like "java*SE Runtime Environment*1.8.0*") {
                $STIGRequired = $true
            }
        }
        Else {
            If ((Get-DomainRoleStatus -ExpectedRole "Standalone Workstation", "Member Workstation").BoolMatchExpected -and (Get-InstalledSoftware | Where-Object DisplayName -Like "Java 8*")) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsPostgresInstalled {
    # PostgreSQL detection
    $STIGRequired = $false

    Try {
        if ($IsLinux) {
            $PostgresProcesses = (ps f -opid','ppid','cmd -C 'postgres,postmaster' --no-headers)
            if ($null -ne $PostgresProcesses) {
                $ParentProcessIds = $PostgresProcesses | awk '{print $2}' | uniq
                foreach ($pId in $ParentProcessIds) {
#                    $IsContainer = Test-IsContainerProcess -ProcessId $pId

#                    if ($IsContainer) {
#                        $STIGRequired = $false
#                        break
#                    }
#                    else {
                        $STIGRequired = $true
#                    }
                }
            }
        }
        else {
            $IsPostgresInstalled = (Get-InstalledSoftware | Where-Object DisplayName -Like "Postgres*")
            if ($IsPostgresInstalled) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsRKE2Installed {
    # Rancher Government Solutions RKE2 detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            If ((Get-Process).ProcessName -match "rke2 agent|rke2 server") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsTrellixInstalled {
    # Trellix ENS 10x Local detection
    $STIGRequired = $false
    Try {
        If ($IsLinux) {
            $IsTrellixInstalled = ((Get-TrellixOptDirs | Measure-Object).Count -ge 1)
            $IsENSInstalled = (((find /opt -type d -name ens) | Measure-Object).Count -ge 1)
            If ($IsTrellixInstalled -eq $true -and $IsENSInstalled -eq $true) {
                $Parameters = "-i"
                $Exec = (find /opt -type f -name cmdagent)
                $AgentModeString = (Invoke-Expression "$($Exec) $($Parameters)") | Select-String -Pattern AgentMode -Raw
                If ($null -ne $AgentModeString -and $AgentModeString -ne "") {
                    $AgentMode = ($AgentModeString.Split(":")[1]).Trim()
                    If ($AgentMode -eq "0") {
                        $STIGRequired = $true
                    }
                }
            }
        }
        Else {
            $RegistryPath = "HKLM:\SOFTWARE\McAfee\Endpoint\Common"
            $RegistryValueName = "ProductVersion"
            $IsVersionTenPlus = ((Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName).Value -Like "10.*")
            If ($IsVersionTenPlus -eq $true) {
                $RegistryPath = "HKLM:\SOFTWARE\WOW6432Node\McAfee\Agent"
                $RegistryValueName = "AgentMode"
                $AgentMode = (Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName).Value
                If ($null -eq $AgentMode -or $AgentMode -eq "(NotFound)") {
                    $STIGRequired = $true
                }
                Else {
                    $IsAgentModeZero = ($AgentMode -eq "0")
                    If ($IsAgentModeZero -eq $true) {
                        $STIGRequired = $true
                    }
                }
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsVMwareHorizonInstalled {
    # VMware Horizon 7.13 detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Agent", "Client", "ConnectionServer")]
        [string]$Component
    )

    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            Switch ($Component) {
                "Agent" {
                    $DisplayName = "VMware Horizon Agent"
                    $DisplayVersion = "7"
                }
                "Client" {
                    $DisplayName = "VMware Horizon Client"
                    $DisplayVersion = "5"
                }
                "ConnectionServer" {
                    $DisplayName = "VMware Horizon 7 Connection Server"
                    $DisplayVersion = "7"
                }
            }
            If (Get-InstalledSoftware | Where-Object {$_.DisplayName -eq $DisplayName -and $_.DisplayVersion -like "$($DisplayVersion).*"}) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsWinDNSServer {
    # Windows DNS Server detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ((Get-Service DNS -ErrorAction SilentlyContinue) -and ((Test-IsRunningOS -Version WinServer2016) -or (Test-IsRunningOS -Version WinServer2019) -or (Test-IsRunningOS -Version WinServer2022))) {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

Function Test-IsWinFirewallInstalled {
    # Windows Firewall detection
    $STIGRequired = $false
    Try {
        If (-Not($IsLinux)) {
            If ([Version](Get-CimInstance Win32_OperatingSystem).Version -ge [Version]"6.1") {
                $STIGRequired = $true
            }
        }
    }
    Catch {
        Return $STIGRequired
    }

    Return $STIGRequired
}

function Test-IsContainerProcess {
    param (
        [Parameter(Mandatory = $True)]
        [int]$ProcessId
    )

    $IsContainer = $false

    if ($ProcessId -gt 1) {
        $ProcessCommandLine = Get-ProcessCommandLine -ProcessId $ProcessId
        $ContainerProcess = $ProcessCommandLine -match '\bcontainerd-shim\b|\bconmon\b'

        if ($null -ne $ContainerProcess -and $ContainerProcess -ne "") {
            $IsContainer = $true
        }
    }

    return $IsContainer
}

Function Test-IsRunningOS {
    # Operating system detection
    Param (
        [Parameter(Mandatory)]
        [ValidateSet("Oracle7", "Oracle8", "RHEL7", "RHEL8", "RHEL9", "Ubuntu16", "Ubuntu18", "Ubuntu20", "Ubuntu22", "Win10", "Win11", "WinServer2008R2", "WinServer2012", "WinServer2016", "WinServer2019", "WinServer2022")]
        [string]$Version
    )

    # Expose addtional dynamic parameters
    DynamicParam {
        $ParamDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

        If ($Version.Trim() -match "^WinServer") {
            # Expose -IsDC
            $Attributes = New-Object System.Management.Automation.ParameterAttribute
            $Attributes.Mandatory = $false
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            $AttributeCollection.Add($Attributes)
            $IsDCParam = New-Object System.Management.Automation.RuntimeDefinedParameter("IsDC", [Switch], $AttributeCollection)
            $ParamDictionary.Add("IsDC", $IsDCParam)
        }

        Return $ParamDictionary
    }

    Process {
        $STIGRequired = $false
        Try {
            If ($IsLinux) {
                $OSRelease = Get-Content /etc/os-release -ErrorAction SilentlyContinue
                Switch ($Version) {
                    "Oracle7" {
                        If ($OSRelease -like '*NAME="Oracle Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Oracle8" {
                        If ($OSRelease -like '*NAME="Oracle Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            $STIGRequired = $true
                        }
                    }
                    "RHEL7" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="CentOS Linux*' -and $OSRelease -like '*VERSION_ID="7*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="7.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "RHEL8" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="8.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "RHEL9" {
                        If ($OSRelease -like '*NAME="Red Hat Enterprise Linux*' -and $OSRelease -like '*VERSION_ID="9.*') {
                            $STIGRequired = $true
                        }
                        ElseIf ($OSRelease -like '*NAME="RedHawk Linux*' -and $OSRelease -like '*VERSION_ID="9.*') {
                            If ($(Get-Content /etc/redhat-release) -like "Red Hat Enterprise Linux*") {
                                $STIGRequired = $true
                            }
                        }
                    }
                    "Ubuntu16" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="16.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu18" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="18.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu20" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="20.*') {
                            $STIGRequired = $true
                        }
                    }
                    "Ubuntu22" {
                        If ($OSRelease -like '*NAME="Ubuntu*' -and $OSRelease -like '*VERSION_ID="22.*') {
                            $STIGRequired = $true
                        }
                    }
                }
            }
            Else {
                If ($PsBoundParameters.IsDC) {
                    $IsDC = "{0}" -f $PsBoundParameters.IsDC
                }
                $Caption = (Get-CimInstance Win32_OperatingSystem).Caption
                Switch ($Version) {
                    "Win10" {
                        If ($Caption -Like "*Windows 10*") {
                            $STIGRequired = $true
                        }
                    }
                    "Win11" {
                        If ($Caption -Like "*Windows 11*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2008R2" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2008 R2*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2008 R2*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2012" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2012*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2012*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2016" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2016*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2016*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2019" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2019*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2019*") {
                            $STIGRequired = $true
                        }
                    }
                    "WinServer2022" {
                        If ($IsDC) {
                            If ($Caption -Like "*Windows*Server 2022*" -and (Get-DomainRoleStatus -ExpectedRole "Backup Domain Controller", "Primary Domain Controller").BoolMatchExpected) {
                                $STIGRequired = $true
                            }
                        }
                        ElseIf ($Caption -Like "*Windows*Server 2022*") {
                            $STIGRequired = $true
                        }
                    }
                }
            }
        }
        Catch {
            Return $STIGRequired
        }

        Return $STIGRequired
    }
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDZbm/mOp5vI7Rd
# Xjx1EGPj+BnTRnUxKP7tjpHCxJu7HaCCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCAx4x+zQOtFlDcpMHgKQ64PA3cCseGd
# sozk2peN2bKdqzANBgkqhkiG9w0BAQEFAASCAQBGLrhOzGQlowrYgowZL52Rn9xP
# sJp9J0yren5/b6g3t9SzBVDveFZOyoeqTEzeZgILA01xfDAFa/Q8rd0w++HRAECR
# CQG/GdJ8uqcuxz8VNgXFT/5pH7wc22jr2let4gbIPObygKwnpDOVhZ7xWnX9IrO9
# YPqFDU/xngorSsjugPTK7sX68g6QnppkfGV8+J4QVmrFOFRzrI78VHE6DyJvgjAe
# vgq+/F6GwH4elljvnEH9SBHR+tl0JYvqSYc4130PS8ZtgFlqks4JVOhIaZMzU2M2
# vxVQrEboRshk8LRWymfMG4PIwKVe/n6/BMpEmlzgezGUJyv2HLP5/+iDDB3m
# SIG # End signature block
